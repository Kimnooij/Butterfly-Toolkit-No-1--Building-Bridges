<?php
defined('_JEXEC') or die('Restricted access');

class modCutter_Cut_period_filter_processor
{
	function cutterPostProcessor($html)
	{
		$html = modCutter_Cut_period_filter_processor::cutPeriodFilter($html);
		return $html;	
	}	

	function cutPeriodFilter($html)
	{
		if($html)
		{		
			$script_tags = modCutterHelper::cutAllCssJsTags($html);			
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
			
			$tag = "div";
			$attribute = "class";
			$value = "play";

			$query = modCutterHelper::singleAttributeExtendedQuery($tag, $attribute, $value);
			$dom = modCutterHelper::removeNodeElements($query, $dom);
			
			$innerHTML = modCutterHelper::convertDomToHtml($dom);
			$html = $script_tags.$innerHTML;
		}
		return $html;
	}
}
?>