<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Example system plugin
 */
class plgSystemPcoecssloader extends JPlugin
{
	function plgSystemPcoecssloader( &$subject, $config )
	{
		parent::__construct( $subject, $config );
	}

	function onAfterInitialise()
	{
		$db=JFactory::getDBO();
		$q="SELECT `template` FROM `#__templates_menu` WHERE menuid=0 AND client_id=0";
		$db->setQuery($q);
		$template = $db->loadResult();
		if($template != 'pcoe')
		{
			$pcoe_stylesheet = JURI::root()."templates/pcoe/css/pcoe.css";
			$document =& JFactory::getDocument();
			$document->addStyleSheet( $pcoe_stylesheet );
		}
	}

}