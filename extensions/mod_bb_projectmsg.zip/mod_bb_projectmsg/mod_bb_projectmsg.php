<?php
defined('_JEXEC') or die('Restricted access');

$text = trim($params->get('text'));
echo $text;

?>