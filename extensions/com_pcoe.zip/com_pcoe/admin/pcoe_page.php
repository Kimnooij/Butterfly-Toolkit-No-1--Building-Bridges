<?php
/**
 * This file acts as the "front controller" to your application. You can
 * configure your application, modules, and system directories here.
 * PHP error_reporting level may also be changed.
 *
 * @see http://kohanaphp.com
 */
/*------------ Hacked by Korn Serey ----------------------*/
defined('_JEXEC') or die( 'Restricted access' );
if($_GET['kohana_uri']=='')
{
	switch(JRequest::getCmd('view'))
	{
		case 'main':		
				$_GET['kohana_uri']='main';
			break;
		case 'reports':
				$_GET['kohana_uri']='reports';
			break;
		case 'alerts':
			$_GET['kohana_uri']='alerts';
			break;				
		case 'submit':
			$_GET['kohana_uri']='reports/submit';
			break;
		case 'help':
			$_GET['kohana_uri']='help';
			break;
			
		case 'dashboard':
		case 'profile':
			$_GET['kohana_uri']='profile/dashboard';
			break;
		case 'project':
			$_GET['kohana_uri']='profile/project';
			break;
		case 'update':
			$_GET['kohana_uri']='profile/update';
			break;
		case 'comments':
			$_GET['kohana_uri']='profile/comments';
			break;			
	}
}
JRequest::setVar('kohana_uri',$_GET['kohana_uri']);
if(strpos( $_GET['kohana_uri'],'?')!==false)
{
	$parts=explode('?',$_GET['kohana_uri']);
	$_GET['kohana_uri']=$parts[0];
	if(isset($parts[1]))
	{
		$query_string=$parts[1];
		$parts=explode('&',$query_string);
		for($i=0;$i<count($parts);$i++)
		{
			$query_string_parts=explode('=',$parts[$i]);
			$_GET[$query_string_parts[0]]=$query_string_parts[1];
		}
	}
}

$kohana_uri=JRequest::getCmd('kohana_uri');
if(defined('_FRONT_END')) //Prevent Admin Path from accessing in front-end
{	
	if(substr($kohana_uri,0,5)=='admin')
	{
		JError::raiseError( 404, 'Page not found');
	}
	if($kohana_uri=='')
		$_GET['kohana_uri']='main';
}
if(defined('_BACKEND_END'))
{
	if($kohana_uri=='')
		$_GET['kohana_uri']='admin/dashboard/';
	
	if(JRequest::getCmd('view') == 'about')
	{
		print_pcoe_info();
		return;
	}
}
/*
echo '$kohana_uri : ' . $kohana_uri;
echo 'GET : ' . $_GET['kohana_uri'];
echo 'View : ' . JRequest::getCmd('view');
*/
if(strpos($kohana_uri,'media')!==false)
{	
	global $mainframe;
	$kohana_uri=$_GET['kohana_uri'];
	
	if(defined('_BACKEND_END'))
		$path=$mainframe->getSiteURL().'/administrator/components/com_pcoe/pcoe/'.$kohana_uri;
	else
		$path=JURI::base().'/administrator/components/com_pcoe/pcoe/'.$kohana_uri;
	
	$mainframe->redirect($path);
}
function server_side_redirect()
{
	$mimeTypes=array(
			'ai'=>'application/postscript',
			'aif'=>'audio/x-aiff',
			'aifc'=>'audio/x-aiff',
			'aiff'=>'audio/x-aiff',
			'asc'=>'text/plain',
			'atom'=>'application/atom+xml',
			'au'=>'audio/basic',
			'avi'=>'video/x-msvideo',
			'bcpio'=>'application/x-bcpio',
			'bin'=>'application/octet-stream',
			'bmp'=>'image/bmp',
			'cdf'=>'application/x-netcdf',
			'cgm'=>'image/cgm',
			'class'=>'application/octet-stream',
			'cpio'=>'application/x-cpio',
			'cpt'=>'application/mac-compactpro',
			'csh'=>'application/x-csh',
			'css'=>'text/css',
			'dcr'=>'application/x-director',
			'dif'=>'video/x-dv',
			'dir'=>'application/x-director',
			'djv'=>'image/vnd.djvu',
			'djvu'=>'image/vnd.djvu',
			'dll'=>'application/octet-stream',
			'dmg'=>'application/octet-stream',
			'dms'=>'application/octet-stream',
			'doc'=>'application/msword',
			'dtd'=>'application/xml-dtd',
			'dv'=>'video/x-dv',
			'dvi'=>'application/x-dvi',
			'dxr'=>'application/x-director',
			'eps'=>'application/postscript',
			'etx'=>'text/x-setext',
			'exe'=>'application/octet-stream',
			'ez'=>'application/andrew-inset',
			'gif'=>'image/gif',
			'gram'=>'application/srgs',
			'grxml'=>'application/srgs+xml',
			'gtar'=>'application/x-gtar',
			'hdf'=>'application/x-hdf',
			'hqx'=>'application/mac-binhex40',
			'htm'=>'text/html',
			'html'=>'text/html',
			'ice'=>'x-conference/x-cooltalk',
			'ico'=>'image/x-icon',
			'ics'=>'text/calendar',
			'ief'=>'image/ief',
			'ifb'=>'text/calendar',
			'iges'=>'model/iges',
			'igs'=>'model/iges',
			'jnlp'=>'application/x-java-jnlp-file',
			'jp2'=>'image/jp2',
			'jpe'=>'image/jpeg','
			jpeg'=>'image/jpeg',
			'jpg'=>'image/jpeg',
			'js'=>'application/x-javascript',
			'kar'=>'audio/midi',
			'latex'=>'application/x-latex',
			'lha'=>'application/octet-stream',
			'lzh'=>'application/octet-stream',
			'm3u'=>'audio/x-mpegurl',
			'm4a'=>'audio/mp4a-latm',
			'm4b'=>'audio/mp4a-latm',
			'm4p'=>'audio/mp4a-latm',
			'm4u'=>'video/vnd.mpegurl',
			'm4v'=>'video/x-m4v',
			'mac'=>'image/x-macpaint',
			'man'=>'application/x-troff-man',
			'mathml'=>'application/mathml+xml',
			'me'=>'application/x-troff-me',
			'mesh'=>'model/mesh',
			'mid'=>'audio/midi',
			'midi'=>'audio/midi',
			'mif'=>'application/vnd.mif',
			'mov'=>'video/quicktime',
			'movie'=>'video/x-sgi-movie',
			'mp2'=>'audio/mpeg',
			'mp3'=>'audio/mpeg',
			'mp4'=>'video/mp4',
			'mpe'=>'video/mpeg',
			'mpeg'=>'video/mpeg',
			'mpg'=>'video/mpeg',
			'mpga'=>'audio/mpeg',
			'ms'=>'application/x-troff-ms',
			'msh'=>'model/mesh',
			'mxu'=>'video/vnd.mpegurl',
			'nc'=>'application/x-netcdf',
			'oda'=>'application/oda',
			'ogg'=>'application/ogg',
			'pbm'=>'image/x-portable-bitmap',
			'pct'=>'image/pict',
			'pdb'=>'chemical/x-pdb',
			'pdf'=>'application/pdf',
			'pgm'=>'image/x-portable-graymap',
			'pgn'=>'application/x-chess-pgn',
			'pic'=>'image/pict',
			'pict'=>'image/pict',
			'png'=>'image/png',
			'pnm'=>'image/x-portable-anymap',
			'pnt'=>'image/x-macpaint',
			'pntg'=>'image/x-macpaint',
			'ppm'=>'image/x-portable-pixmap',
			'ppt'=>'application/vnd.ms-powerpoint',
			'ps'=>'application/postscript',
			'qt'=>'video/quicktime',
			'qti'=>'image/x-quicktime',
			'qtif'=>'image/x-quicktime',
			'ra'=>'audio/x-pn-realaudio',
			'ram'=>'audio/x-pn-realaudio',
			'ras'=>'image/x-cmu-raster',
			'rdf'=>'application/rdf+xml',
			'rgb'=>'image/x-rgb',
			'rm'=>'application/vnd.rn-realmedia',
			'roff'=>'application/x-troff',
			'rtf'=>'text/rtf',
			'rtx'=>'text/richtext',
			'sgm'=>'text/sgml',
			'sgml'=>'text/sgml',
			'sh'=>'applcation/x-sh',
			'shar'=>'applcation/x-shar',
			'silo 	model/mesh',
			'sit'=>'applcation/x-stuffit',
			'skd'=>'applcation/x-koan',
			'skm'=>'applcation/x-koan',
			'skp'=>'applcation/x-koan',
			'skt'=>'applcation/x-koan',
			'smi'=>'applcation/smil',
			'smil'=>'applcation/smil',
			'snd'=>'audio/basic',
			'so'=>'applcation/octet-stream',
			'spl'=>'applcation/x-futuresplash',
			'src'=>'applcation/x-wais-source',
			'sv4cpio'=>'applcation/x-sv4cpio',
			'sv4crc'=>'applcation/x-sv4crc',
			'svg'=>'image/svg+xml',
			'swf'=>'applcation/x-shockwave-flash',
			't'=>'applcation/x-troff',
			'tar'=>'applcation/x-tar',
			'tcl'=>'applcation/x-tcl',
			'tex'=>'applcation/x-tex',
			'texi'=>'applcation/x-texinfo',
			'texinfo'=>'applcation/x-texinfo',
			'tif'=>'image/tiff',
			'tiff'=>'image/tiff',
			'tr'=>'applcation/x-troff',
			'tsv'=> 'text/tab-separated-values',
			'txt'=>'text/plain',
			'ustar'=>'applcation/x-ustar',
			'vcd'=>'applcation/x-cdlink',
			'vrml'=>'model/vrml',
			'vxml'=>'applcation/voicexml+xml',
			'wav'=>'audio/x-wav',
			'wbmp'=>'image/vnd.wap.wbmp',
			'wbmxl'=>'applcation/vnd.wap.wbxml',
			'wml'=>'text/vnd.wap.wml',
			'wmlc'=>'applcation/vnd.wap.wmlc',
			'wmls'=>'text/vnd.wap.wmlscript',
			'wmlsc'=>'applcation/vnd.wap.wmlscriptc',
			'wrl'=>'model/vrml',
			'xbm'=>'image/x-xbitmap',
			'xht'=>'applcation/xhtml+xml',
			'xhtml'=>'applcation/xhtml+xml',
			'xls'=>'applcation/vnd.ms-excel',
			'xml'=>'applcation/xml',
			'xpm'=>'image/x-xpixmap',
			'xsl'=>'applcation/xml',
			'xslt'=>'applcation/xslt+xml',
			'xul'=>'applcation/vnd.mozilla.xul+xml',
			'xwd'=>'image/x-xwindowdump',
			'xyz'=>'chemical/x-xyz',
			'zip'=>'applcation/zip');
	$parts=explode('.',$kohana_uri);
	
	$extension=$parts[1]; //implement by yourself
	$mimeType=$mimeTypes[$extension];
	$filename =JPATH_SITE .DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.$kohana_uri;
	header('Content-Type: '.$mimeType );
	echo readfile($filename);
	exit(0);
}
/**
 * Define the website environment status. When this flag is set to TRUE, some
 * module demonstration controllers will result in 404 errors. For more information
 * about this option, read the documentation about deploying Kohana.
 *
 * @see http://docs.kohanaphp.com/installation/deployment
 */
ob_start();
define('IN_PRODUCTION', TRUE);

/**
 * Website application directory. This directory should contain your application
 * configuration, controllers, models, views, and other resources.
 *
 * This path can be absolute or relative to this file.
 */
$kohana_application = JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'application';

/**
 * Kohana modules directory. This directory should contain all the modules used
 * by your application. Modules are enabled and disabled by the application
 * configuration file.
 *
 * This path can be absolute or relative to this file.
 */
$kohana_modules =JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'modules';

/**
 * Kohana system directory. This directory should contain the core/ directory,
 * and the resources you included in your download of Kohana.
 *
 * This path can be absolute or relative to this file.
 */
$kohana_system =JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'system';

/**
 * Themes directory.
 *
 * This path can be absolute or relative to this file.
 */
 $kohana_themes =JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'themes';

/**
 * Test to make sure that Kohana is running on PHP 5.2 or newer. Once you are
 * sure that your environment is compatible with Kohana, you can comment this
 * line out. When running an application on a new server, uncomment this line
 * to check the PHP version quickly.
 */
version_compare(PHP_VERSION, '5.2', '<') and exit('Kohana requires PHP 5.2 or newer.');

/**
 * Set the error reporting level. Unless you have a special need, E_ALL is a
 * good level for error reporting.
 */
error_reporting(E_ALL & ~E_STRICT);

/**
 * Turning off display_errors will effectively disable Kohana error display
 * and logging. You can turn off Kohana errors in application/config/config.php
 */
ini_set('display_errors', TRUE);

/**
 * If you rename all of your .php files to a different extension, set the new
 * extension here. This option can left to .php, even if this file has a
 * different extension.
 */
define('EXT', '.php');

//
// DO NOT EDIT BELOW THIS LINE, UNLESS YOU FULLY UNDERSTAND THE IMPLICATIONS.
// ----------------------------------------------------------------------------
// $Id: index.php 3168 2008-07-21 01:34:36Z Shadowhand $
//

// Define the front controller name and docroot
define('DOCROOT', JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS);
define('KOHANA',  basename(__FILE__));

// If the front controller is a symlink, change to the real docroot
is_link(KOHANA) and chdir(dirname(realpath(__FILE__)));

// Define application and system paths

define('APPPATH', str_replace('\\', '/', realpath($kohana_application)).'/');
define('THEMEPATH', str_replace('\\', '/', realpath($kohana_themes)).'/');
define('MODPATH', str_replace('\\', '/', realpath($kohana_modules)).'/');
define('SYSPATH', str_replace('\\', '/', realpath($kohana_system)).'/');
/*
echo APPPATH .'<br>';
echo THEMEPATH .'<br>';
echo MODPATH .'<br>';
echo SYSPATH .'<br>';
echo DOCROOT .'<br>';
*/
// Clean up
unset($kohana_application, $kohana_themes, $kohana_modules, $kohana_system);

if ( ! IN_PRODUCTION)
{
	// Check APPPATH
	if ( ! (is_dir(APPPATH) AND is_file(APPPATH.'config/config'.EXT)))
	{
		die
		(
			'<div style="width:80%;margin:50px auto;text-align:center;">'.
				'<h3>Application Directory Not Found</h3>'.
				'<p>The <code>$kohana_application</code> directory does not exist.</p>'.
				'<p>Set <code>$kohana_application</code> in <tt>'.KOHANA.'</tt> to a valid directory and refresh the page.</p>'.
			'</div>'
		);
	}

	// Check SYSPATH
	if ( ! (is_dir(SYSPATH) AND is_file(SYSPATH.'core/Bootstrap'.EXT)))
	{
		die
		(
			'<div style="width:80%;margin:50px auto;text-align:center;">'.
				'<h3>System Directory Not Found</h3>'.
				'<p>The <code>$kohana_system</code> directory does not exist.</p>'.
				'<p>Set <code>$kohana_system</code> in <tt>'.KOHANA.'</tt> to a valid directory and refresh the page.</p>'.
			'</div>'
		);
	}
}


// Initialize.
require SYSPATH.'core/Bootstrap'.EXT;
if(substr(JRequest::getCmd('kohana_uri'),0,4)=='feed')
	exit(0);

if(substr(JRequest::getCmd('kohana_uri'),0,4)=='json')
	exit(0);

$kohana_uri=JRequest::getCmd('kohana_uri');
if($kohana_uri=='captchadefault') //captcha will create an images
	exit(0);
//register the function above as autoloader
spl_autoload_register('original_joomla_autoload');
$content=ob_get_clean();

$article=new stdClass();
$article->text=$content;
if(defined('_FRONT_END'))
{
	/*
	* Process the prepare content plugins
	*/	
	$params=array();
	$dispatcher	=& JDispatcher::getInstance();
	JPluginHelper::importPlugin('content','cssmapper');
//	JPluginHelper::importPlugin('content','loadmodule');
	$results = $dispatcher->trigger('onPrepareContent', array ($article, $params));
					
	JPluginHelper::importPlugin('pcoe');
	$results = $dispatcher->trigger('onSefURL', array ($article));	
}
echo $article->text;

function original_joomla_autoload($class)
{
       //copy of the original joomla autoload class declared in libraries/loader.php
       //Kohana overwrites the autoload behaviour
       //Consequently, Joomla cannot autoload JModuleHelper when dealing with the modules
       //So, register the original Joomla autoloader again, after finishing executing Kohana scripts

        if(JLoader::load($class)) {
                return true;
        }
        return false;

}

function print_pcoe_info()
{
	jimport('joomla.filesystem.file');
	$info_file = JPATH_ADMINISTRATOR.'/components/com_pcoe_mei/pcoe_info.php';
	if(JFile::exists($info_file))
	{
		require_once(JPATH_ADMINISTRATOR.'/components/com_pcoe_mei/pcoe_info.php');
		
		Pcoe_Helper_Info::print_pcoe_info();
	}	
}
?>