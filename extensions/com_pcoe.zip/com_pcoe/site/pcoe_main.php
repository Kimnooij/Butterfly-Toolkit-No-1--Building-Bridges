<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );		
	if(!defined('_FRONT_END'))define('_FRONT_END',1);	
	require_once(JPATH_ADMINISTRATOR.'/components/com_pcoe/pcoe_page.php');
	
?>