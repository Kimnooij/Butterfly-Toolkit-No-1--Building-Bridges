<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );		
	define('_FRONT_END',1);	
	require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'pcoe_page.php');
	
?>