<?php
/**
* @version		$Id: router.php 10711 2008-08-21 10:09:03Z eddieajau $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

function PCOEBuildRoute(&$query)
{
	static $items;
	$segments	= array();
	$itemid		= null;
	
	
	$component	= &JComponentHelper::getComponent('com_pcoe');
	$menus		= &JSite::getMenu();
	$items		= $menus->getItems('componentid', $component->id);
	$item =& $menus->getActive();
	
	if(!isset($query['kohana_uri']) AND defined('_FRONT_END'))
		$query['kohana_uri']='';
	
	$kohana_uri_parts=explode('/',$query['kohana_uri']);	
	$current_view=$kohana_uri_parts[0];
	if($current_view=='reports')
	{
		if(isset($kohana_uri_parts[1]))
		{
			if($kohana_uri_parts[1]=='submit')
				$current_view='submit';
		}
	}
	
	$related_menu_item=null;
	$new_item_id=0;
	if(isset($query['Itemid']))
		$new_item_id=$query['Itemid'];
		
	if($items!=null)
	{
		foreach($items as $menu_item)
		{
			if($current_view==$menu_item->query['view'])
			{			
					$related_menu_item=$menu_item;
					$new_item_id=$menu_item->id;
			}
			
		}	
	}
	$query['Itemid']=$new_item_id;
	$finds=array();
	$replaces=array();
	$finds[]='?';
	$finds[]='=';
	$replaces[]='/';
	$replaces[]='/';
	if($related_menu_item)
	{
		$kohana_uri_parts=explode('/',$query['kohana_uri']);
		if(count($kohana_uri_parts)>1)
		{
			$query['kohana_uri']=str_replace(
												array($kohana_uri_parts[0].'/submit',$kohana_uri_parts[0],'//'),
												array('','','/'),
												$query['kohana_uri']
											);
		}
	}
	$query['kohana_uri']=str_replace($finds,$replaces,$query['kohana_uri']);
	$segments=explode('/',$query['kohana_uri']);	
	
	unset($query['kohana_uri']);
	
	return $segments;
}

function PCOEParseRoute($segments)
{
	//print_r($segments);
	$vars = array();

	//Get the active menu item
	$menu =& JSite::getMenu();
	$item =& $menu->getActive();
	
	if(!$item)
	{	
		$vars['kohana_uri']=$item->query['kohana_uri'];
		if(count($segments)>0)
		{			
			if($segments[0]=='reports')
			{
				switch(count($segments))
				{
					case 1:						
							$vars['view']='reports';
							break;
					case 2:
							$vars['kohana_uri'] .=$segments[0].'/'.$segments[1];
							break;
					case 3:
							$vars['kohana_uri'] =$segments[0] .'/';
							if($segments[1]=='view')
							{
								$vars['kohana_uri'] .=$segments[1].'/'.$segments[2];
							}
							if($segments[1]=='c')
							{
								$vars['c']=$segments[2];
							}	
							break;
				}				
			}
			if($segments[0]=='help')
			{
				switch(count($segments))
				{					
					case 2:
							$vars['kohana_uri'] .=$segments[0].'/'.$segments[1];
							break;
					case 3:
							$vars['kohana_uri'] =$segments[0] .'/';
							if($segments[1]=='view')
							{
								$vars['kohana_uri'] .=$segments[1].'/'.$segments[2];
							}							
							break;
				}				
			}
		}
	}
	else
	{
		$vars['view']=$item->query['view'];
		switch($item->query['view'])
		{
			case 'main':
				switch(count($segments))
					{
						case 2:
							$vars['kohana_uri']='reports/';		
							if($segments[0]=='view')
							{
								$vars['kohana_uri'] .=$segments[0].'/'.$segments[1];
							}
							if($segments[0]=='c')
							{
								$vars['c']=$segments[1];
							}
							
							if($segments[1]=='submit')
							{
								$vars['kohana_uri'] .='submit/';		
							}
							
							break;

					}
					break;
			case 'reports':
				$vars['kohana_uri']='reports/';				
				if(count($segments)>0)
				{
					
					switch(count($segments))
					{
						case 1:
							if($segments[0]!='reports')
								$vars['kohana_uri'] .=$segments[0];
							break;
						case 2:
							if($segments[0]=='view')
							{
								$vars['kohana_uri'] .=$segments[0].'/'.$segments[1];
							}
							if($segments[0]=='c')
							{
								$vars['c']=$segments[1];
							}
							
							if($segments[1]=='submit')
							{
								$vars['kohana_uri'] .='submit/';		
							}
							
							break;
						case 3:
							if($segments[1]=='view')
							{
								$vars['kohana_uri'] .=$segments[1].'/'.$segments[2];
							}
							if($segments[1]=='c')
							{
								$vars['c']=$segments[2];
							}	
							break;														
					}
				}	
				break;
			case 'help':
				$vars['kohana_uri']='help/';	
				if(count($segments)>0)
				{
					
					switch(count($segments))
					{
						case 2:
							if($segments[0]=='view')
							{
								$vars['kohana_uri'] .=$segments[0].'/'.$segments[1];
							}						
							
							break;
						case 3:
							if($segments[1]=='view')
							{
								$vars['kohana_uri'] .=$segments[1].'/'.$segments[2];
							}							
							break;														
					}
				}	
				break;
		}		
	}
	if(count($segments)==1)
	{
		if($segments[0]=='feed' OR $segments[0]=='search')
		{
			$vars['kohana_uri']=$segments[0];
		}
	}	
	return $vars;
}
