<?php
defined('_JEXEC') or die('Restricted access');

$functions_dir = dirname(__FILE__)."/functions/";

//load helper file
require_once($functions_dir.'helper.php');

$document = &JFactory::getDocument();
$document->addScriptDeclaration(modPcoeCentralMapHelper::setCentralMapGlobalVariable());

jimport('joomla.filesystem.file');
$cutter_functions = JPATH_SITE."/modules/mod_cutter/functions/helper.php";

if(JFile::exists($cutter_functions))
{
  require_once($cutter_functions);
  
  //$url = trim($params->get('url'));
  $url = modCutterHelper::getPcoeUrl();
  $tag = trim($params->get('tag'));
  $attribute = trim($params->get('attribute'));
  $value = trim($params->get('value'));
  $index = trim($params->get('index'));
  $post_script = trim($params->get('post_script'));
  	
  if($url)
  {
  	$html = modCutterHelper::cutUrlHtmlContentNode($url,$tag,$attribute,$value,$index);
  	
  	if($post_script)
  	{
  		$html = modCutterHelper::postProcessScript($html,$post_script, $functions_dir);	
  	}
	//print result
  	modCutterHelper::printResult($html);
  }
}


?>