<?php
	
	define('CENTRALMAPCUTTER_MSG1','  works with the Central Map module');
	define('CENTRALMAPCUTTER_MSG2','The Central Map module needs to be published');
	
?>

     