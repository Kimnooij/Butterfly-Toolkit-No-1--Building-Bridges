<?php
defined('_JEXEC') or die('Restricted access');

class modCutter_Cut_central_map_processor
{
	function cutterPostProcessor($html)
	{
		$html = modCutter_Cut_central_map_processor::cutCentralMap($html);
		return $html;	
	}	

	function cutCentralMap($html)
	{
		if($html)
		{	
			//extract script tags
			$script_tags = modCutterHelper::cutAllCssJsTags($html);			
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
			
			//multiple classes query
			$tag = "div";
			$attribute = "class";
			$value = "slider-holder";
			$attribute2 = "class";
			$value2 = "filter";			
			$attribute3 = "id";
			$value3 = "graph";
			 
			$query = modCutterHelper::tripleAttributeExtendedQuery($tag, $attribute, $value, $attribute2, $value2, $attribute3, $value3);				
			$dom = modCutterHelper::removeNodeElements($query, $dom);
		
			$innerHTML = modCutterHelper::convertDomToHtml($dom);
			$html = $script_tags.$innerHTML;
		}
		return $html;
	}
}
?>