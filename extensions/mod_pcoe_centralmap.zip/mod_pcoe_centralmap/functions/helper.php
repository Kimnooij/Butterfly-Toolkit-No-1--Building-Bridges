<?php
defined('_JEXEC') or die('Restricted access');

class modPcoeCentralMapHelper
{
	function setCentralMapGlobalVariable()
  {
  		return 'var googleMapCutterPublished = true;';
  }
  
  function centralMapPublishedScript($name=null)
	{
    //load language file
    modPcoeCentralMapHelper::loadLanguageFile();
    if($name)
	  {
      $msg = $name.CENTRALMAPCUTTER_MSG1.'<br>';
    }
	  $msg .= CENTRALMAPCUTTER_MSG2;
	
    ob_start();
?>
    	<script type="text/javascript">
  			if(typeof(googleMapCutterPublished) == 'undefined')
          {
            message = '<strong><?php echo $msg; ?></strong>';
            document.write(message);
          }  
    	</script>
<?php
		$script = ob_get_contents();
		ob_end_clean();
		return $script;
	}
  
  function loadLanguageFile()
  {
    //get active language
    $lang =& JFactory::getLanguage();
    $active_lang = trim($lang->get('backwardlang'));
    
    jimport('joomla.filesystem.file');
    $lang_dir = JPATH_SITE."/modules/mod_pcoe_centralmap/languages/";
    //get  language file
    if( JFile::exists(($lang_dir.$active_lang.'.php'))) 
    {
    	require_once($lang_dir.$active_lang.'.php');
    } 
    else {
    	require_once($lang_dir.'english.php');
    }

  }	

	function cutCentralMap($html)
	{
		if($html)
		{	
			//extract script tags
			$script_tags = modCutterHelper::cutAllCssJsTags($html);
			
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
			//Init the XPath object
			$xpath = new DOMXpath($dom);		
			$query ="//div[@class='slider-holder' or @class='filter']";
			$results = $xpath->query( $query );
			foreach ($results as $element) 
			{				
				$element->parentNode->removeChild($element);				
			} 	
			$innerHTML = modCutterHelper::convertDomToHtml($dom);
			$html = $script_tags.$innerHTML;
		}
		return $html;
	}
}
?>