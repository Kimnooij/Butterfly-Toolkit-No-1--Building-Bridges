<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$mainframe->registerEvent( 'onPrepareContent', 'plgContentCssmapper' );

function plgContentCssmapper( &$row, &$params )
{
	//echo "<strong>CSS mapper plugin called</strong>";
	if(file_exists(JPATH_ADMINISTRATOR."/components/com_cssmapper/functions/helper.php"))
	{
		require_once(JPATH_ADMINISTRATOR."/components/com_cssmapper/functions/helper.php");
		$db=JFactory::getDBO();
		$q = "SELECT * FROM #__cssmapper";
		$db->setQuery($q);
		$reg_expressions = $db->loadObjectList();
		if($reg_expressions)
		{
		
//$row->text = getSampleData();
//echo $row->text;die();	
	
			$uri = JFactory::getURI();	
			$url_query = $uri->getQuery();
			
			//add & to aid adding post variables below
			if($url_query)
			{
				$url_query = "&$url_query";
			}
		
			if( !empty( $_POST )) 
			{
				foreach( $_POST as $key => $val ) 
				{		
					if( is_array($val) ) 
					{
						$i = 0;
						foreach( $val as $value ) 
						{
							if(!(stristr($url_query,"&$key[$i]=") or stristr($url_query,"?$key[$i]=")))
							{
								$url_query .= "&$key[$i]=$value";
							}
							++$i;
						}
					} 
					else
					{
						if(!stristr($url_query,"&$key="))
						{
							$url_query .= "&$key=$val";
						}
					}	
				} 
			}

			foreach($reg_expressions as $reg_exp)
			{
				if($reg_exp->page_reg_exp and $reg_exp->src_css_class and $reg_exp->dest_css_class and $row->text)
				{
					if(preg_match("/".$reg_exp->page_reg_exp."/", $url_query))
					{
						$row->text = css_map($row->text, $reg_exp->src_css_class, $reg_exp->dest_css_class);
					}
				}	
			}
		}
	}	
	
//print_r($row->text);die();  
	
	return true;
}
