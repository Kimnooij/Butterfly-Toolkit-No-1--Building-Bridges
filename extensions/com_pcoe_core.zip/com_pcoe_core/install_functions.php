<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

function executePcoeSql()
{
	jimport('joomla.filesystem.file');
	$sql_path =  getPcoePath()."sql/ushahidi.sql";
	if(JFile::exists($sql_path))
	{
		$sql = JFile::read($sql_path);
		$dbprefix = getPcoeDbPrefix();
		$sql = add_dbprefix($sql, $dbprefix);
		$stmts = getQueries($sql);
		$status = executeQuery($stmts);
		//emptyUserTable();
		return $status;
	}
	else
	{
		echo "$sql_path file not detected <br />";
		echo "<strong>Failed to create PCOE tables</strong><br />";
		return false;
	}	
}

function add_dbprefix($sql, $dbprefix)
{
	$sql = createIfExistsStmt($sql, $dbprefix);
	$sql = createStmt($sql, $dbprefix);
	$sql = alterStmt($sql, $dbprefix);
	$sql = insertStmt($sql, $dbprefix);
	$sql = constraintStmt($sql, $dbprefix);
	$sql = removeComments($sql);
	
    return $sql;
}

function createIfExistsStmt($sql, $dbprefix)
{
    $pattern = "/create(\s+)table(\s+)if(\s+)not(\s+)exists(\s+)(`?)\w+(`?)/mi";
    $matches = match_pattern($pattern, $sql);
    if($matches)
    {      
	   $matches = array_filter($matches);
        $matches = array_unique($matches);
        foreach($matches as $match)
        {
            $pattern2 = "/create(\s+)table(\s+)if(\s+)not(\s+)exists(\s+)/mi";
			$table = preg_replace($pattern2, "", $match);
			$new_table = addTablePrefix($table, $dbprefix);
			$replacement = "CREATE TABLE IF NOT EXISTS $new_table ";
			$sql = preg_replace("/$match/", $replacement, $sql); 					
        }        
    }
   return $sql; 
}

function createStmt($sql, $dbprefix)
{
    $pattern = "/(create\s+)table(\s+)[^(if\s+)(not\s+)](`?)\w+(`?)/mi";
    $matches = match_pattern($pattern, $sql);
    if($matches)
    {      
	   $matches = array_filter($matches);
        $matches = array_unique($matches);
        foreach($matches as $match)
        {
            $pattern2 = "/(create\s+)table(\s+)/i";
			$table = preg_replace($pattern2, "", $match);
			$new_table = addTablePrefix($table, $dbprefix);
			$replacement = "CREATE TABLE IF NOT EXISTS $new_table ";
			$sql = preg_replace("/$match/", $replacement, $sql); 
        }        
    }	
   return $sql; 
}

function alterStmt($sql, $dbprefix)
{
    $pattern = "/(alter\s+)table(\s+)(`?)\w+(`?)/mi";
    $matches = match_pattern($pattern, $sql);
    if($matches)
    {      
	   $matches = array_filter($matches);
        $matches = array_unique($matches);
        foreach($matches as $match)
        {
            $pattern2 = "/(alter\s+)table(\s+)/i";
			$table = preg_replace($pattern2, "", $match);
			$new_table = addTablePrefix($table, $dbprefix);
			$replacement = "ALTER TABLE $new_table ";
			$sql = preg_replace("/$match/", $replacement, $sql); 
        }        
    }
   return $sql; 
}

function insertStmt($sql, $dbprefix)
{
    $pattern = "/insert(\s+)into(\s+)(`?)\w+(`?)/mi";
    $matches = match_pattern($pattern, $sql);
    if($matches)
    {      
		$matches = array_filter($matches);
        $matches = array_unique($matches);
        foreach($matches as $match)
        {
            $pattern2 = "/insert(\s+)into(\s+)/i";
			$table = preg_replace($pattern2, "", $match);
			$new_table = addTablePrefix($table, $dbprefix);
			$replacement = "INSERT INTO $new_table ";
			$sql = preg_replace("/$match/", $replacement, $sql); 
        }        
    }
   return $sql; 
}

function constraintStmt($sql, $dbprefix)
{
	$pattern = "/^(references\s+)|(\s(references)\s+)(`?)\w+(`?)(\s+)\(/mi";
    $matches = match_pattern($pattern, $sql);
    if($matches)
    {      
	   $matches = array_filter($matches);
        $matches = array_unique($matches);
        foreach($matches as $match)
        {
			$table = str_ireplace("references", "", $match);
			$table = str_replace("(", "", $table);
			$new_table = addTablePrefix($table, $dbprefix);
			$replacement = " REFERENCES $new_table (";
			$match = str_replace("(", "\(", $match);
			$sql = preg_replace("/$match/", $replacement, $sql);
        }        
    }
   return $sql; 
}

function addTablePrefix($table, $dbprefix)
{
	$table = str_replace("`", "", $table);
	$table = trim($table);
	$table = "`{$dbprefix}{$table}`";
	
	return $table;
}

function removeComments($sql)
{
	$pattern = "/--(.+)?/";	
	$sql = preg_replace($pattern, "", $sql);
	return $sql;
}

function match_pattern($pattern, $string)
{
	preg_match_all ( $pattern , $string , $matches );
    return $matches[0];
}

function getQueries($sql)
{
	$stmts = explode(';',$sql);			
	return $stmts;
}

function executeQuery($stmts)
{
	if(is_array($stmts))
	{
		$stmts = array_filter($stmts);
		$db=JFactory::getDBO();
		$db_setup_success = true;
		
		foreach($stmts as $query)
		{
			$query = trim($query);
			if($query)
			{			
				$db->setQuery($query);
				if(!$db->query())
				{
					echo "<strong>".$db->getErrorMsg()."</strong><br />";
					$db_setup_success = false;
				}
			}	
		}
		return $db_setup_success;
	}
	else
	{
		echo "No sql query executed <br />";
		return false;
	}	
}

function emptyUserTable()
{
	$db=JFactory::getDBO();
	$table_prefix = getPcoeDbPrefix();
	$q = "SELECT DISTINCT(`user`.id) FROM `{$table_prefix}users` as `user` 
			LEFT JOIN `{$table_prefix}roles_users` AS `usr_role`  
			ON `user`.id = `usr_role`.user_id  
			LEFT JOIN `{$table_prefix}roles` as `role` 
			ON `usr_role`.role_id = `role`.id  
			WHERE `role`.name = 'superadmin' OR `role`.name = 'admin'";
	$db->setQuery($q);
	$cids = $db->loadResultArray();
	if($cids)
	{
		$user_ids = implode(",", $cids);
		$q = "DELETE FROM `{$table_prefix}users` WHERE `id` IN ($user_ids)";
		$db->setQuery($q);
		if(!$db->query())
		{
			echo "There was a problem emptying the {$table_prefix}users table<br />";
			echo $db->getErrorMsg()."<br />";
		}
		$q = "DELETE FROM `{$table_prefix}roles_users` WHERE `user_id` IN ($user_ids)";
		$db->setQuery($q);
		if(!$db->query())
		{
			echo "There was a problem emptying the {$table_prefix}roles_users table<br />";
			echo $db->getErrorMsg()."<br />";
		}
	}
	
}

function getJoomlaConfig()
{
	require_once(JPATH_CONFIGURATION."/configuration.php");
	$config = new  JConfig;
	return $config;
}

function getDbPrefix()
{
	$config = getJoomlaConfig();
	return $config->dbprefix;
}

function getPcoeDbPrefix()
{
	$config = getJoomlaConfig();
	return $config->dbprefix."pcoe_";
}

function createConfigFile()
{
	jimport('joomla.filesystem.file');
	$config_path =  getPcoePath()."application/config/";
	$tmpl_file =  "config.template.php";	
	if(JFile::exists($config_path.$tmpl_file))
	{
		$config_template = JFile::read($config_path.$tmpl_file);
		$config_template = setConfigSiteDomain($config_template);
		$config_template = configDisableCompression($config_template);
		$config_template = addModulesToConfig($config_template);	
		if(writeFile($config_template, $config_path."config.php"))
		{
			echo "PCOE configuration file created <br />";
		}
		else
		{
			echo "<br>There was a problem creating the PCOE configuration file. Please copy the following code to " .  $config_path."config.php<br />";
			echo "<textarea style='width:100%;min-width:500px;' rows='15'>{$config_template}</textarea>";			
		}
	}
	else
	{
		echo "$config_path/config.template.php file not detected <br />";
		echo "<strong>Failed to create PCOE config file</strong><br />";
	}	
}

function setConfigSiteDomain($config_template)
{
	$pattern = "{\\\$config\['site_domain'\].*;}";
	$matchString = match_pattern($pattern, $config_template);	
	$siteDomain = JURI::root();
	$siteDomain = str_replace('http://', '', $siteDomain);
	$configSiteDomainReplace = "\$config['site_domain'] = '$siteDomain';";
	if($matchString)
	{
		$siteDomainLine = $matchString[0];		
		$config_template = str_replace($siteDomainLine, $configSiteDomainReplace, $config_template);
	}
	
	return $config_template;
}

function configDisableCompression($config_template)
{
	$pattern = "{\\\$config\[('|\")output_compression('|\")\].*;}";
	$matchString = match_pattern($pattern, $config_template);	
	$configCompressionReplace = "\$config['output_compression'] = FALSE;";
	if($matchString)
	{
		$configCompression = $matchString[0];		
		$config_template = str_replace($configCompression, $configCompressionReplace, $config_template);
	}
	
	return $config_template;
}

function addModulesToConfig($config_template)
{
	$pattern = "{\\\$config\[('|\")modules('|\")\](\s+)?=(\s+)?array(\s+)?\(}m";
	$setConfigModuleStr = match_pattern($pattern, $config_template);	
	$new_modules = array(
							"MODPATH.'kohana',      // Joomla",
							"MODPATH.'joomla',      // Joomla" 
						);	
	if($setConfigModuleStr)
	{
		$configModuleStr = $setConfigModuleStr[0];
		$add_module = $configModuleStr."\n";
		foreach($new_modules as $module)
		{
			$add_module .= "\t $module \n";
		}
		//$add_module .= $module_match;
		
		$config_template = str_replace($configModuleStr, $add_module, $config_template);
	}
	
	return $config_template;
}

function createDbaseConfigFile()
{
	jimport('joomla.filesystem.file');
	$config_path =  getPcoePath()."application/config/";
	$tmpl_file = "database.template.php";
	if(JFile::exists($config_path.$tmpl_file))
	{
		$database_template = JFile::read($config_path.$tmpl_file);
		$database_template = setDbaseInfo($database_template);
		if(writeFile($database_template, $config_path."database.php"))
		{
			echo "PCOE database configuration file created <br />";
		}
		else
		{
			echo "<br>There was a problem creating the PCOE database configuration file. Please copy the following code to " .  $config_path."database.php<br />";
			echo "<textarea style='width:100%;min-width:500px;' rows='15'>{$database_template}</textarea>";
		}
	}
	else
	{
		echo "<br>$config_path/database.template.php file not detected <br />";
		echo "<strong>Failed to create PCOE database config file</strong><br />";
	}	
}

function setDbaseInfo($database_template)
{
	$config = getJoomlaConfig();	

	$username_pattern = "{('|\")username('|\")}";
	$password_pattern = "{('|\")password('|\")}";
	$host_pattern = "{('|\")localhost('|\")}";
	$db_pattern = "{('|\")db('|\")}";
	$dbprefix_pattern = "{('|\")table_prefix('|\")(\s+)=>(\s+)?[^,]+,}";
	$type_pattern = "{('|\")mysql('|\")}";
	
	$username = $config->user;
	$password = $config->password;
	$host = $config->host;
	$database = $config->db;
	$dbprefix = getPcoeDbPrefix();
	
	$database_template = preg_replace($username_pattern, "'$username'", $database_template);
	$database_template = preg_replace($password_pattern, "'$password'", $database_template);
	$database_template = preg_replace($host_pattern, "'$host'", $database_template);
	$database_template = preg_replace($db_pattern, "'$database'", $database_template);
	$database_template = preg_replace($dbprefix_pattern, "'table_prefix' => '$dbprefix',", $database_template);
	$database_template = preg_replace($type_pattern, "'joomla'", $database_template);
	
	return $database_template;
}

function getPcoePath()
{
	return JPATH_ADMINISTRATOR."/components/com_pcoe/pcoe/";
}

function writeFile($content, $file_path) 
{
	jimport('joomla.filesystem.file');	
	//$content = str_replace("\\", "/",$content);
	if(!JFile::exists($file_path) or JFile::delete($file_path)==true)
		return JFile::write($file_path,$content);
		
	return false;
	/*
	if ($fp = fopen($file_path, "w+")) {
		fputs($fp, $content, strlen($content));
		fclose ($fp);
		return true;
	}
	else
		return false;
	*/
}

function disableHtaccessFile()
{
	jimport('joomla.filesystem.file');
	$htaccess_path = JPATH_ADMINISTRATOR."/components/com_pcoe/pcoe/";
	if(JFile::exists($htaccess_path.".htaccess"))
	{
		if(JFile::move($htaccess_path.".htaccess",$htaccess_path."disabled_htaccess.txt") == true)
		{
			echo "htaccess file disabled <br /> ";
		}
		else
		{
			echo "There was an error disabling PCOE htaccess file <br /> ";
		}
	}
}