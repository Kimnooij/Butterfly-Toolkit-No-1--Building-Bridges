<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


function com_pcoe_core_install()
{
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	jimport('joomla.filesystem.archive');
	jimport('joomla.filesystem.path');
	// Get the uploaded file information
	$userfile = JRequest::getVar('install_package', null, 'files', 'array' );

	$installer=JInstaller::getInstance();
	
	$tmp_source= $installer->getPath('source');
	
	// Build the appropriate paths
	$config =& JFactory::getConfig();
	$ushahidi_zip_file='pcoe.zip';
	$tmp_dest 	= $tmp_source.DS.$ushahidi_zip_file;
	$extractdir=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe';
	// Unpack the downloaded package file
	echo "Start extract PCOE from {$tmp_dest} to {$extractdir}<br />";
	$result=JArchive::extract( $tmp_dest, $extractdir);
	echo "Stop extract PCOE from {$tmp_dest} to {$extractdir}<br />";
	require_once(JPATH_ADMINISTRATOR."/components/com_pcoe_core/permission_settings.php");
	permission_settings::set_folder_permission();
	
	require_once(JPATH_ADMINISTRATOR."/components/com_pcoe_core/install_functions.php");
	if(JFolder::exists(getPcoePath()))
	{
		echo '<br /><br />';
    if(executePcoeSql())
		{	
			echo "PCOE tables created <br />";
		}	
		createConfigFile();
		createDbaseConfigFile();
		disableHtaccessFile();
		
		permission_settings::set_config_files_permission();
		
		echo "<br />";
	}
	return true;

}
?>