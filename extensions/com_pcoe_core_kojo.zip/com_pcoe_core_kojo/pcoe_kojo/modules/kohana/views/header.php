<?php 
/**
 * Header view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=7" />
	<title><?php echo $site_name; ?></title>
	<?php
	/*-----Blocked by Korn Serey -----------------------*/
	echo html::stylesheet('media/css/all', '', true);
	/*----------------------------------------------------*/
	echo html::stylesheet('media/css/jquery-ui-themeroller', '', true);

/*	
	echo "<!--[if lt IE 7]>".
		html::stylesheet('media/css/ie6', '', true)
		."<![endif]-->";
*/
	
	$document = & JFactory::getDocument();
	$document->setMetaData('X-UA-Compatible', 'IE=7',true);
	
	ereg('MSIE ([0-9]\.[0-9])',$_SERVER['HTTP_USER_AGENT'],$reg);
	if(isset($reg[1]) and intval($reg[1] < 7))
	{
		echo html::stylesheet('media/css/ie6', '', true);
	}
		
	// Load OpenLayers before jQuery!
	if ($map_enabled)
	{
		echo html::script('media/js/OpenLayers', true);
		echo "<script type=\"text/javascript\">
			OpenLayers.ImgPath = '".url::base().'media/img/openlayers/'."';
			</script>";
	}	
	
	// Load jQuery
	echo html::script('media/js/jquery', true);
	echo html::script('media/js/jquery.ui.min', true);
	
	// Other stuff to load only we have the map enabled
	if ($map_enabled)
	{
		echo $api_url . "\n";
		if ($main_page) {
			echo html::script('media/js/selectToUISlider.jQuery', true);
			echo html::script('media/js/jquery.flot', true);
			echo html::script('media/js/timeline', true);
			
		/*	
			echo "<!--[if IE]>".
				html::script('media/js/excanvas.pack', true)
				."<![endif]-->";
		
		*/

			if( eregi( "MSIE" , $_SERVER['HTTP_USER_AGENT'] ) )
			{
				echo html::script('media/js/excanvas.pack', true);
			}
		}
	}
	if ($validator_enabled) 
	{
		echo html::script('media/js/jquery.validate.min');
	}
	if ($photoslider_enabled)
	{
		echo html::script('media/js/photoslider');
		echo html::stylesheet('media/css/photoslider');
	}
	if( $videoslider_enabled )
	{
		echo html::script('media/js/coda-slider.pack');
		echo html::stylesheet('media/css/videoslider');
	}
	if ($allow_feed == 1) {
		echo "<link rel=\"alternate\" type=\"application/rss+xml\" href=\"http://" . $_SERVER['SERVER_NAME'] . "/feed/\" title=\"RSS2\" />";
	}
	?>
	<script type="text/javascript">
		<?php echo $js . "\n"; ?>
	</script>
</head>
<body>
