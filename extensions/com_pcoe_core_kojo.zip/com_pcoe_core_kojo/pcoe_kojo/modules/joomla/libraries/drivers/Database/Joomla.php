<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * Joomla Database Driver
 *
 * @package    Core
 * @author     Sankuru Team
 * 
 * returns the joomla database connection  
 */
class Database_Joomla_Driver extends Database_Mysql_Driver {

	/**
	 * Sets the config for the class.
	 *
	 * @param  array  database configuration
	 */
	public function __construct($config)
	{
		$this->db_config = $config;

		Kohana::log('debug', 'MySQL Database Driver Initialized');
	}

	/**
	 * Keep open the database connection.
	 */	
	public function __destruct(){}

  /**
	 * Return the Joomla database connection
	 */
	public function connect()
	{   
    //return link if already exists  
    if (is_resource($this->link))
    	return $this->link;
    	
    global $mainframe;    
    $option['driver'] = $mainframe->getCfg( 'dbtype' );
    $option['host'] = $mainframe->getCfg( 'host' );
    $option['user'] = $mainframe->getCfg( 'user' );
    $option['password'] = $mainframe->getCfg( 'password' );
    $option['database'] = $mainframe->getCfg( 'db' );
    $option['prefix'] = $mainframe->getCfg( 'dbprefix' );
    
    $db = & JDatabase::getInstance($option);
   
    $this->link = $db->_resource;
    return $this->link;
	}

} // End Database_Joomla_Driver Class


