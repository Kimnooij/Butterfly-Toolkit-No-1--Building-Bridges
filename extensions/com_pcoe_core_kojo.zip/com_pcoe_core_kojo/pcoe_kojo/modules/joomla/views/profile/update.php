<?php 
/**
 * Reports submit view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
?>
		<div id="content">
			<div class="content-bg">
				<!-- start report form block -->
				<?php print form::open(NULL, array('enctype' => 'multipart/form-data', 'id' => 'updateForm', 'name' => 'updateForm')); ?>
				<input type="hidden" name="save" id="save" value="">
			
				<div class="big-block">
					<div class="big-block-top">
						<div class="big-block-bottom">
							
					<!--div class="report-form"-->
						<?php
						if ($form_error) {
						?>
							<!-- red-box -->
							<div class="red-box">
								<h3>Error!</h3>
								<ul>
								<?php
								foreach ($errors as $error_item => $error_description)
								{
									// print "<li>" . $error_description . "</li>";
									print (!$error_description) ? '' : "<li>" . $error_description . "</li>";
								}
								?>
								</ul>
							</div>
						<?php
						}

						if ($form_saved) {
						?>
							<!-- green-box -->
							<div class="green-box">
								<h3><?php echo Kohana::lang('pcoe.report_saved'); ?></h3>
							</div>
						<?php
						}
						?>
						<div class="profile-head">
							<h3 class="no-background"><?php echo $id ? Kohana::lang('pcoe.edit_update') : Kohana::lang('pcoe.new_update'); ?></h3>
							
						</div>
						<!-- f-col -->
						<div class="f-col">
							<div class="pcoe-profile_update">
		                    	<div class="report_row">
		                        	<h4><?php echo Kohana::lang('ui_main.reports_title'); ?></h4>
									<?php print form::input('incident_title', $form['incident_title'], ' class="text long"'); ?>
		                        </div>
		                        <div class="report_row">
		                        	<h4><?php echo Kohana::lang('ui_main.reports_description'); ?></h4>
									<?php print form::textarea('incident_description', $form['incident_description'], ' rows="10" class="textarea long" ') ?>
		                        </div>
								<div class="report_row hide" id="datetime_default">
									<h4><a href="#" id="date_toggle" class="show-more"><?php echo Kohana::lang('pcoe.modify_date'); ?></a><?php echo Kohana::lang('pcoe.date_time'); ?>: 
									<?php echo "Today at ".$form['incident_hour']
										.":".$form['incident_minute']." ".$form['incident_ampm']; ?></h4>
								</div>
								<div class="report_row" id="datetime_edit">
		                       	  <div class="date-box">
		                            	<h4><?php echo Kohana::lang('ui_main.reports_date'); ?></h4>
										<?php print form::input('incident_date', $form['incident_date'], ' class="text short"'); ?>								
										<script type="text/javascript">
											jQuery().ready(function() {
												jQuery("#incident_date").datepicker({ 
												    showOn: "both", 
												    buttonImage: "<?php echo url::base() ?>media/img/icon-calendar.gif", 
												    buttonImageOnly: true 
												});
											});
									    </script>
		                          </div>
		                          <div class="time">
		                            	<h4><?php echo Kohana::lang('ui_main.reports_time'); ?></h4>
						    		  	<?php
										for ($i=1; $i <= 12 ; $i++) { 
											$hour_array[sprintf("%02d", $i)] = sprintf("%02d", $i); 	// Add Leading Zero
										}
										for ($j=0; $j <= 59 ; $j++) { 
											$minute_array[sprintf("%02d", $j)] = sprintf("%02d", $j);	// Add Leading Zero
										}
										$ampm_array = array('pm'=>'pm','am'=>'am');
										print form::dropdown('incident_hour',$hour_array,$form['incident_hour']);
										print '<span class="dots">:</span>';
										print form::dropdown('incident_minute',$minute_array,$form['incident_minute']);
										print '<span class="dots">:</span>';
										print form::dropdown('incident_ampm',$ampm_array,$form['incident_ampm']);
										?>
		                          </div>
		                          <div style="clear:both; display:block;" id="incident_date_time"></div>
		                        </div>
		                        
										
								<div style="clear:both;"></div>
		                  	</div>
							 <div class="report_bottom">
		                        <div class="report_row">
		                        	<input name="submit" type="submit" value="<?php echo Kohana::lang('ui_main.reports_btn_submit'); ?>" class="btn_blue" />
		                        </div>
		                    </div>
					  </div>
					
				</div>	
				<?php print form::close(); ?>
				<!-- end report form block -->
			</div>
		</div>
