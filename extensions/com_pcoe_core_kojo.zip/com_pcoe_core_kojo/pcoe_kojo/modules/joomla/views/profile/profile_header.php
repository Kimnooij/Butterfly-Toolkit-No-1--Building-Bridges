<?php 
/**
 * Layout for the admin interface.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=7" />
	<title><?php echo Kohana::lang('pcoe.site_title'); ?></title>
	<?php

	//echo html::stylesheet('media/css/admin/all', '', true);
	echo html::stylesheet('media/css/all', '', true);
	echo html::stylesheet('media/css/jquery-ui-themeroller', '', true);
	echo "<!--[if lt IE 7]>".
		html::stylesheet('media/css/ie6', '', true)
		."<![endif]-->";
	
	// Load OpenLayers
	if ($map_enabled)
	{	
		echo html::script('media/js/OpenLayers', true);
		echo $api_url . "\n";
		echo "<script type=\"text/javascript\">
			OpenLayers.ImgPath = '".url::base().'media/img/openlayers/'."';
			</script>";
	}
	
	// Load jQuery
	echo html::script('media/js/jquery', true);
	echo html::script('media/js/jquery.form', true);
	echo html::script('media/js/jquery.validate.min', true);
	echo html::script('media/js/jquery.ui.min', true);
	echo html::script('media/js/selectToUISlider.jQuery', true);
	
	// Load Flot
	if ($flot_enabled)
	{
		echo html::script('media/js/jquery.flot', true);
		echo html::script('media/js/excanvas.pack', true);
		echo html::script('media/js/timeline.js', true);
	}
	
	// Load ColorPicker
	if ($colorpicker_enabled)
	{
		echo html::stylesheet('media/css/colorpicker', '', true);
		echo html::script('media/js/colorpicker', true);
	}
	?>
	<script type="text/javascript" charset="utf-8">
		<?php echo $js . "\n"; ?>
	</script>
</head>

<body>

	<div id="content">
		<div id="content-background">
			<div style="padding:10px">
			<!-- nav-holder -->
			<div class="profile-nav-holder">
				<!-- main-nav -->
				<ul class="profile-main-nav">
					<li><a href="<?php echo url::base() ?>profile/dashboard" <?php if($this_page=="dashboard") echo "class=\"active\"" ;?>>
						<?php echo Kohana::lang('pcoe.dashboard_tab');?>
						</a></li>
					<li><a href="<?php echo url::base() ?>profile/project" <?php if($this_page=="project") echo "class=\"active\"" ;?>>
						<?php echo Kohana::lang('pcoe.project_tab');?>
						</a></li>
					<li><a href="<?php echo url::base() ?>profile/update" <?php if($this_page=="update") echo "class=\"active\"" ;?>>
						<?php echo Kohana::lang('pcoe.update_tab');?>
						</a></li>
					<li><a href="<?php echo url::base() ?>profile/comments" <?php if($this_page=="comments") echo "class=\"active\"" ;?>>
						<?php echo Kohana::lang('pcoe.comments_tab');?>
						</a></li>
				</ul>
			</div>
			
			<div class="profile-content">
		<!--/div-->
	

