<?php 
/**
 * Comments view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
?>
	
			<div class="bg">				
				<!-- report-table -->
					<div class="profile-table-holder">
						<h2><?php echo Kohana::lang('pcoe.profile_comment_project_comment_title'); ?></h2>
						
						<table class="profile-table">
							<thead>
								<tr>
									<th class="profile-comment-col-1">
										<?php echo Kohana::lang('pcoe.profile_comment_details'); ?>
									</th>
									<th class="profile-comment-col-2">
										<?php echo Kohana::lang('pcoe.profile_comment_date'); ?>
									</th>
									<th class="profile-comment-col-3">
										<?php echo Kohana::lang('pcoe.profile_comment_actions'); ?>
									</th>
								</tr>
							</thead>
							<tfoot>
								<tr class="foot">
									<td colspan="3">
										<?php echo $pagination; ?>
									</td>
								</tr>
							</tfoot>
							<tbody>
								<?php
							
								if($project_available)
								{
									$project = $project_info['project'];
									$category = $project_info['category'];
									$author = $project_info['user_name'];
									
									$title = $project->incident_title;
									$description = text::limit_chars($project->incident_description, 50, "...", true);
									$date = date('Y-m-d', strtotime($project->incident_dateadd));
									$location = $project->location_name;
									$incident_id = $project->incident_id;
								
									$description = $description."<a href='".url::base() . 'profile/project/edit/' . $incident_id."'>".Kohana::lang('pcoe.more')."</a>";
									
									if($project_info['has_comment'])
									{
										$title .= " (".$project_info['has_comment'].")";
									}	
								?>
									<tr>
										<td class="profile-comment-col-1">
											<div class="profile-post">
												<?php
												if ($title != "")
												{
												?>
													<div class="profile-comment_incident">
														<?php echo Kohana::lang('pcoe.profile_comment_project_lbl'); ?>- 
														<strong>
															<a href="<?php echo url::base() . 'profile/project/edit/' . $incident_id; ?>"><?php echo $title; ?></a>
														</strong>
													</div>
												<?php
												}
												?>
												<p><?php echo $description; ?></p>
											</div>
											<ul class="profile-info">
												<li class="profile-none-separator">
													<?php echo Kohana::lang('pcoe.profile_comment_location'); ?>: 
													<strong><?php echo $location; ?></strong>
												</li>
												<li>
													<?php echo Kohana::lang('pcoe.profile_comment_submitted_by'); ?>: 
													<strong><?php echo $author; ?></strong>
												</li>
												<li class="profile-category_list">
													<?php echo Kohana::lang('pcoe.profile_comment_category'); ?>: 
													<strong><?php echo $category; ?></strong>
												</li>
											</ul>
										</td>
										<td class="profile-comment-col-2"><?php echo $date; ?></td>
										<td class="profile-comment-col-3">
									<?php
										if($project_info['has_comment'])
										{
									?>
											<a href="<?php echo url::base().'profile/comments/view/incident/'.$incident_id;?>">
												<?php echo Kohana::lang('pcoe.profile_view_comment'); ?></a>
									<?php
										}
										else
										{
									?>	
											<?php echo Kohana::lang('pcoe.profile_no_comment'); ?>
								<?php }?>
										</td>
									</tr>
								<?php
																
									foreach ($updates as $update)
									{
										$update_id = $update->id;
										$description = text::limit_chars($update->update_description, 50, "...", true);
										$date = date('Y-m-d', strtotime($update->update_date));											
										$title = $update->update_title;
																			
										$description = $description."<a href='".url::base() . 'profile/update/edit/' . $update_id."'>".Kohana::lang('pcoe.more')."</a>";
																												
										if($comment_count[$update_id])
										{
											$title .= " (".$comment_count[$update_id].")";
										}
										?>
										<tr>
											<td class="profile-comment-col-1">
												<div class="profile-post">
													<?php
													if ($title != "")
													{
														?><div class="profile-comment_incident">
															<?php echo Kohana::lang('pcoe.profile_comment_update'); ?>: 
															<strong><a href="<?php echo url::base() . 'profile/update/edit/' . $update_id; ?>">
															<?php echo $title; ?>
															</a></strong>
														</div>
												<?php
													}
												?>
													<p><?php echo $description; ?></p>
												</div>
											</td>
											<td class="profile-comment-col-2"><?php echo $date; ?></td>
											<td class="profile-comment-col-3">
										<?php
											if($comment_count[$update_id])
											{
										?>
												<a href="<?php echo url::base().'profile/comments/view/update/'.$update_id;?>">
													<?php echo Kohana::lang('pcoe.profile_view_comment'); ?>
												</a>
										<?php
											}
											else
											{
										?>	
												<?php echo Kohana::lang('pcoe.profile_no_comment'); ?>!
										<?php }?>	
											</td>
										</tr>
										<?php
									}								
								}
								else			
								{
								?>
									<tr>
										<td colspan="4" class="col">
											<h3><?php echo Kohana::lang('pcoe.profile_no_project_msg'); ?>!</h3>
										</td>
									</tr>
								<?php	
								}								
								?>
							</tbody>
						</table>
					</div>
			</div>
