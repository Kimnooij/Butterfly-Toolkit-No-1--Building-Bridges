<?php 
/**
 * Reports submit view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
?>
		<!--div id="content"-->
			<div class="content-bg">
				<!-- start report form block -->
				<?php print form::open(NULL, array('enctype' => 'multipart/form-data', 'id' => 'reportForm', 'name' => 'reportForm')); ?>
				<input type="hidden" name="save" id="save" value="">
				<input type="hidden" name="location_id" id="location_id" value="<?php print $form['location_id']; ?>">
				<input type="hidden" name="form_id" id="form_id" value="<?php print $form['form_id']; ?>">
			<?php //* ?>	
				<div class="big-block">
					<div class="big-block-top">
						<div class="big-block-bottom">
							
					<!--div class="report-form"-->
						<?php
						if ($form_error) {
						?>
							<div class="profile-msg_holder">
								<div class="profile-msg_holder_inner">
								<!-- red-box -->
									<div class="profile-red-box">
										<h3><?php echo Kohana::lang('pcoe.error'); ?>!</h3>
										<ul>
										<?php
											foreach ($errors as $error_item => $error_description)
											{
												// print "<li>" . $error_description . "</li>";
												print (!$error_description) ? '' : "<li>" . $error_description . "</li>";
											}
										?>
										</ul>
									</div>
								</div>	
							</div>
							
						<?php
						}

						if ($display_msg) {
						?>
							<div class="profile-msg_holder">
								<div class="profile-msg_holder_inner">
								<!-- green-box -->
									<div class="profile-green-box">
										<h3><?php echo $display_msg ?></h3>
									</div>
								</div>	
							</div>
						<?php
						}
						?>
						<div class="profile-head">
							<h3 class='no-background'><?php echo $id ? Kohana::lang('pcoe.edit_report') : Kohana::lang('pcoe.report_project'); ?></h3>
						</div>
						<!-- f-col -->
						<div class="f-col">
							<div class="row">
								<div class="profile-btns" style="float:right;">
									<ul>
										<li><a href="#" class="profile-btn_save" onclick="document.reportForm.getElementById('save').value=1;submit()"><?php echo Kohana::lang('pcoe.project_save'); ?></a></li>
										<li><a href="#" class="profile-btn_save_close" onclick="javascript:submit()"><?php echo Kohana::lang('pcoe.project_save_close'); ?></a></li>
										<li><a href="<?php echo url::base().'profile/dashboard/';?>" class="profile-btns_red"><?php echo Kohana::lang('pcoe.project_cancel'); ?></a>&nbsp;&nbsp;&nbsp;</li>
										
									</ul>
								</div>
								<!--h4>Form <span>(Select A Form Type)</span></h4>
								<span class="sel-holder">
									<?php //print form::dropdown('form_id', $forms, $form['form_id'],
										//' onchange="formSwitch(this.options[this.selectedIndex].value, \''.$id.'\')"') ?>
								</span-->
								<div id="form_loader" style="float:left;"></div>
							</div>
						
							<div class="report_left">
		                    	<div class="report_row">
		                        	<h4><?php echo Kohana::lang('ui_main.reports_title'); ?></h4>
									<?php print form::input('incident_title', $form['incident_title'], ' class="text long"'); ?>
		                        </div>
		                        <div class="report_row">
		                        	<h4><?php echo Kohana::lang('ui_main.reports_description'); ?></h4>
									<?php print form::textarea('incident_description', $form['incident_description'], ' rows="10" class="textarea long" ') ?>
		                        </div>
								<div class="report_row" id="datetime_default">
									<h4><a href="#" id="date_toggle" class="show-more"><?php echo Kohana::lang('pcoe.modify_date'); ?></a><?php echo Kohana::lang('pcoe.date_time'); ?>: 
									<?php echo "Today at ".$form['incident_hour']
										.":".$form['incident_minute']." ".$form['incident_ampm']; ?></h4>
								</div>
		                        <div class="report_row hide" id="datetime_edit">
		                       	  <div class="date-box">
		                            	<h4><?php echo Kohana::lang('ui_main.reports_date'); ?></h4>
										<?php print form::input('incident_date', $form['incident_date'], ' class="text short"'); ?>								
										<script type="text/javascript">
											jQuery().ready(function() {
												jQuery("#incident_date").datepicker({ 
												    showOn: "both", 
												    buttonImage: "<?php echo url::base() ?>media/img/icon-calendar.gif", 
												    buttonImageOnly: true 
												});
											});
									    </script>
		                          </div>
		                          <div class="time">
		                            	<h4><?php echo Kohana::lang('ui_main.reports_time'); ?></h4>
						    		  	<?php
										for ($i=1; $i <= 12 ; $i++) { 
											$hour_array[sprintf("%02d", $i)] = sprintf("%02d", $i); 	// Add Leading Zero
										}
										for ($j=0; $j <= 59 ; $j++) { 
											$minute_array[sprintf("%02d", $j)] = sprintf("%02d", $j);	// Add Leading Zero
										}
										$ampm_array = array('pm'=>'pm','am'=>'am');
										print form::dropdown('incident_hour',$hour_array,$form['incident_hour']);
										print '<span class="dots">:</span>';
										print form::dropdown('incident_minute',$minute_array,$form['incident_minute']);
										print '<span class="dots">:</span>';
										print form::dropdown('incident_ampm',$ampm_array,$form['incident_ampm']);
										?>
		                          </div>
		                          <div style="clear:both; display:block;" id="incident_date_time"></div>
		                        </div>
		                        <div class="report_row">
		                        	<h4><?php echo Kohana::lang('ui_main.reports_categories'); ?></h4>
							    	<div class="report_category" id="categories">
										                                        
                                        <?php
                                        //format categories for 2 column display
                                        $this_col = 1; // First column
		                                $maxper_col = round($categories_total/2); // Maximum number of elements per column
										
										$i = 1; // Element Count
                                        foreach ($categories as $category => $category_extra)
                                        {
                                            $category_title = $category_extra[0];
                                            $category_color = $category_extra[1];
                                            if ($this_col == 1) 
                                                echo "<ul>";
                                   
                                            if (!empty($selected_categories) 
                                                && in_array($category, $selected_categories)) {
                                                $category_checked = TRUE;
                                            }
                                            else
                                            {
                                                $category_checked = FALSE;
                                            }
                                                                                                            
                                            echo "\n<li><label>";
                                            echo form::checkbox('incident_category[]', $category, $category_checked, ' class="check-box"');
                                            echo "$category_title";
                                            echo "</label></li>";
                                    
                                            if ($this_col == $maxper_col || $i == count($categories)) 
		                                        print "</ul>\n";

		                                    if ($this_col < $maxper_col)
		                                    {
		                                        $this_col++;
		                                    } 
		                                    else 
		                                    {
		                                        $this_col = 1;
		                                    }
											$i++;
                                        }

                                        ?>
                                       
									</div>
		                        </div>
							</div>
						
						
		               	  	<div class="report_right">
		                    	
								<div class="incident-location">
									<h4><?php echo Kohana::lang('pcoe.incident_location'); ?></h4>
									<div class="location-info">
										<span><?php echo Kohana::lang('pcoe.map_latitude'); ?>:
											<?php print form::input('latitude', $form['latitude'], ' class="text"'); ?>
										</span>
										<span><?php echo Kohana::lang('pcoe.map_logitude'); ?>:
											<?php print form::input('longitude', $form['longitude'], ' class="text"'); ?>
										</span>
									</div>
								</div>	
		                        <div class="report_row">
		                        	<div id="divMap" class="report_map"></div>
									<div class="report-find-location">
										<?php print form::input('location_find', '', ' title="City, State and/or Country" class="findtext"'); ?>
										<div style="float:left;margin:9px 0 0 5px;"><input type="button" name="button" id="button" value="Find Location" class="btn_gray btn_find" /></div>
										<div id="find_loading" class="report-find-loading"></div>
										<div style="clear:both;" id="find_text"><?php echo Kohana::lang('pcoe.location_click_on_map'); ?></div>
									</div>
		                        </div>
								
		                        <div class="report_row">
		                        	<h4><?php echo Kohana::lang('ui_main.reports_location_name'); ?><br /><span><?php echo Kohana::lang('pcoe.location_name_example'); ?></span></h4>
									<?php print form::input('location_name', $form['location_name'], ' class="text long"'); ?>
		                        </div>

								<!-- News Fields -->
								<div id="divNews" class="report_row">
			                        <h4><?php echo Kohana::lang('ui_main.reports_news'); ?></h4>
									<?php
									$this_div = "divNews";
									$this_field = "incident_news";
									$this_startid = "news_id";
									$this_field_type = "text";

									if (empty($form[$this_field]))
									{
										$i = 1;
										print "<div class=\"report_row\">";
										print form::input($this_field . '[]', '', ' class="text long2"');
										print "<a href=\"#\" class=\"add\" onClick=\"addFormField('$this_div','$this_field','$this_startid','$this_field_type'); return false;\">add</a>";
										print "</div>";
									}
									else
									{
										$i = 0;
										foreach ($form[$this_field] as $value) {									
											print "<div class=\"report_row\" id=\"$i\">\n";
											
											print form::input($this_field . '[]', $value, ' class="text long2"');
											print "<a href=\"#\" class=\"add\" onClick=\"addFormField('$this_div','$this_field','$this_startid','$this_field_type'); return false;\">add</a>";
											if ($i != 0)
											{
												print "<a href=\"#\" class=\"rem\"  onClick='removeFormField(\"#" . $this_field . "_" . $i . "\"); return false;'>remove</a>";
											}
											print "</div>\n";
											$i++;
										}
									}
									print "<input type=\"hidden\" name=\"$this_startid\" value=\"$i\" id=\"$this_startid\">";
									?>
								</div>


								<!-- Video Fields -->
								<div id="divVideo" class="report_row">
									<h4><?php echo Kohana::lang('ui_main.reports_video'); ?></h4>
									<?php
									$this_div = "divVideo";
									$this_field = "incident_video";
									$this_startid = "video_id";
									$this_field_type = "text";

									if (empty($form[$this_field]))
									{
										$i = 1;
										print "<div class=\"report_row\">";
										print form::input($this_field . '[]', '', ' class="text long2"');
										print "<a href=\"#\" class=\"add\" onClick=\"addFormField('$this_div','$this_field','$this_startid','$this_field_type'); return false;\">add</a>";
										print "</div>";
									}
									else
									{
										$i = 0;
										foreach ($form[$this_field] as $value) {									
											print "<div class=\"report_row\" id=\"$i\">\n";
											
											print form::input($this_field . '[]', $value, ' class="text long2"');
											print "<a href=\"#\" class=\"add\" onClick=\"addFormField('$this_div','$this_field','$this_startid','$this_field_type'); return false;\">add</a>";
											if ($i != 0)
											{
												print "<a href=\"#\" class=\"rem\"  onClick='removeFormField(\"#" . $this_field . "_" . $i . "\"); return false;'>remove</a>";
											}
											print "</div>\n";
											$i++;
										}
									}
									print "<input type=\"hidden\" name=\"$this_startid\" value=\"$i\" id=\"$this_startid\">";
									?>
								</div>
								
								
								<!-- Photo Fields -->
								<div class="row link-row">
									<h4><?php echo Kohana::lang('pcoe.upload_photos'); ?></h4>
									<?php								
	    								
										if ($incident != "0")
										{
											// Retrieve Media
											foreach($incident->media as $photo) 
											{
												if ($photo->media_type == 1)
												{
													print "<div class=\"report_thumbs\" id=\"photo_". $photo->id ."\">";
													print "<img src=\"" . url::base() . "media/uploads/" . $photo->media_thumb . "\" >";
													print "&nbsp;&nbsp;<a href=\"#\" onClick=\"deletePhoto('". $photo->id ."', 'photo_". $photo->id ."'); return false;\" >Delete</a>";
													print "</div>";
												}
											}
										}
									
				                    ?>
								</div>
								<div id="divPhoto" class="report_row">
									<h4><?php echo Kohana::lang('ui_main.reports_photos'); ?></h4>
									<?php
									$this_div = "divPhoto";
									$this_field = "incident_photo";
									$this_startid = "photo_id";
									$this_field_type = "file";

									if (empty($form[$this_field]['name'][0]))
									{
										$i = 1;
										print "<div class=\"report_row\">";
										print form::upload($this_field . '[]', '', ' class="file long2"');
										print "<a href=\"#\" class=\"add\" onClick=\"addFormField('$this_div','$this_field','$this_startid','$this_field_type'); return false;\">add</a>";
										print "</div>";
									}
									else
									{
										$i = 0;
										foreach ($form[$this_field]['name'] as $value) 
										{
											print "<div class=\"report_row\" id=\"$i\">\n";
											
											// print "\"<strong>" . $value . "</strong>\"" . "<BR />";
											print form::upload($this_field . '[]', $value, ' class="file long2"');
											print "<a href=\"#\" class=\"add\" onClick=\"addFormField('$this_div','$this_field','$this_startid','$this_field_type'); return false;\">add</a>";
											if ($i != 0)
											{
												print "<a href=\"#\" class=\"rem\"  onClick='removeFormField(\"#" . $this_field . "_" . $i . "\"); return false;'>remove</a>";
											}
											print "</div>\n";
											$i++;
										}
									}
									print "<input type=\"hidden\" name=\"$this_startid\" value=\"$i\" id=\"$this_startid\">";
									?>
								</div>
										
								<div style="clear:both;"></div>
		                  	</div>
                
					  </div>
					<!--/div-->
				</div></div></div>	
				<!--/div-->
				<?php print form::close(); ?>
				<!-- end report form block -->
			</div>
		<!--/div-->
