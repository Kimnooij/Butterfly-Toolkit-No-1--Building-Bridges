/**
 * Edit update js file.
 *
 * Handles javascript stuff related to edit report function.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

		

		// Date Picker JS
		jQuery(document).ready(function() {
			jQuery("#incident_date").datepicker({ 
			    showOn: "both", 
			    buttonImage: "<?php echo url::base() ?>media/img/icon-calendar.gif", 
			    buttonImageOnly: true 
			});
		});
		
		jQuery(document).ready(function() {			
						
			/* Form Actions */
			// Action on Save Only
			jQuery('.profile-btn_save').live('click', function () {
				jQuery("#save").attr("value", "1");
				jQuery(this).parents("form").submit();
				return false;
			});
			
			jQuery('.profile-btn_save_close').live('click', function () {
				jQuery(this).parents("form").submit();
				return false;
			});
			
			// Prevent Enter Button Submit
			jQuery("#reportForm").bind("keypress", function(e) {
				if (e.keyCode == 13) return false;
			});
			
			// Toggle Date Editor
			jQuery('a#date_toggle').click(function() {
		    	jQuery('#datetime_edit').show(400);
				jQuery('#datetime_default').hide();
		    	return false;
			});
		});
		
		