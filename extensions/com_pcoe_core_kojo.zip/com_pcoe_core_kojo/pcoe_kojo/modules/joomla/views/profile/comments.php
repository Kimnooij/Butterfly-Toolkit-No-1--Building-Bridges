<?php 
/**
 * Comments view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
?>
			<div class="bg">
				<h2><?php echo $title; ?> <span>(<?php echo $total_items; ?>)</span></h2>

				<?php
				if ($form_error)
				{
				?>
					<!-- red-box -->
					<div class="red-box">
						<h3><?php echo Kohana::lang('pcoe.error'); ?>!</h3>
						<ul><?php echo Kohana::lang('pcoe.profile_comment_check_item_err'); ?></ul>
					</div>
				<?php
				}

				if ($form_saved)
				{
				?>
					<!-- green-box -->
					<div class="green-box" id="submitStatus">
						<h3><?php echo Kohana::lang('pcoe.profile_comment_comment'); ?> <?php echo $form_action; ?> 
							<a href="#" id="hideMessage" class="hide">
								<?php echo Kohana::lang('pcoe.profile_comment_hide_msg'); ?>
							</a>
						</h3>
					</div>
				<?php
				}
				?>
				<!-- report-table -->
				<?php print form::open(NULL, array('id' => 'commentMain', 'name' => 'commentMain')); ?>
					<input type="hidden" name="action" id="action" value="">
					<input type="hidden" name="comment_id[]" id="comment_single" value="">
					<div class="profile-table-holder">
						<table class="profile-table">
							<thead>
								<tr>
									<!--th class="col-1"><input id="checkallcomments" type="checkbox" class="check-box" onclick="CheckAll( this.id, 'comment_id[]' )" /></th-->
									<th class="profile-comment-col-1"><?php echo Kohana::lang('pcoe.profile_comment_details'); ?></th>
									<th class="profile-comment-col-2"><?php echo Kohana::lang('pcoe.profile_comment_date'); ?></th>
									<th class="profile-comment-col-3"><?php echo Kohana::lang('pcoe.profile_comment_actions'); ?></th>
								</tr>
							</thead>
							<tfoot>
								<tr class="foot">
									<td colspan="4">
										<?php echo $pagination; ?>
									</td>
								</tr>
							</tfoot>
							<tbody>
								<?php
								if ($total_items == 0)
								{
								?>
									<tr>
										<td colspan="4" class="col">
											<h3><?php echo Kohana::lang('pcoe.profile_comment_no_result_to_display'); ?>!</h3>
										</td>
									</tr>
								<?php	
								}
								
								foreach ($comments as $comment)
								{
									$comment_id = $comment->id;
									$comment_author = $comment->comment_author;
									$comment_description = $comment->comment_description;
									$comment_email = $comment->comment_email;
									$comment_ip = $comment->comment_ip;
									$comment_active = $comment->comment_active;
									$comment_spam = $comment->comment_spam;
									$comment_rating = $comment->comment_rating;
									$comment_date = date('Y-m-d', strtotime($comment->comment_date));
									
									?>
									<tr>
										<td class="profile-comment-col-1">
											<div class="post">
												<h4><?php echo $comment_author; ?></h4>
											<?php
												if ($incident_title != "")
												{
											?>
													<div class="profile-comment_incident">
														<?php echo Kohana::lang('pcoe.profile_comment_response_to'); ?>: 
														<strong>
															<a href="<?php echo url::base() . $incident_link; ?>">
																<?php echo $incident_title; ?>
															</a>
														</strong>
													</div>
											<?php
												}
											?>
												<p><?php echo $comment_description; ?></p>
											</div>
											<ul class="profile-info">
												<li class="profile-none-separator"><?php echo Kohana::lang('pcoe.profile_comment_email'); ?>: 
													<strong><?php echo $comment_email; ?></strong>
												</li>
												<li><?php echo Kohana::lang('pcoe.profile_comment_ip_address'); ?>: 
													<strong><?php echo $comment_ip; ?></strong>
												</li>
												<li><?php echo Kohana::lang('pcoe.profile_comment_rating'); ?>: 
													<strong><?php echo $comment_rating; ?></strong>
												</li>
											</ul>
										</td>
										<td class="profile-comment-col-2"><?php echo $comment_date; ?></td>
										<td class="profile-comment-col-3"></td>
									</tr>
									<?php
								}
								?>
							</tbody>
						</table>
					</div>
				<?php print form::close(); ?>
			</div>
