<?php 
/**
 * Dashboard view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

?>	
<div class="content-bg">
	<div class="big-block">
		<div class="big-block-top">
			<div class="big-block-bottom">
				
				
			<?php
				if ($display_msg) {
			?>
					<div class="profile-msg_holder">
						<div class="profile-msg_holder_inner">
						<!-- green-box -->
							<div class="profile-green-box">
								<h3><?php echo $display_msg ?></h3>
							</div>
						</div>	
					</div>	
			<?php
				}
			?>
						
				<div class='profile-report_row'>
					<h4><?php echo Kohana::lang('pcoe.dashboard_reports_and_updates'); ?></h4>
					<table class='profile-table'>
						<th class='col-1'><?php echo Kohana::lang('pcoe.dashboard_media'); ?></th>
						<th class='col-2'><?php echo Kohana::lang('pcoe.dashboard_reports_and_updates'); ?></th>
						<th class='col-3'><?php echo Kohana::lang('pcoe.dashboard_date'); ?></th>
						<th class='col-4'><?php echo Kohana::lang('pcoe.dashboard_location'); ?></th>
						<th class='col-5'><?php echo Kohana::lang('pcoe.dashboard_verified'); ?></th>
						
					<?php 	
							if($project_available)
							{
								$status = $project->incident_verified == '1' ?  Kohana::lang('pcoe.dashboard_verified_yes') :  Kohana::lang('pcoe.dashboard_verified_no');
								$incident_desc = text::limit_chars($project->incident_description, 50, "...", true);
					?>
								<tr>
									<td>
							<?php
										if(isset($media_icons[$project->id])){
				                        	echo $media_icons[$project->id];
				                       }
							?>		
									</td>
									<td>
										<div style="float:left;width:80%">
											<div class="profile-report-title">
												<?php echo $project->incident_title ?>
											</div>
											<div class="profile-report-description">
												<?php echo $incident_desc ?>
											</div>
										</div>
										<div style="float:right;width:19%;text-align:right">
											<a class='profile-edit-btn' href="<?php echo url::site().'profile/project/edit/'.$project->id; ?>">
												<img src="<?php echo $img_src?>" />
												<?php echo Kohana::lang('pcoe.dashboard_edit_project_btn'); ?>
											</a>
										</div>
									</td>
									<td><?php echo date('m/d/Y', strtotime($project->incident_date)); ?></td>
									<td><?php echo $project->location_name  ?></td>
									<td><?php echo $status  ?></td>
								<tr>	
					<?php
					
								if($updates)
								{
									foreach($updates as $update)
									{
										$update_desc = text::limit_chars($update->update_description, 50, "...", true);
										
					?>
										<tr>
											<td></td>
											<td>									
												<div style="float:left;width:80%">
													<div class="profile-report-title">
														<?php echo $update->update_title ?>
													</div>
													<div class="profile-report-description">
														<?php echo$update_desc ?>
													</div>
												</div>
												<div style="float:right;width:19%;text-align:right">							
													<a class='profile-edit-btn' href="<?php echo url::site().'profile/update/edit/'.$update->id; ?>">
														<img src="<?php echo $img_src?>" />
														<?php echo Kohana::lang('pcoe.dashboard_edit_update_btn'); ?>
													</a>
												</div>
											</td>
											<td><?php echo date('m/d/Y', strtotime($update->update_date)); ?></td>
											<td></td>
											<td></td>
										<tr>	
					<?php				
									
									}
								}
							}
					
					?>	
					
							<tr>
								<td></td>
								<td>
									<div style="padding:10px">	
										<div class="profile-new-project">
											<?php echo $new_lbl ?>
										</div>
										<div style="float:right;width:30%;text-align:right">
											<a class='profile-new-btn' href="<?php echo url::site().$new_link; ?>"><?php echo Kohana::lang('pcoe.dashboard_create_new_btn'); ?></a>
										</div>
									</div>	
								</td>
								<td></td>
								<td></td>
								<td></td>
							<tr>	
							
					</table>
				</div>
				
			</div>
		</div>
	</div>
</div>	
		
