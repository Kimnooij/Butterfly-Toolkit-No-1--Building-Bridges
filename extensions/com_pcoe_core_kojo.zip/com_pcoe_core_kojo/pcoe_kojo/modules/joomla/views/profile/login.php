<?php 
/**
 * Comments view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
 
?>
	<div class="content-bg">
		<div class="big-block">
			<div class="big-block-top">
				<div class="big-block-bottom">
					<!--div class="profile-login-outer">
						<div class="profile-login-middle">
							<div class="profile-login-inner"-->
								<?php echo "{loadposition bb_login}"?>
							<!--/div>
						</div>
					</div-->	
				</div>
			</div>
		</div>
	</div>	
