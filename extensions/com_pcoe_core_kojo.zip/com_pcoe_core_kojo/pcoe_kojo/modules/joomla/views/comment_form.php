<?php 
/**
 * Reports view page.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
?>
		<div id="content">			
			<br />
		    <!-- end incident block <> start other report -->
			<a name="comments"></a>
			<div class="big-block">
				<div class="big-block-top">
				<div class="big-block-bottom">
					<div id="comments" class="pcoe-report_comment" style="width:100%">
						<?php
						if ($form_error) {
						?>
							<!-- red-box -->
							<div class="red-box">
								<h3>Error!</h3>
								<ul>
								<?php
								foreach ($errors as $error_item => $error_description)
								{
									print (!$error_description) ? '' : "<li>" . $error_description . "</li>";
								}
								?>
								</ul>
							</div>
						<?php
						}
						?>
				
						<?php print form::open(NULL, array('id' => 'commentForm', 'name' => 'commentForm')); ?>
						<div class="pcoe-report_row">
                        	<strong>Name:</strong><br />
							<?php print form::input('comment_author', $form['comment_author'], ' class="text"'); ?>
                        </div>
						<div class="pcoe-report_row">
                        	<strong>E-Mail:</strong><br />
							<?php print form::input('comment_email', $form['comment_email'], ' class="text"'); ?>
                        </div>
						<div class="pcoe-report_row">
							<strong>Comments:</strong><br />
							<?php print form::textarea('comment_description', $form['comment_description'], ' rows="4" cols="40" class="textarea long" ') ?>
                        </div>
						<div class="pcoe-report_row">
							<strong>Security Code:</strong><br />
							<?php print $captcha->render(); ?><br />
							<?php print form::input('captcha', $form['captcha'], ' class="text"'); ?>
                        </div>
                        <div class="pcoe-report_row">
                        	<input name="submit" type="submit" value="Submit Comment" class="btn_blue" />
                        </div>	
						<input name="type" type="hidden" value="<?php echo $type?>" />
						<?php print form::close(); ?>
			
					</div>
				  </div>
				</div>
			  </div>
			</div>
		</div>
