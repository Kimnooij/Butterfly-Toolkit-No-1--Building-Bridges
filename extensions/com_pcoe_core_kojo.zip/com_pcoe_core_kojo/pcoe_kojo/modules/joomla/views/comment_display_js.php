<?php
/**
 * Reports view js file.
 *
 * Handles javascript stuff related to reports view function.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     API Controller
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */
 
?>			
		jQuery(function() {	
			/*
			Add Comments JS
			*/			
			// Ajax Validation
			jQuery("#commentForm").validate({
				rules: {
					comment_author: {
						required: true,
						minlength: 3
					},
					comment_email: {
						required: true,
						email: true
					},
					comment_description: {
						required: true,
						minlength: 3
					},
					captcha: {
						required: true
					}
				},
				messages: {
					comment_author: {
						required: "Please enter your Name",
						minlength: "Your Name must consist of at least 3 characters"
					},
					comment_email: {
						required: "Please enter an Email Address",
						email: "Please enter a valid Email Address"
					},
					comment_description: {
						required: "Please enter a Comment",
						minlength: "Your Comment must be at least 3 characters long"
					},
					captcha: {
						required: "Please enter the Security Code"
					}
				}
			});
				
		});
		
		function rating(id,action,type,loader)
		{				
			jQuery('#' + loader).html('<img src="<?php echo url::base() . "media/img/loading_g.gif"; ?>">');
			jQuery.post("<?php echo url::base() . 'project/rating/' ?>" + type + '/' + id, { action: action, type: type },
				function(data){
					if (data.status == 'saved'){
						if (type == 'original') {
							jQuery('#oup_' + id).attr("src","<?php echo url::base() . 'media/img/'; ?>gray_up.png");
							jQuery('#odown_' + id).attr("src","<?php echo url::base() . 'media/img/'; ?>gray_down.png");
							jQuery('#orating_' + id).html(data.rating);
						}
						else if (type == 'update') {
							jQuery('#uup_' + id).attr("src","<?php echo url::base() . 'media/img/'; ?>gray_up.png");
							jQuery('#udown_' + id).attr("src","<?php echo url::base() . 'media/img/'; ?>gray_down.png");
							jQuery('#urating_' + id).html(data.rating);
						}
						else if (type == 'comment')
						{
							jQuery('#cup_' + id).attr("src","<?php echo url::base() . 'media/img/'; ?>gray_up.png");
							jQuery('#cdown_' + id).attr("src","<?php echo url::base() . 'media/img/'; ?>gray_down.png");
							jQuery('#crating_' + id).html(data.rating);
						}
					} else {
						alert('ERROR!');
					}
					jQuery('#' + loader).html('');
				}, "json");
		}