<?php defined('SYSPATH') or die('No direct script access.');

/**
 * This controller is used to list/ view and edit reports
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author	   Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module	   Reports Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Comments_Controller extends Profile_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->template->header->this_page = 'comments';
	}
	
	public function index()
	{
		$user_info = Profile_Controller::get_user_info();
		$userid = $user_info['id'];
		$project = Profile_Controller::get_usr_project($userid);
		$incident_id = '';
		
		$project_comments = array();
		$update_comments = array();
		
		$this->template->content = new View('profile/comment_list');
		$this->template->content->title = 'Comments';
		
		if($project)
		{
			$incident_id = $project->id;
			$project = Profile_Controller::get_incident_info($project->id);
			$has_comment = Profile_Controller::get_project_comments_count($project->id);
			
			$category_list = Profile_Controller::get_incident_categories($incident_id);
			$temp = array();
			if($category_list)
			{
				$categoryies = Profile_Controller::get_categories($category_list);
				
				foreach($category_list as $category_id)
				{
					$temp[] = $categoryies["$category_id"][0];
				}
				$category = implode('| ', $temp);
			}
			
			$user = Profile_Controller::get_pcoe_info($userid);
			
			$project_comments = array('project'=>$project,
										'has_comment'=>$has_comment,
										'category'=>$category,
										'user_name'=>$user->name,
								);		
		
			$this->template->content->project_available = true;			
			$this->template->content->project_info = $project_comments;
			$this->template->content->update_info = false;
		}
		else
		{
			$this->template->content->project_available = false;
			$this->template->content->project_info = false;
			$this->template->content->update_info = false;
		}

		$filter = "incident_id='$incident_id'";
		// Pagination
		$pagination = new Pagination(array(
			'query_string'    => 'page',
			'items_per_page' => (int) Kohana::config('settings.items_per_page_admin'),
			'total_items'    => ORM::factory('update')->where($filter)->count_all()
		));
		
		$updates = ORM::factory('update')
					->where($filter)
					->orderby('update_date', 'desc')
					->find_all((int) Kohana::config('settings.items_per_page_admin'), $pagination->sql_offset);
					
		$comment_count = array();
		
		foreach($updates as $update)
		{
			$comment_count[$update->id] = Profile_Controller::get_project_comments_count($update->id,true);
		}
		
	
		$this->template->content->pagination = $pagination;
		$this->template->content->total_items = $pagination->total_items;
		
		$this->template->content->updates = $updates;
		$this->template->content->comment_count = $comment_count;
	
	}
	
	public function view($type='incident',$id=false)
	{
		$this->template->content = new View('profile/comments');
		$this->template->content->title = 'Comments';
		
		if(!$id)
		{
			url::redirect('profile/comments');
		}
		else
		{
			if($type=='update')
			{
				$incident = ORM::factory('update', $id);
				$title = $incident->update_description;
				$desc = $incident->update_description;
				$date = $incident->update_date;
				$update = true;
				
				$incident_link = "profile/update/edit/$id";
			
				$filter = "comment_active='1' AND comment_spam = '0' AND update_id = $id";
			}
			else
			{
				$incident = ORM::factory('incident', $id);
				$title = $incident->incident_description;
				$desc = $incident->incident_description;
				$date = $incident->incident_date;
				$update = false;			
				
				$incident_link = "profile/uproject/edit/$id";
				
				$filter = "comment_active=1 AND comment_spam = '0' AND update_id = 0 AND incident_id = $id";
			}
			
			
			$pagination = new Pagination(array(
				'query_string'    => 'page',
				'items_per_page' => (int) Kohana::config('settings.items_per_page_admin'),
				'total_items'    => ORM::factory('comment')->where($filter)->count_all()
			));

		$comments = ORM::factory('comment')
					->where($filter)
					->orderby('comment_date', 'desc')
					->find_all((int) Kohana::config('settings.items_per_page_admin'), $pagination->sql_offset);
		
		$this->template->content->comments = $comments;
		$this->template->content->pagination = $pagination;
		$this->template->content->form_error = false;
		$this->template->content->form_saved = false;
		
		$this->template->content->update = $update;
		$this->template->content->incident_title = $title;
		$this->template->content->incident_id = $id;
		$this->template->content->incident_link = $incident_link;
		
		// Total Reports
		$this->template->content->total_items = $pagination->total_items;
		}	
	}
	 
	 
} // End Reports
