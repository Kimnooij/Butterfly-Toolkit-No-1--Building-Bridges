<?php defined('SYSPATH') or die('No direct script access.');
/**
 * This controller is used for the main Admin panel
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     Admin Dashboard Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Dashboard_Controller extends Profile_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->template->header->this_page = 'dashboard';
	}
	
	
	function index()
	{	
		self::view();
	}
	
	function view($msg=false)
	{
		$display_msg = false;
		if($msg)
		{
			if($msg == 'saved')
			{
				$display_msg = Kohana::lang('pcoe.dashboard_project_saved'); 
			}
			elseif($msg=='new')
			{
				$display_msg = Profile_Controller::get_new_project_msg();
			}
			elseif($msg=='usave')
			{
				$display_msg = Kohana::lang('pcoe.dashboard_update_saved'); 
			}
			elseif($msg=='noupdate')
			{
				$display_msg = Kohana::lang('pcoe.dashboard_update_no_project_error'); 
			}
			else
			{
		        $display_msg = urldecode($msg);
			}
		}
		$this->template->content = new View('profile/dashboard');
		$this->template->content->title = 'Dashboard';
		
		$juser =& JFactory::getUser();
		$user = Profile_Controller::get_user_info();
		$userid = $user['id'];
					
		$project = Profile_Controller::get_usr_project($userid);
				
		if($project)
		{
			$updates = Profile_Controller::get_usr_updates($userid);
		
			$this->template->content->project_available = true;			
			$this->template->content->project = $project;
			$this->template->content->updates = $updates;
			$this->template->content->new_lbl = "New Update";
			$this->template->content->new_link = "profile/update/add";
		}
		else
		{
			$this->template->content->project_available = false;
			$this->template->content->project = false;
			$this->template->content->updates = false;
			$this->template->content->new_lbl = "New Project";
			$this->template->content->new_link = "profile/project/add";
		}
		
		$this->template->content->display_msg = $display_msg;
		$this->template->content->img_src = JURI::base().'templates/pcoe/images/profile-edit-icon.png';
		$this->template->content->project_media_icons = array();
		
		$icon_html = array();
		$icon_html[1] = "<img src=\"".url::base()."media/img/image.png\">"; //image
		$icon_html[2] = "<img src=\"".url::base()."media/img/video.png\">"; //video
		$icon_html[3] = ""; //audio
		$icon_html[4] = ""; //news
		$icon_html[5] = ""; //podcast
		
		if($project)
		{
			$incident_id = $project->id;
			
			$count = ORM::factory('media')
               ->where('incident_id', $incident_id)->count_all();			
			
			if( $count > 0)   
			{
				$medias = ORM::factory('media')
                          ->where('incident_id', $incident_id)->find_all();
				
				//Modifying a tmp var prevents Kohona from throwing an error
				$tmp[$incident_id] = '';
				
				foreach($medias as $media)
				{
					$tmp[$incident_id] .= $icon_html[$media->media_type];
					$this->template->content->media_icons = $tmp;
				}
			}
		}
	}

}
?>
