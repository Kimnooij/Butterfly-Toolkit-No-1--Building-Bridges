<?php defined('SYSPATH') or die('No direct script access.');

/**
 * This controller is used to list/ view and edit reports
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author	   Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module	   Reports Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Update_Controller extends Profile_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->template->header->this_page = 'update';
	}
	
	public function index()
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$user_info = Profile_Controller::get_user_info();
		$user_id = $user_info['id'];
		$q = "SELECT id FROM {$table_prefix}update WHERE `user_id` = '$user_id' ORDER BY id DESC LIMIT 1";

		$jdb->setQuery($q);
		$id =  $jdb->loadResult();		
		if($id)	
			self::edit($id);
		else
			self::edit();
	}
	
	/**
	 * Submits a new report.
	 */
	public function add()
	{
		self::edit();
	}
	
	public function edit($id=false, $saved=false)
	{
		//check if user has created project
		if(!$id)
		{
	      	$jdb=JFactory::getDBO();
	  	    $table_prefix = Kohana::config('database.default.table_prefix');
			$user_info = Profile_Controller::get_user_info();
			$user_id = $user_info['id'];
			$q = "SELECT id FROM {$table_prefix}incident WHERE `user_id` = '$user_id' ";
	
			$jdb->setQuery($q);
			$project_id =  $jdb->loadResult();
	  		
	  		if(!$project_id)
	  		{
		        url::redirect('profile/dashboard/view/noupdate');
			}
      
		}
		
		$this->template->content = new View('profile/update');
		
		// setup and initialize form field names
		$form = array
		(
			'incident_title' => '',
			'incident_description' => '',
			'incident_date' => '',
			'incident_hour' => '',
			'incident_minute' => '',
			'incident_ampm' => ''
		);
		//	copy the form as errors, so the errors will be stored with keys corresponding to the form field names
		$errors = $form;
		$form_error = FALSE;
		
		if($saved)
			$form_saved = true;
		else
			$form_saved = false;
		
		// Initialize Default Values
		$form['incident_date'] = date("m/d/Y",time());
		$form['incident_hour'] = "12";
		$form['incident_minute'] = "00";
		$form['incident_ampm'] = "pm";
		
		
		if($id)
		{
			$user = Profile_Controller::get_user_info();
			$update = Profile_Controller::get_update_info($id);

			$form['incident_title']= $update->update_title ;
			$form['incident_description']= $update->update_description ;
			$form['incident_date']= date('m/d/Y', strtotime($update->update_date));
			$form['incident_hour']= date('h', strtotime($update->update_date));
			$form['incident_minute']= date('i', strtotime($update->update_date));
			$form['incident_ampm']= date('a', strtotime($update->update_date));
						
		}

		$form_error = false;
		//save
		if ($_POST)
	    {		
			$save_error = self::save($id);		
			
			if($save_error)
			{			
	            // populate the error fields, 
	            $errors = arr::overwrite($errors, $save_error);	
				$post = Validation::factory(array_merge($_POST));
				$form = arr::overwrite($form, $post->as_array());				
				$form_error = true;
			}	
		}
		
		//$this->template->content->this_page = 'update';
		$this->template->content->form = $form;
		$this->template->content->errors = $errors;
		$this->template->content->form_error = $form_error;
		
		$this->template->content->form_saved = $form_saved;
		$this->template->content->id = $id;
		$this->template->content->date_picker_js = Profile_Controller::date_picker_js();
		// Time formatting
	    $this->template->content->hour_array = Profile_Controller::hour_array();
	    $this->template->content->minute_array = Profile_Controller::minute_array();
        $this->template->content->ampm_array = Profile_Controller::ampm_array();
	
	}
	
	function save($id)
	{
		if($id)
			$edit = true;
		else
			$edit = false;
			
		if ($_POST)
	    {
            // Instantiate Validation, use $post, so we don't overwrite $_POST fields with our own things
			$post = Validation::factory($_POST);
	         //  Add some filters
	        $post->pre_filter('trim', TRUE);

			$post->add_rules('incident_title','required', 'length[3,200]');
			$post->add_rules('incident_description','required');
			$post->add_rules('incident_date','required','date_mmddyyyy');
			$post->add_rules('incident_hour','required','between[1,12]');
			$post->add_rules('incident_minute','required','between[0,59]');
			if ($_POST['incident_ampm'] != "am" && $_POST['incident_ampm'] != "pm")
			{
				$post->add_error('incident_ampm','values');
	        }
			

			// Test to see if things passed the rule checks
	        if ($post->validate())
	        {
                // Yes! everything is valid
				$update = new Update_Model();
				if ($edit)	// edit
				{
					$update = new Update_Model($id);
					//incident->id = $id;
				}			
				$user_info = Profile_Controller::get_user_info();
				$update->user_id = $user_info['id'];
				
				$incident_id = Profile_Controller::get_usr_incident_id($user_info['id']);
				$update->incident_id = $incident_id;
				
				$update->update_title = $post->incident_title;
				$update->update_description = $post->incident_description;
				
				$incident_date=explode("/",$post->incident_date);
				$incident_date=$incident_date[2]."-".$incident_date[0]."-".$incident_date[1];
					
				$incident_time = $post->incident_hour 
									. ":" . $post->incident_minute 
									. ":00 " . $post->incident_ampm;
				$update->update_date = $incident_date . " " . $incident_time;
				// Is this new or edit?
				if ($edit)	// edit
				{
					$update->update_datemodify = date("Y-m-d H:i:s",time());
				}
				else 		// new
				{
					$update->update_dateadd = date("Y-m-d H:i:s",time());
				}
				
				//Save
				$update->save();
				
				url::redirect('profile/dashboard/view/usave');
				
	        }
	
            // No! We have validation errors, we need to show the form again, with the errors
	        else   
			{
				$errors = $post->errors('report');
				return $errors;
	        }
	    }
	}
   
	 
} // End Reports
