<?php defined('SYSPATH') or die('No direct script access.');
/**
 * This controller is used for the main Admin panel
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     Admin Dashboard Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Login_Controller extends Main_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->template->header->this_page = 'login';
		error_reporting(E_ALL & ~E_NOTICE);
	}
	
	
	function index()
	{
		$juser = Profile_Controller::get_juser_info();	
		if($juser['id']>0)
		{
			url::redirect('profile/dashboard');
		}
		
		JPluginHelper::importPlugin('content','loadmodule');
		$this->template->header = '';
		$this->template->content = new View('profile/login');
	}
	
	function login()
	{
		$this->template->header = '';
		$this->template->content = new View('profile/login');
		
	}

}
?>
