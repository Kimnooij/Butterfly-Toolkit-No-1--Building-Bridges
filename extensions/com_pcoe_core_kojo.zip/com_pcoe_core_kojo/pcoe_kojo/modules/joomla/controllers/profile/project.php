<?php defined('SYSPATH') or die('No direct script access.');

/**
 * This controller is used to list/ view and edit reports
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author	   Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module	   Reports Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Project_Controller extends Profile_Controller {

	function __construct()
	{
		parent::__construct();

		// Javascript Header
		$this->template->header->validator_enabled = TRUE;
		
		
		// Javascript Header
		$this->template->header->map_enabled = TRUE;
		$this->template->header->datepicker_enabled = TRUE;
		$this->template->header->js = new View('profile/project_js');
		$this->template->header->js->default_map = Kohana::config('settings.default_map');
		$this->template->header->js->default_zoom = Kohana::config('settings.default_zoom');
		
		$this->template->header->this_page = 'project';
		
	}
	
	public function index()
	{
		$user = Profile_Controller::get_user_info();
		$id = Profile_Controller::get_usr_incident_id($user['id']);
		self::edit_report($id);
	}
	/**
	 * Submits a new report.
	 */
	public function add()
	{
		self::edit_report();
	}
	
	public function edit( $id = false, $saved=false)
	{
		self::edit_report( $id, $saved);
	}
	
	public function edit_report($id=false, $saved=false)
	{		
		$display_msg = false;
		if($saved)
		{
			if($saved=='new')
			{
				$display_msg = Profile_Controller::get_new_project_msg();
			}
			else
			{
				$display_msg = "Your Project has been saved";
			}
			
		}
		$this->template->this_page = 'project';
		$this->template->content = new View('profile/project');
		$this->template->content->display_msg = $display_msg;
		
		// setup and initialize form field names
		$form = array
		(
			'location_id' => '',
			'form_id' => '',
			'incident_title' => '',
			'incident_description' => '',
			'incident_date' => '',
			'incident_hour' => '',
			'incident_minute' => '',
			'incident_ampm' => '',
			'latitude' => '',
			'longitude' => '',
			'location_name' => '',
			'country_id' => '',
			'incident_category' => array(),
			'incident_news' => array(),
			'incident_video' => array(),
			'incident_photo' => array(),
			'person_first' => '',
			'person_last' => '',
			'person_email' => ''
		);
		//	copy the form as errors, so the errors will be stored with keys corresponding to the form field names
		$errors = $form;
		$form_error = FALSE;
		
		if($saved)
			$form_saved = true;
		else
			$form_saved = false;
		
		// Initialize Default Values
		$form['incident_date'] = date("m/d/Y",time());
		$form['incident_hour'] = "12";
		$form['incident_minute'] = "00";
		$form['incident_ampm'] = "pm";
		
		
		if($id)
		{
			$user = Profile_Controller::get_user_info();
			$incident = Profile_Controller::get_incident_info($id);
			$incident_media = Profile_Controller::get_incident_media($id);

			$form['incident_title']= $incident->incident_title ;
			$form['incident_description']= $incident->incident_description ;
			$form['incident_date']= date('m/d/Y', strtotime($incident->incident_date));
			$form['incident_hour']= date('h', strtotime($incident->incident_date));
			$form['incident_minute']= date('i', strtotime($incident->incident_date));
			$form['incident_ampm']= date('a', strtotime($incident->incident_date));
			
			$form['latitude']= $incident->latitude ;
			$form['longitude']= $incident->longitude ;
			$form['location_name']= $incident->location_name ;
			$form['country_id']= $incident->country_id ;
			$form['incident_category'] = Profile_Controller::get_incident_categories($id);
			
			$form['location_id']= $incident->location_id ;
			$form['form_id']= $incident->form_id ;
					
			// Retrieve Media
			$incident_news = array();
			$incident_video = array();
			$incident_photo = array();
			if($incident_media)
			{		
				foreach($incident_media as $media) 
				{
					if ($media->media_type == 4)
					{
						$incident_news[] = $media->media_link;
					}
					elseif ($media->media_type == 2)
					{
						$incident_video[] = $media->media_link;
					}
					elseif ($media->media_type == 1)
					{
						$incident_photo[] = $media->media_link;
					}
				}
			}	
			$form['incident_news'] = $incident_news;
			$form['incident_video'] = $incident_video;
			$form['incident_photo'] = $incident_photo;
				
		}

		$form_error = false;
		//save
		if ($_POST)
	    {		
			$save_error = self::save_incident($id);
			
			if($save_error)
			{						
				$post = Validation::factory(array_merge($_POST,$_FILES));
				$errors = arr::overwrite($errors, $save_error);
				$form = arr::overwrite($form, $post->as_array());
				$form_error = true;
			}
	
		}
			
		$this->template->content->incident = $this->get_thumbnails($id);
		
		// Retrieve Country Cities
		$default_country = Kohana::config('settings.default_country');
		$this->template->content->cities = Profile_Controller::get_cities($default_country);
		//$this->template->content->cities = $this->_get_cities($default_country);
		$this->template->content->multi_country = Kohana::config('settings.multi_country');
	
		$this->template->content->form = $form;
		$this->template->content->errors = $errors;
		$this->template->content->form_error = $form_error;
		$this->template->content->categories = Profile_Controller::get_categories($form['incident_category']);
		
		$this->template->content->selected_categories = $form['incident_category'];
		
		$this->template->content->form_saved = $form_saved;
		$this->template->content->id = $id;
		$this->template->content->date_picker_js = self::date_picker_js();
		// Time formatting
	    $this->template->content->hour_array = $this->hour_array();
	    $this->template->content->minute_array = $this->minute_array();
        $this->template->content->ampm_array = $this->ampm_array();
		// Retrieve Custom Form Fields Structure
		$disp_custom_fields = $this->get_custom_form_fields($id,$form['form_id'],false);
		$this->template->content->disp_custom_fields = $disp_custom_fields;
		
				
		//GET custom forms
		$forms = array();
		foreach (ORM::factory('form')->find_all() as $custom_forms)
		{
			$forms[$custom_forms->id] = $custom_forms->form_title;
		}
		$this->template->content->forms = $forms;
		
		if (!$form['latitude'] || !$form['latitude'])
		{
			$this->template->header->js->latitude = Kohana::config('settings.default_lat');
			$this->template->header->js->longitude = Kohana::config('settings.default_lon');
		}
		else
		{
			$this->template->header->js->latitude = $form['latitude'];
			$this->template->header->js->longitude = $form['longitude'];
		}
		
	}
	
	function save_incident($id)
	{
		if($id)
			$update = true;
		else
			$update = false;
			
		if ($_POST)
	    {
            // Instantiate Validation, use $post, so we don't overwrite $_POST fields with our own things
			$post = Validation::factory(array_merge($_POST,$_FILES));

	         //  Add some filters
	        $post->pre_filter('trim', TRUE);

			if($update)
			{
				$post->add_rules('location_id','numeric');
				$post->add_rules('message_id','numeric');
			}
			
			$post->add_rules('incident_title','required', 'length[3,200]');
			$post->add_rules('incident_description','required');
			$post->add_rules('incident_date','required','date_mmddyyyy');
			$post->add_rules('incident_hour','required','between[1,12]');
			$post->add_rules('incident_minute','required','between[0,59]');
			if ($_POST['incident_ampm'] != "am" && $_POST['incident_ampm'] != "pm")
			{
				$post->add_error('incident_ampm','values');
	        }
			$post->add_rules('latitude','required','between[-90,90]');		// Validate for maximum and minimum latitude values
			$post->add_rules('longitude','required','between[-180,180]');	// Validate for maximum and minimum longitude values
			$post->add_rules('location_name','required', 'length[3,200]');
			
			//XXX: Hack to validate for no checkboxes checked
			if (!isset($_POST['incident_category'])) {
				$post->incident_category = "";
				$post->add_error('incident_category','required');
			}
			else
			{
				$post->add_rules('incident_category.*','required','numeric');
			}

			// Validate only the fields that are filled in	
	        if (!empty($_POST['incident_news']))
			{
	        	foreach ($_POST['incident_news'] as $key => $url) {
					if (!empty($url) AND !(bool) filter_var($url, FILTER_VALIDATE_URL, FILTER_FLAG_HOST_REQUIRED))
					{
						$post->add_error('incident_news','url');
					}
	        	}
	        }
			
			// Validate only the fields that are filled in
	        if (!empty($_POST['incident_video']))
			{
	        	foreach ($_POST['incident_video'] as $key => $url) {
					if (!empty($url) AND !(bool) filter_var($url, FILTER_VALIDATE_URL, FILTER_FLAG_HOST_REQUIRED))
					{
						$post->add_error('incident_video','url');
					}
	        	}
	        }
	
			// Validate photo uploads
			$post->add_rules('incident_photo', 'upload::valid', 'upload::type[gif,jpg,png]', 'upload::size[2M]');
	
			// Test to see if things passed the rule checks
	        if ($post->validate())
	        {
                // Yes! everything is valid	
				if($update)
				{
					$location_id = $post->location_id;
					$location = new Location_Model($location_id);
					$incident = new Incident_Model($id);
					$incident->form_id = $post->form_id;
				}
				else
				{
					$location = new Location_Model();
					$incident = new Incident_Model();
				}
				
				// STEP 1: SAVE LOCATION
				$location->location_name = $post->location_name;
				$location->latitude = $post->latitude;
				$location->longitude = $post->longitude;
				$location->location_date = date("Y-m-d H:i:s",time());
				$location->save();
				
				// STEP 2: SAVE INCIDENT
				$incident->location_id = $location->id;
				//$incident->locale = $post->locale;
				
				
				$user = Profile_Controller::get_user_info();
				$incident->user_id = $user['id'];
			
				$incident->incident_title = $post->incident_title;
				$incident->incident_description = $post->incident_description;
				
				$incident_date=explode("/",$post->incident_date);
				// where the $_POST['date'] is a value posted by form in mm/dd/yyyy format
					$incident_date=$incident_date[2]."-".$incident_date[0]."-".$incident_date[1];
					
				$incident_time = $post->incident_hour 
									. ":" . $post->incident_minute 
									. ":00 " . $post->incident_ampm;
				$incident->incident_date = $incident_date . " " . $incident_time;
				// Is this new or edit?
				if ($update)	// edit
				{
					$incident->incident_datemodify = date("Y-m-d H:i:s",time());
				}
				else 		// new
				{
					$incident->incident_dateadd = date("Y-m-d H:i:s",time());
				}
				
				//Save
				$incident->save();
								
				// STEP 3: SAVE CATEGORIES
				if($update)
				{
					// Delete Previous Entries
					ORM::factory('Incident_Category')->where('incident_id',$incident->id)->delete_all();
				}
				
				foreach($post->incident_category as $item)
				{
					$incident_category = new Incident_Category_Model();
					$incident_category->incident_id = $incident->id;
					$incident_category->category_id = $item;
					$incident_category->save();
				}
				
				
				// STEP 4: SAVE MEDIA
				if($update)
				{
					// Delete Previous Entries
					ORM::factory('Media')->where('incident_id',$incident->id)->where('media_type <> 1')->delete_all();
				}
				
				// a. News
				foreach($post->incident_news as $item)
				{
					if(!empty($item))
					{
						$news = new Media_Model();
						$news->location_id = $location->id;
						$news->incident_id = $incident->id;
						$news->media_type = 4;		// News
						$news->media_link = $item;
						$news->media_date = date("Y-m-d H:i:s",time());
						$news->save();
					}
				}
				
				// b. Video
				foreach($post->incident_video as $item)
				{
					if(!empty($item))
					{
						$video = new Media_Model();
						$video->location_id = $location->id;
						$video->incident_id = $incident->id;
						$video->media_type = 2;		// Video
						$video->media_link = $item;
						$video->media_date = date("Y-m-d H:i:s",time());
						$video->save();
					}
				}
				
				// c. Photos
				$filenames = upload::save('incident_photo');
				$i = 1;
				
				foreach ($filenames as $filename) 
				{
					$new_filename = $incident->id . "_" . $i . "_" . time();
					
					// Resize original file... make sure its max 408px wide
					Image::factory($filename)->resize(408,248,Image::AUTO)
						->save(Kohana::config('upload.directory', TRUE) . $new_filename . ".jpg");
					
					// Create thumbnail
					Image::factory($filename)->resize(70,41,Image::HEIGHT)
						->save(Kohana::config('upload.directory', TRUE) . $new_filename . "_t.jpg");
					
					// Remove the temporary file
					unlink($filename);
					
					// Save to DB
					$photo = new Media_Model();
					$photo->location_id = $location->id;
					$photo->incident_id = $incident->id;
					$photo->media_type = 1; // Images
					$photo->media_link = $new_filename . ".jpg";
					$photo->media_thumb = $new_filename . "_t.jpg";
					$photo->media_date = date("Y-m-d H:i:s",time());
					$photo->save();
					$i++;
				}				
								
				// STEP 5: SAVE PERSONAL INFORMATION
				if($update)
				{
					// Delete Previous Entries
					ORM::factory('Incident_Person')->where('incident_id',$incident->id)->delete_all();
	            }
				
				$person = new Incident_Person_Model();
				
				$user = Profile_Controller::get_user_info();
				$person->person_first = $user['name'];
				$person->person_last = $user['name'];
				$person->person_email = $user['email'];
				
				$person->location_id = $location->id;
				$person->incident_id = $incident->id;
				
				$person->person_date = date("Y-m-d H:i:s",time());
				$person->save();
				
				//$display_msg = false;
				$display_msg = 'saved';
				
				if(!$update)
				{						
					$display_msg = "new";
				}
				
				// SAVE AND CLOSE?
				if ($post->save == 1)		// Save but don't close
				{
					url::redirect('profile/project/edit/'. $incident->id .'/'.$display_msg);
				}
				else 						// Save and close
				{
					url::redirect('profile/dashboard/view/'.$display_msg);
				}
	        }
	
            // No! We have validation errors, we need to show the form again, with the errors
	        else   
			{
				$errors = $post->errors('report');
				return $errors;
	        }
	    }
	}
    
	
	// Javascript functions
	 function color_picker_js()
    {
     return "<script type=\"text/javascript\">
				jQuery(document).ready(function() {
                jQuery('#category_color').ColorPicker({
                        onSubmit: function(hsb, hex, rgb) {
                            jQuery('#category_color').val(hex);
                        },
                        onChange: function(hsb, hex, rgb) {
                            jQuery('#category_color').val(hex);
                        },
                        onBeforeShow: function () {
                            jQuery(this).ColorPickerSetColor(this.value);
                        }
                    })
                .bind('keyup', function(){
                    jQuery(this).ColorPickerSetColor(this.value);
                });
				});
            </script>";
    }
		
    function date_picker_js()
    {
        return "<script type=\"text/javascript\">
				jQuery(document).ready(function() {
				jQuery(\"#incident_date\").datepicker({ 
				showOn: \"both\", 
				buttonImage: \"" . url::base() . "media/img/icon-calendar.gif\", 
				buttonImageOnly: true 
				});
				});
			</script>";	
    }
	
	function get_thumbnails( $id )
	{
		$incident = ORM::factory('incident', $id);
		
		if ( $id )
		{
			$incident = ORM::factory('incident', $id);
			
			return $incident;
		
		}
		return "0";
	}
	
	
    // Time functions
    function hour_array()
    {
        for ($i=1; $i <= 12 ; $i++) 
        { 
		    $hour_array[sprintf("%02d", $i)] = sprintf("%02d", $i); 	// Add Leading Zero
		}
	    return $hour_array;	
	}
									
	function minute_array()
	{								
		for ($j=0; $j <= 59 ; $j++) 
		{ 
			$minute_array[sprintf("%02d", $j)] = sprintf("%02d", $j);	// Add Leading Zero
		}
		
		return $minute_array;
	}
	
	function ampm_array()
	{								
	    return $ampm_array = array('pm'=>'pm','am'=>'am');
	}
	
	function get_custom_form_fields($incident_id = false, $form_id = 1, $data_only = false)
    {
		$fields_array = array();
		
		if (!$form_id)
		{
			$form_id = 1;
		}
		$custom_form = ORM::factory('form', $form_id)->orderby('field_position','asc');
		foreach ($custom_form->form_field as $custom_formfield)
		{
			if ($data_only)
			{ // Return Data Only
				$fields_array[$custom_formfield->id] = '';
				
				foreach ($custom_formfield->form_response as $form_response)
				{
					if ($form_response->incident_id == $incident_id)
					{
						$fields_array[$custom_formfield->id] = $form_response->form_response;
					}
				}
			}
			else
			{ // Return Field Structure
				$fields_array[$custom_formfield->id] = array(
					'field_id' => $custom_formfield->id,
					'field_name' => $custom_formfield->field_name,
					'field_type' => $custom_formfield->field_type,
					'field_required' => $custom_formfield->field_required,
					'field_maxlength' => $custom_formfield->field_maxlength,
					'field_height' => $custom_formfield->field_height,
					'field_width' => $custom_formfield->field_width,
					'field_isdate' => $custom_formfield->field_isdate,
					'field_response' => ''
					);
			}
		}
		
		return $fields_array;
    }
   
	function deletePhoto ( $id )
	{
		$this->auto_render = FALSE;
		$this->template = "";
		
		if ( $id )
		{
			$photo = ORM::factory('media', $id);
			$photo_large = $photo->media_link;
			$photo_thumb = $photo->media_thumb;
			
			// Delete Files from Directory
			if (!empty($photo_large))
				unlink(Kohana::config('upload.directory', TRUE) . $photo_large);
			if (!empty($photo_thumb))
				unlink(Kohana::config('upload.directory', TRUE) . $photo_thumb);

			// Finally Remove from DB
			$photo->delete();
		}
	}

	/**
	 * Ajax call to update Incident Reporting Form
	 */
	public function switch_form()
    {
		$this->template = "";
		$this->auto_render = FALSE;
		
		isset($_POST['form_id']) ? $form_id = $_POST['form_id'] : $form_id = "1";
		isset($_POST['incident_id']) ? $incident_id = $_POST['incident_id'] : $incident_id = "";
			
		$html = "";
		$fields_array = array();		
		$custom_form = ORM::factory('form', $form_id)->orderby('field_position','asc');
		
		foreach ($custom_form->form_field as $custom_formfield)
		{
			$fields_array[$custom_formfield->id] = array(
				'field_id' => $custom_formfield->id,
				'field_name' => $custom_formfield->field_name,
				'field_type' => $custom_formfield->field_type,
				'field_required' => $custom_formfield->field_required,
				'field_maxlength' => $custom_formfield->field_maxlength,
				'field_height' => $custom_formfield->field_height,
				'field_width' => $custom_formfield->field_width,
				'field_isdate' => $custom_formfield->field_isdate,
				'field_response' => ''
				);
			
			// Load Data, if Any
			foreach ($custom_formfield->form_response as $form_response)
			{
				if ($form_response->incident_id = $incident_id)
				{
					$fields_array[$custom_formfield->id]['field_response'] = $form_response->form_response;
				}
			}
		}
		
		foreach ($fields_array as $field_property)
		{
			$html .= "<div class=\"row\">";
			$html .= "<h4>" . $field_property['field_name'] . "</h4>";
			if ($field_property['field_type'] == 1)
			{ // Text Field
				// Is this a date field?
				if ($field_property['field_isdate'] == 1)
				{
					$html .= form::input('custom_field['.$field_property['field_id'].']', $field_property['field_response'],
						' id="custom_field_'.$field_property['field_id'].'" class="text"');
					$html .= "<script type=\"text/javascript\">
							jQuery(document).ready(function() {
							jQuery(\"#custom_field_".$field_property['field_id']."\").datepicker({ 
							showOn: \"both\", 
							buttonImage: \"" . url::base() . "media/img/icon-calendar.gif\", 
							buttonImageOnly: true 
							});
							});
						</script>";
				}
				else
				{
					$html .= form::input('custom_field['.$field_property['field_id'].']', $field_property['field_response'],
						' id="custom_field_'.$field_property['field_id'].'" class="text custom_text"');
				}
			}
			elseif ($field_property['field_type'] == 2)
			{ // TextArea Field
				$html .= form::textarea('custom_field['.$field_property['field_id'].']',
					$field_property['field_response'], ' class="custom_text" rows="3"');
			}
			$html .= "</div>";
		}
		
		echo json_encode(array("status"=>"success", "response"=>$html));
    }	
} // End Reports
