<?php defined('SYSPATH') or die('No direct script access.');
/**
 * This main controller for the Admin section 
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author	   Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module	   Admin Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Admin_Controller extends Template_Controller
{
	public $auto_render = TRUE;
	
	// Main template
	public $template = 'admin/layout';
	
	// Cache instance
	protected $cache;

	// Enable auth
	protected $auth_required = FALSE;
	
	protected $user;

	public function __construct()
	{
	//===========added by Yos=============	
		if(Kohana::config('profile.update_view'))
		{
			$this->template = 'admin/layout_profile';
		}
	//===================================
	
		parent::__construct();
		// Load cache
		$this->cache = new Cache;
				
		// Load session
		$this->session = new Session;
		
		// Load database
		$this->db = new Database();
		$this->auth = new Auth();
		
	//===========added by Yos=============
		global $mainframe;			
		$jdb=JFactory::getDBO();
		if(!defined('_BACKEND_END'))
		{
			//url::redirect('login');
			$mainframe->redirect('index.php?option=com_login');
		}
		else
		{	
			Admin_Controller::check_pcoe_registered();
			$juser = Admin_Controller::get_juser_info();
			if(!$juser)
			{				
				$mainframe->redirect('index.php?option=com_login');
			}

			$jid = $juser['id'];
			$usr_username = $juser['username'];	
			$pcoe_id = Admin_Controller::get_pcoe_id($jid);
			
			//auto login
			if(!Auth::instance()->logged_in('superadmin'))
			{
				Auth::instance()->login($usr_username, "");
				$this->session->set('joomla_id', $jid);
			}
		}
		
		if(Auth::instance()->logged_in('admin'))
		{
			// Get Session Information
			$user = new User_Model($_SESSION['auth_user']->id);
			$this->template->admin_name = $user->name;

			// Retrieve Default Settings
			$this->template->site_name = Kohana::config('settings.site_name');
			$this->template->mapstraction = Kohana::config('settings.mapstraction');
			$this->template->api_url = Kohana::config('settings.api_url');

			// Javascript Header
			$this->template->map_enabled = FALSE;
			$this->template->flot_enabled = FALSE;
			$this->template->colorpicker_enabled = FALSE;
			$this->template->js = '';
		}
		else
		{
			global $mainframe;
			$mainframe->redirect('index.php', 'PCOE Login Error');
		}
	}

	function get_juser_info()
	{
		$juser =& JFactory::getUser();
		
		$user = array();
		$user['name'] = $juser->get('name');
		$user['username'] = $juser->get('username');
		$user['email'] = $juser->get('email');
		$user['id'] = $juser->get('id');
		if($juser->get('id') > 0)
			return $user;
		else
			return false;
	}
	
	function check_pcoe_registered()
	{			
		$juser = Admin_Controller::get_juser_info();				
		if($juser)
		{			
			$xref_id = Admin_Controller::get_pcoe_id($juser['id']);
			$pcoe_id = Admin_Controller::get_pcoe_id_by_username($juser['username']);
			
			if($pcoe_id and !$xref_id)
			{				
				Admin_Controller::update_xref_table($juser['id'],$pcoe_id);
				Admin_Controller::update_roles_table($pcoe_id);
			}
			elseif(!$pcoe_id and !$xref_id)
			{
				Admin_Controller::add_j_user();
			}
			
			if($pcoe_id)
			{
				$admin_role = Admin_Controller::get_pcoe_roles_info($pcoe_id);
				if(!$admin_role)
				{
					Admin_Controller::update_roles_table($pcoe_id);
				}
			}
		}
	}
	
	function get_pcoe_id($id=false)
	{	
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT pcoe_id FROM {$table_prefix}pcoe_id_xref WHERE `j_id`='$id'";
				
		$jdb->setQuery($q);
		$id = $jdb->loadResult();
		
		return $id;
	}
	
	function get_pcoe_id_by_username($username)
	{				
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT id FROM {$table_prefix}users WHERE `username`='$username'";
				
		$jdb->setQuery($q);
		$id = $jdb->loadResult();			

		return $id;				
	}
		
	function add_j_user()
	{		
		$juser = Admin_Controller::get_juser_info();
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "INSERT INTO {$table_prefix}users(`name`,`username`,`email`,`password`) 
				VALUES('{$juser['name']}','{$juser['username']}','{$juser['email']}','')";
				
		$jdb->setQuery($q);
		$jdb->query();
		$pcoe_id = $jdb->insertid();
		
		if($pcoe_id)
		{
			Admin_Controller::update_roles_table($pcoe_id);
			Admin_Controller::update_xref_table($juser['id'],$pcoe_id);
		}
		else
		{
			echo "<br />".$jdb->getErrorMsg();
		}
	}
	
	function update_roles_table($id=false)
	{		
		if($id)
		{
			$jdb=JFactory::getDBO();
			$table_prefix = Kohana::config('database.default.table_prefix');
			$q = "DELETE FROM {$table_prefix}roles_users WHERE user_id = '$id'";
			$jdb->setQuery($q);
			$jdb->query();
			
			$q = "INSERT INTO {$table_prefix}roles_users(user_id, role_id) 
									  VALUES ('$id', '1'),('$id', '2') ,('$id', '3')";				
			$jdb->setQuery($q);
			if(!$jdb->query())
			{
				echo $jdb->getErrorMsg();
				return false;
			}
			else
			  return true;
		}
		else
		{
			echo "<br /> Missing user id";
			return false;
		}
		
	}
	
	function update_xref_table($jid,$pcoe_id)
	{
		if($jid and $pcoe_id)
		{
			$jdb=JFactory::getDBO();
		    $table_prefix = Kohana::config('database.default.table_prefix');
			
			$q = "INSERT INTO {$table_prefix}pcoe_id_xref(`j_id`,`pcoe_id`) 
						VALUES('$jid','$pcoe_id')";
					
				$jdb->setQuery($q);
				$jdb->query();
								
		}
		else
			return false;
	}
	
	function get_pcoe_roles_info($pcoe_id=false)
	{                                                               
		if($pcoe_id)
		{
			$jdb=JFactory::getDBO();
			$table_prefix = Kohana::config('database.default.table_prefix');
			$q = "SELECT `user_id` FROM {$table_prefix}roles_users WHERE user_id = '$pcoe_id' AND `role_id` = 2";
			$jdb->setQuery($q);
			return $jdb->loadResult();
		}
		return false;		
	} 
	
	public function index()
	{
		// Send them to the right page
		url::redirect('admin/dashboard');
	}
	                                    
 
	public function log_out()
	{		
		global $mainframe;
		$mainframe->redirect('index.php');
	}
 //===========================end============================ 

} // End Admin
