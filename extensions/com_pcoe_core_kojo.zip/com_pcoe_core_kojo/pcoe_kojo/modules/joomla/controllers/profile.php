<?php defined('SYSPATH') or die('No direct script access.');
/**
 * This main controller for the Admin section 
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author	   Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module	   Admin Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Profile_Controller extends Main_Controller
{
	// Main template
	
	public function __construct()
	{
		parent::__construct();	
		
		$juser = self::get_juser_info();
		if($juser['id']>0)
		{
			$xref_id = self::get_pcoe_id($juser['id']);
			$pcoe_id = self::check_pcoe_registered($juser['username']);
		
			if($pcoe_id and !$xref_id)
			{
				self::update_xref_table($juser['id'],$pcoe_id);
				self::update_roles_table($pcoe_id);
			}
			elseif(!$pcoe_id and !$xref_id)
			{
				self::add_j_user();
			}
		}
		else
		{	
			url::redirect('profile/login');
		}		
		
		$this->template->header  = new View('profile/profile_header');
		$this->template->footer  = new View('footer');
	
		// Retrieve Default Settings
		$site_name = Kohana::config('settings.site_name');
			// Prevent Site Name From Breaking up if its too long
			// by reducing the size of the font
			if (strlen($site_name) > 20)
			{
				$site_name_style = " style=\"font-size:21px;\"";
			}
			else
			{
				$site_name_style = "";
			}
        $this->template->header->site_name = $site_name;
		$this->template->header->site_name_style = $site_name_style;
		$this->template->header->site_tagline = Kohana::config('settings.site_tagline');
        $this->template->header->api_url = Kohana::config('settings.api_url');
		
		// Display News Feed?
		$this->template->header->allow_feed = Kohana::config('settings.allow_feed');
		
		// Javascript Header
		$this->template->header->map_enabled = FALSE;
		$this->template->header->validator_enabled = FALSE;
		$this->template->header->datepicker_enabled = FALSE;
		$this->template->header->photoslider_enabled = FALSE;
		$this->template->header->videoslider_enabled = FALSE;
		$this->template->header->main_page = FALSE;
		$this->template->header->js = new View('footer_form_js');
		$this->template->header->flot_enabled = FALSE;
		$this->template->header->colorpicker_enabled = FALSE;
		
		$this->template->header->this_page = "";
		
		// Google Analytics
		$google_analytics = Kohana::config('settings.google_analytics');
		$this->template->footer->google_analytics = $this->_google_analytics($google_analytics);
		
		// Create Language Session
		if (isset($_GET['lang']) && !empty($_GET['lang'])) {
			$_SESSION['lang'] = $_GET['lang'];
		}
		if (isset($_SESSION['lang']) && !empty($_SESSION['lang'])){
			Kohana::config_set('locale.language', $_SESSION['lang']);
		}
		$this->template->header->site_language = Kohana::config('locale.language');
		
		//Set up tracking gif
		if($_SERVER['SERVER_NAME'] != 'localhost' && $_SERVER['SERVER_NAME'] != '127.0.0.1'){
			$track_url = $_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
		}else{
			$track_url = 'null';
		}
		$this->template->footer->tracker_url = 'http://tracker.ushahidi.com/track.php?url='.urlencode($track_url).'&lang='.$this->template->header->site_language.'';
        		
	}

	public function index()
	{
		// Send them to the right page
		url::redirect('profile/dashboard');
	}

	function get_user_info()
	{
		$juser =& JFactory::getUser();
		$usr_name = $juser->get('name');
		$usr_username = $juser->get('email');
		$usr_email = $juser->get('email');
		$userid = $juser->get('id');
		
		$user_info = array();
		$user_info = array('name'=> $juser->get('name'),
							'username'=> $juser->get('username'),
							'email'=> $juser->get('email'),
							'id'=> $juser->get('id'),
							);
							
		$user_info['id'] = self::get_pcoe_id($user_info['id']);					
		return $user_info;					
	}
	
	function get_pcoe_id($id=false)
	{	
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT pcoe_id FROM {$table_prefix}pcoe_id_xref WHERE `j_id`='$id'";
				
		$jdb->setQuery($q);
		$id = $jdb->loadResult();
		
		return $id;
	}
	
	function check_pcoe_registered($username)
	{				
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT id FROM {$table_prefix}users WHERE `username`='$username'";
				
		$jdb->setQuery($q);
		$id = $jdb->loadResult();			

		return $id;				
	}
	
	function get_pcoe_info($id)
	{
		$pcoe = ORM::factory('user',$id);
		return $pcoe;
	}
	
	function add_j_user()
	{
		$juser = self::get_juser_info();
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "INSERT INTO {$table_prefix}users(`name`,`username`,`email`,`password`) 
				VALUES('{$juser['name']}','{$juser['username']}','{$juser['email']}','')";
				
		$jdb->setQuery($q);
		$jdb->query();
		$pcoe_id = $jdb->insertid();

		self::update_roles_table($pcoe_id);
		self::update_xref_table($juser['id'],$pcoe_id);
	}
	
	function update_roles_table($id)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
	
		$q = "SELECT count(`user_id`) FROM {$table_prefix}roles_users WHERE `user_id`='$id' AND `role_id`=1";
		$jdb->setQuery($q);
		$count = $jdb->loadResult();
		
		if($count=='0')
		{
			$q = "INSERT INTO {$table_prefix}roles_users(`user_id`,`role_id`) 
					VALUES('$id','1')";
				
			$jdb->setQuery($q);
			$jdb->query();
				
		}	
	}
	
	function update_xref_table($jid,$pcoe_id)
	{
		if($jid and $pcoe_id)
		{
			$jdb=JFactory::getDBO();
		    $table_prefix = Kohana::config('database.default.table_prefix');
			
			$q = "INSERT INTO {$table_prefix}pcoe_id_xref(`j_id`,`pcoe_id`) 
						VALUES('$jid','$pcoe_id')";
					
				$jdb->setQuery($q);
				$jdb->query();
								
		}
		else
			return false;
	}
	
	function get_juser_info()
	{
		$juser =& JFactory::getUser();
		$usr_name = $juser->get('name');
		$usr_username = $juser->get('email');
		$usr_email = $juser->get('email');
		$userid = $juser->get('id');
		
		$user_info = array();
		$user_info = array('name'=> $juser->get('name'),
							'username'=> $juser->get('username'),
							'email'=> $juser->get('email'),
							'id'=> $juser->get('id'),
							);
		return $user_info;					
	}

	function get_incident_info($id)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT inc.*,inc.id AS incident_id, loc.*,loc.id AS location_id FROM {$table_prefix}incident AS inc
				LEFT JOIN {$table_prefix}location as loc 
				ON inc.location_id = loc.id
				WHERE inc.id = '$id'";
				
		$jdb->setQuery($q);
		return $jdb->loadObject();
	}
	
	function get_update_info($id)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT * FROM {$table_prefix}update WHERE id = '$id'";
			
		$jdb->setQuery($q);
		return $jdb->loadObject();
	}
	
	function get_usr_incident_id($user_id)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT id FROM {$table_prefix}incident WHERE user_id = '$user_id' ORDER BY id ASC LIMIT 1";
			
		$jdb->setQuery($q);
		return $jdb->loadResult();
	}
	
	function get_project_comment($incident_id,$update_id=0)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT * FROM {$table_prefix}comment WHERE `incident_id` = '$incident_id' 
				AND `update_id` = '$update_id'";
			
		$jdb->setQuery($q);
		return $jdb->loadObjectList();
	}
	
	function project_has_comment($incident_id,$update_id=0)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT count(id) FROM {$table_prefix}comment WHERE `incident_id` = '$incident_id' 
				AND `update_id` = '$update_id'";
			
		$jdb->setQuery($q);
		return $jdb->loadResult();
	}
	
	function get_project_comments_count($incident_id,$update=false)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		
		if($update)
		{
			$q = "SELECT count(id) FROM {$table_prefix}comment WHERE `update_id` = '$incident_id'"; 
		}
		else
		{
			$q = "SELECT count(id) FROM {$table_prefix}comment WHERE `incident_id` = '$incident_id' 
					AND `update_id` = '0'";
		}			
			
		$jdb->setQuery($q);
		return $jdb->loadResult();		
	}
	
	function get_incident_categories($id)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT category_id FROM {$table_prefix}incident_category WHERE incident_id = '$id'";
		$jdb->setQuery($q);
		return $jdb->loadResultArray();
	}
	
	function get_incident_media($id)
	{
		$jdb=JFactory::getDBO();
	    $table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT * FROM {$table_prefix}media WHERE incident_id = '$id'";
			
		$jdb->setQuery($q);
		return $jdb->loadObjectList();
	}
	
	function get_cities()
	{
		$cities = ORM::factory('city')->orderby('city', 'asc')->find_all();
		$city_select = array('' => Kohana::lang('ui_main.reports_select_city'));
		
		foreach ($cities as $city) 
		{
			$city_select[$city->city_lon.",".$city->city_lat] = $city->city;
		}
		
		return $city_select;
	}
	
	function get_categories($selected_categories)
	{
		// Count categories to determine column length
		$categories_total = ORM::factory('category')
                            ->where('category_visible', '1')
                            ->count_all();

		$this->template->content->categories_total = $categories_total;

		$categories = array();

		foreach (ORM::factory('category')
                 ->where('category_visible', '1')
                 ->find_all() as $category)
		{
			// Create a list of all categories
			$categories[$category->id] = array($category->category_title, $category->category_color);
		}

		return $categories;
	}
	
	function color_picker_js()
    {
     return "<script type=\"text/javascript\">
				jQuery(document).ready(function() {
                jQuery('#category_color').ColorPicker({
                        onSubmit: function(hsb, hex, rgb) {
                            jQuery('#category_color').val(hex);
                        },
                        onChange: function(hsb, hex, rgb) {
                            jQuery('#category_color').val(hex);
                        },
                        onBeforeShow: function () {
                            jQuery(this).ColorPickerSetColor(this.value);
                        }
                    })
                .bind('keyup', function(){
                    jQuery(this).ColorPickerSetColor(this.value);
                });
				});
            </script>";
    }
		
    function date_picker_js()
    {
        return "<script type=\"text/javascript\">
				jQuery(document).ready(function() {
				jQuery(\"#incident_date\").datepicker({ 
				showOn: \"both\", 
				buttonImage: \"" . url::base() . "media/img/icon-calendar.gif\", 
				buttonImageOnly: true 
				});
				});
			</script>";	
    }
	
	function get_thumbnails( $id )
	{
		$incident = ORM::factory('incident', $id);
		
		if ( $id )
		{
			$incident = ORM::factory('incident', $id);
			
			return $incident;
		
		}
		return "0";
	}
	
	
    // Time functions
    function hour_array()
    {
        for ($i=1; $i <= 12 ; $i++) 
        { 
		    $hour_array[sprintf("%02d", $i)] = sprintf("%02d", $i); 	// Add Leading Zero
		}
	    return $hour_array;	
	}
									
	function minute_array()
	{								
		for ($j=0; $j <= 59 ; $j++) 
		{ 
			$minute_array[sprintf("%02d", $j)] = sprintf("%02d", $j);	// Add Leading Zero
		}
		
		return $minute_array;
	}
	
	function ampm_array()
	{								
	    return $ampm_array = array('pm'=>'pm','am'=>'am');
	}
	
	function get_custom_form_fields($incident_id = false, $form_id = 1, $data_only = false)
    {
		$fields_array = array();
		
		if (!$form_id)
		{
			$form_id = 1;
		}
		$custom_form = ORM::factory('form', $form_id)->orderby('field_position','asc');
		foreach ($custom_form->form_field as $custom_formfield)
		{
			if ($data_only)
			{ // Return Data Only
				$fields_array[$custom_formfield->id] = '';
				
				foreach ($custom_formfield->form_response as $form_response)
				{
					if ($form_response->incident_id == $incident_id)
					{
						$fields_array[$custom_formfield->id] = $form_response->form_response;
					}
				}
			}
			else
			{ // Return Field Structure
				$fields_array[$custom_formfield->id] = array(
					'field_id' => $custom_formfield->id,
					'field_name' => $custom_formfield->field_name,
					'field_type' => $custom_formfield->field_type,
					'field_required' => $custom_formfield->field_required,
					'field_maxlength' => $custom_formfield->field_maxlength,
					'field_height' => $custom_formfield->field_height,
					'field_width' => $custom_formfield->field_width,
					'field_isdate' => $custom_formfield->field_isdate,
					'field_response' => ''
					);
			}
		}
		
		return $fields_array;
    }
   
	function deletePhoto ( $id )
	{
		$this->auto_render = FALSE;
		$this->template = "";
		
		if ( $id )
		{
			$photo = ORM::factory('media', $id);
			$photo_large = $photo->media_link;
			$photo_thumb = $photo->media_thumb;
			
			// Delete Files from Directory
			if (!empty($photo_large))
				unlink(Kohana::config('upload.directory', TRUE) . $photo_large);
			if (!empty($photo_thumb))
				unlink(Kohana::config('upload.directory', TRUE) . $photo_thumb);

			// Finally Remove from DB
			$photo->delete();
		}
	}	
	
	function get_usr_project($user_id)
	{
		$jdb=JFactory::getDBO();
		$table_prefix = Kohana::config('database.default.table_prefix');
		
		$q = "SELECT `incident`.*, `status`.verified_status,location.location_name FROM {$table_prefix}incident AS incident  
				LEFT JOIN {$table_prefix}verified AS `status` ON `incident`.id = `status`.incident_id	
				LEFT JOIN {$table_prefix}location AS `location` ON `incident`.location_id = `location`.id	
				WHERE `incident`.user_id = '$user_id' ORDER BY `incident`.id ASC LIMIT 1";
				
		$jdb->Quote($q);
		$jdb->setQuery($q);
		$projects = $jdb->loadObject();
		
		
		if($projects)
		{					
			return $projects;		
		}
		return false;
	}
	
	function get_usr_updates($user_id)
	{
		$jdb=JFactory::getDBO();
		$table_prefix = Kohana::config('database.default.table_prefix');
		$q = "SELECT * FROM {$table_prefix}update WHERE user_id = '$user_id' ORDER BY id ASC";
		
		$jdb->setQuery($q);
		$updates = $jdb->loadObjectList();
		
		if($updates)
		{	
			return $updates;		
		}
		else
			return false;
	
	}

	function _google_analytics($google_analytics = false)
	{
		$html = "";
		if (!empty($google_analytics)) {
			$html = "<script type=\"text/javascript\">
				var gaJsHost = ((\"https:\" == document.location.protocol) ? \"https://ssl.\" : \"http://www.\");
				document.write(unescape(\"%3Cscript src='\" + gaJsHost + \"google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E\"));
				</script>
				<script type=\"text/javascript\">
				var pageTracker = _gat._getTracker(\"" . $google_analytics . "\");
				pageTracker._trackPageview();
				</script>";
		}
		return $html;
	}	
	
	function get_new_project_msg()
	{
		//set default text 
		$display_msg = "Your project has been saved. " ;
				
		require_once(JPATH_SITE."/libraries/joomla/application/module/helper.php"); 
		$module = JModuleHelper::getModule( 'bb_projectmsg' );
		if($module)
		{
			$params	= new JParameter( $module->params );
			$text = $params->get('text');			
			
			if($text)
				$display_msg = nl2br($text);						
		}
		
		return $display_msg;
	}

} // End Admin
