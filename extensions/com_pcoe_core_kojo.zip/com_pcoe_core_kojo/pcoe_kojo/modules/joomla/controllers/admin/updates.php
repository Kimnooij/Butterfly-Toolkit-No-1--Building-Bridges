<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Reports Controller.
 * This controller will take care of adding and editing reports in the Admin section.
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license 
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     Ushahidi Team <team@ushahidi.com> 
 * @package    Ushahidi - http://source.ushahididev.com
 * @module     Admin Reports Controller  
 * @copyright  Ushahidi - http://www.ushahidi.com
 * @license    http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License (LGPL) 
 */

class Updates_Controller extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
	
		$this->template->this_page = 'updates';
	}
	
	
	/**
	* Lists the reports.
    * @param int $page
    */
	function index()
	{
		Updates_Controller::get_updates();
		
	}
	
	function project($id=false)
	{
		if($id)
		{
			Updates_Controller::get_project_updates($id);
		}
		else
		{
			Updates_Controller::get_updates();
		}
	}
	
	function get_updates()
	{
		$this->template->content = new View('admin/updates');
		$this->template->content->title = 'Updates';
					
		$form_error = FALSE;
		$form_saved = FALSE;
		$form_action = "";
		$sortby = '';
		
		if ($_POST)
	    {
			$post = Validation::factory($_POST);			
	         //  Add some filters
	        $post->pre_filter('trim', TRUE);
			
	        // Add some rules, the input field, followed by a list of checks, carried out in order
			$post->add_rules('action','required', 'alpha', 'length[1,1]');
			$post->add_rules('update_id.*','required','numeric');
			
			if ($post->validate())
	        {
				if ($post->action == 'd')	//Delete Action
				{
					$status = Updates_Controller::delete_update();
					$form_saved = $status['form_saved'];
					$form_action = $status['form_action'];					
				}
			}
			else
			{
				$form_error = TRUE;
			}
		}
		// Pagination
		$pagination = new Pagination(array(
			'query_string'    => 'page',
			'items_per_page' => (int) Kohana::config('settings.items_per_page_admin'),
			'total_items'    => ORM::factory('update')->count_all()
		));

		$updates = ORM::factory('update')	
			->select('update.*')
			->select('incident.incident_title')
			->select('location.location_name')
			->join('incident', 'update.incident_id', 'incident.id','LEFT')
			->join('location', 'incident.location_id', 'location.id','LEFT')
			->orderby('update_dateadd', 'desc')
			->find_all((int) Kohana::config('settings.items_per_page_admin'), $pagination->sql_offset);
		
						
		$this->template->content->updates = $updates;
		$this->template->content->pagination = $pagination;
		$this->template->content->form_error = $form_error;
		$this->template->content->form_saved = $form_saved;
		$this->template->content->form_action = $form_action;
		
		// Total Reports
		$this->template->content->total_items = $pagination->total_items;
		
		// Javascript Header
		$this->template->js = new View('admin/update_js');	
	}
	
	function get_project_updates($incident_id)
	{
		$this->template->content = new View('admin/project_updates');
		$this->template->content->title = 'Updates';
					
		$form_error = FALSE;
		$form_saved = FALSE;
		$form_action = "";
		
		if ($_POST)
	    {
			$post = Validation::factory($_POST);			
	         //  Add some filters
	        $post->pre_filter('trim', TRUE);

	        // Add some rules, the input field, followed by a list of checks, carried out in order
			$post->add_rules('action','required', 'alpha', 'length[1,1]');
			$post->add_rules('update_id.*','required','numeric');
			
			if ($post->validate())
	        {
				if ($post->action == 'd')	//Delete Action
				{
					$status = Updates_Controller::delete_update();
					$form_saved = $status['form_saved'];
					$form_action = $status['form_action'];					
				}
			}
			else
			{
				$form_error = TRUE;
			}
		}
		
		$incident = ORM::factory('incident', $incident_id);
		$location = ORM::factory('location', $incident->location_id);
		$person = ORM::factory('incident_person')
					->where('incident_id',$incident_id)->find();

		// Pagination
		$pagination = new Pagination(array(
			'query_string'    => 'page',
			'items_per_page' => (int) Kohana::config('settings.items_per_page_admin'),
			'total_items'    => ORM::factory('update')->where('incident_id',$incident_id)->count_all()
		));
	
		$updates = ORM::factory('update')
			->where('incident_id',$incident_id)
			->orderby('update_dateadd', 'desc')
			->find_all((int) Kohana::config('settings.items_per_page_admin'), $pagination->sql_offset);
						
		$this->template->content->form_error = $form_error;
		$this->template->content->form_saved = $form_saved;
		$this->template->content->form_action = $form_action;
		
		$this->template->content->updates = $updates;
		$this->template->content->incident = $incident;
		$this->template->content->location = $location;
		$this->template->content->person = $person;
		$this->template->content->pagination = $pagination;		
		$this->template->content->total_items = $pagination->total_items;
		
		// Javascript Header
		$this->template->js = new View('admin/update_js');	
		
	}
	
	function delete_update()
	{
		$form_error = FALSE;
		$form_saved = FALSE;
		$form_action = "";
	    if ($_POST)
	    {
			$post = Validation::factory($_POST);			
	       
			foreach($post->update_id as $item)
			{
				$update = new Update_Model($item);
				if ($update->loaded == true) {
					$update_id = $update->id;
					$update->delete();							
					
					// Delete Comments
					ORM::factory('comment')->where('update_id',$update_id)->delete_all();
				}					
			}
			$form_action = "DELETED";		
			$form_saved = TRUE;			
			
		}
		$status = array(
						'form_action'=>$form_action,
						'form_saved'=>$form_saved,
						'form_error'=>$form_error,
						);
		return $status;
	}
}
