<?php
$lang = array
(
	'more_lbl' => 'MORE',
	'no_report_in_system_lbl' => 'No Reports In The System',
	'submit_by_tweet_lbl' => 'By sending a tweet with the hashtag/s ',
	'submit_by_email_lbl' => 'By sending an email to ',
	'submit_by_msg_lbl' => 'By sending a message to ',
	'how_to_report_lbl' => 'HOW TO REPORT',
	'other_ushahidi_instances_lbl' => 'OTHER USHAHIDI INSTANCES',
	'all_categories_lbl' => 'All Categories',
	'category_filter_lbl' => 'CATEGORY FILTER',
	'to_lbl' => 'To',
	'from_lbl' => 'From',
	'play_lbl' => 'PLAY',
	'by_lbl' => 'By ',
	'filling_a_form' => 'filling a form',
	'at_the_website_lbl' => ' at the website',
	'official_news' => 'Latest news Building Bridges Community',
	'incidents_listed' => 'Latest Initiatives',
);
?>