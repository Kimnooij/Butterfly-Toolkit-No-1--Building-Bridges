<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


function com_pcoe_core_kojo_install()
{
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	jimport('joomla.filesystem.archive');
	jimport('joomla.filesystem.path');

	// Get the uploaded file information
	$userfile = JRequest::getVar('install_package', null, 'files', 'array' );

	$installer=JInstaller::getInstance();
	
	$tmp_source= $installer->getPath('source');
	
	// Build the appropriate paths
	$config =& JFactory::getConfig();
	$from_path 	= $tmp_source.DS.'pcoe_kojo'.DS;			
	$to_path=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS;

/*
	$from_path=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoecore' .DS.'pcoe_patches'.DS;
	$to_path=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoecore' .DS.'pcoe'.DS;
	*/
	$files=JFolder::files($from_path, '.', true, true);
	$suffix=date('_Y_m_d_H_i_s',mktime());
	foreach($files as $file)
	{
		$from_file=$file;
		$end_path=str_replace($from_path,'',$from_file);
		$to_file=$to_path.$end_path;
		$to_file_path=dirname($to_file);
		if(JFile::exists($to_file))
		{
			$ext='.' . JFile::getExt($to_file);
			$new_ext=$suffix.'.' . $ext;
			$rename_to_file=str_replace($ext,$new_ext,$to_file);
			JFile::move($to_file,$rename_to_file);
		}
		JFolder::create($to_file_path);
		JFile::copy($from_file,$to_file);		
	}
	return true;

}
?>