<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
$cutter_functions = JPATH_SITE."/modules/mod_cutter/functions/helper.php";
$centralmap_functions = JPATH_SITE."/modules/mod_pcoe_centralmap/functions/helper.php";

if(JFile::exists($centralmap_functions))
{
  require_once($centralmap_functions);
  $script = modPcoeCentralMapHelper::centralMapPublishedScript('Period Filter Module');
  echo $script;
}

if(JFile::exists($cutter_functions))
{
  require_once($cutter_functions);
  
  //$url = trim($params->get('url'));
  $url = modCutterHelper::getPcoeUrl();
  $tag = trim($params->get('tag'));
  $attribute = trim($params->get('attribute'));
  $value = trim($params->get('value'));
  $index = trim($params->get('index'));
  $post_script = trim($params->get('post_script'));
  //$pre_script = $params->get('pre_script');
  	
  if($url)
  {
  	$html = modCutterHelper::cutUrlHtmlContentNode($url,$tag,$attribute,$value,$index);
  	
  	if($post_script)
  	{
  		$script_dir = dirname(__FILE__)."/functions/";
  		$html = modCutterHelper::postProcessScript($html,$post_script, $script_dir);	
  	}
  	modCutterHelper::printResult($html);
  }
}


?>