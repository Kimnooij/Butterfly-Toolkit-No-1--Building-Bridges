<?php
defined('_JEXEC') or die('Restricted access');

class modCutter_Cut_play_btn_processor
{
	function cutterPostProcessor($html)
	{
		$html = modCutter_Cut_play_btn_processor::cutPlayBtn($html);
		return $html;	
	}	

	function cutPlayBtn($html)
	{
		if($html)
		{		
			$script_tags = modCutterHelper::cutAllCssJsTags($html);			
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
				
			$query ="//select";
			$dom = modCutterHelper::removeNodeElements($query, $dom);			
			
			$query ="//label";
			$dom = modCutterHelper::removeNodeElements($query, $dom);
			
			$innerHTML = modCutterHelper::convertDomToHtml($dom);
			$html = $script_tags.$innerHTML;
		}
		return $html;
	}
}
?>