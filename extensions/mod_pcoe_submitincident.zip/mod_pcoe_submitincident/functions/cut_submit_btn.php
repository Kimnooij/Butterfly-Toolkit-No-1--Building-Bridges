<?php
defined('_JEXEC') or die('Restricted access');

class modCutter_Cut_submit_btn_processor
{
  function cutterPostProcessor($html)
  {
  	$html = modCutter_Cut_submit_btn_processor::cutSubmitBtn($html);
  	return $html;	
  }	
  
	function cutSubmitBtn($html)
	{
		if($html)
	  	{		
	  		$script_tags = modCutterHelper::cutAllCssJsTags($html);	  		
	  		$dom = modCutterHelper::convertHtmlToDomDoc($html);
	  		
			//multiple classes query
			$tag = "div";
			$attribute = "class";
			$value = "grey-box";

			$query = modCutterHelper::singleAttributeExtendedQuery($tag, $attribute, $value);
			$dom = modCutterHelper::removeNodeElements($query, $dom);
			
	  		$query ="//strong";
			$dom = modCutterHelper::removeNodeElements($query, $dom);
	  		
	  		$innerHTML = modCutterHelper::convertDomToHtml($dom);
	  		$html = $innerHTML;
	  		$html = $script_tags.$innerHTML;
	  	}
	  	return $html;
	}
}
?>