<?php
defined('_JEXEC') or die('Restricted access');
class modCutterHelper
{
	//cuts a particular html content node from a given Url
	//caches the html content for the next call within the same request

	function cutUrlHtmlContentNode($url,$tag,$attribute,$value,$index)
	{
		$url=trim($url);

		//global variable names to cach content and cssJs tags
		$urlContent='mod_cutter_content_'.md5($url);
		$urlCssJs='mod_cutter_css_js'.md5($url);

		if(empty($GLOBALS[$urlContent]))
		{
			//FIRST TIME --> SINGLETON PATTERN
			$GLOBALS[$urlContent]=modCutterHelper::readUrlContent($url);
			$GLOBALS[$urlCssJs]=modCutterHelper::cutAllCssJsTags($GLOBALS[$urlContent]);
		}
	   
		$htmlNode=modCutterHelper::cutHtmlNode($GLOBALS[$urlContent],$tag,$attribute,$value,$index);
		$result=$GLOBALS[$urlCssJs].$htmlNode;
		
		//make CssJs empty for the next call
		//never return it twice
		$GLOBALS[$urlCssJs]='';
		
		return $result;
	}

	//Reads a Url from the web or from the file system

	function readUrlContent($url)
	{
		if(modCutterHelper::strStartsWith($url,'http://')) 
			return modCutterHelper::readHttpUrlContent($url);
		else 
			return modCutterHelper::readFileUrlContent($url);
	}

	function strStartsWith($string,$prefix)
	{
		if(strncmp($string, $prefix, strlen($prefix)) == 0) return true;
		else return false;
	}

	function readHttpUrlContent($url) 
	{  			
		$fp = fopen($url, "r");
		if($fp)
		{	
			$contents = '';
			while (!feof($fp)) 
			{
				$contents .= fread($fp, 8192);
			}
			fclose($fp);			
		}		
		return $contents;
	}

	function readFileUrlContent($url)
	{
		jimport('joomla.filesystem.file');
		$url = JPATH_SITE.DS.$url;   
		if(JFile::exists($url))
		{	
			ob_start();
			require_once($url);
			$result=ob_get_contents();
			ob_end_clean();
		}	
		return $result;
	}

	function cutAllCssJsTags($html) 
	{		
		$innerHTML = "";	
		if($html)
		{
			$html =  modCutterHelper::cleanScriptTags($html);
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
			$query = "//script|style";
			//Init the XPath object
			$xpath = new DOMXpath($dom);
			$results = $xpath->query( $query );
			
			if($results)
			{			
				$innerHTML = modCutterHelper::convertDomElementsToHtml($results);
				$innerHTML = htmlspecialchars_decode($innerHTML,ENT_QUOTES);
			}
			
			$query = "//link[@rel='stylesheet']";
			//Init the XPath object
			$results2 = $xpath->query( $query );
			
			if($results2)
			{			
				$innerHTML .= modCutterHelper::convertDomElementsToHtml($results2);
			}
		}	
		return $innerHTML;
	}

	function cutHtmlNode($html,$tag,$attribute,$value,$index)
	{
		$innerHTML = ""; 
		if($html)
		{
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
		
			if($tag)
			{
				$query = "//{$tag}";
				if($value and $attribute)
				{
					if($attribute == 'id')
			        {
			          $query .="[@{$attribute}='{$value}']";
			        }	
			        elseif($attribute)
			        {
						$query = modCutterHelper::singleAttributeExtendedQuery($tag, $attribute, $value);
					}							
				}
				if((int)$index > 0)
				{  
					$query .= "[$index]";  
				}
				
				$dom= modCutterHelper::convertHtmlToDomDoc($html);
				//Init the XPath object
				$xpath = new DOMXpath($dom);		
				$results = $xpath->query( $query );				
				if($results)
				{
					$innerHTML = modCutterHelper::convertDomElementsToHtml($results);
				}
			}
		}	
		return $innerHTML;
	}

	function convertHtmlToDomDoc($html)
	{
		$html = utf8_encode($html);
		$dom= new DOMDocument(); 
		@$dom->loadHTML($html);	
		$dom->preserveWhiteSpace = false; 
		$dom->formatOutput = true;
		return $dom;
	}

	function convertDomToHtml($dom)
	{
		//strip unwanted tags
		$remove_tags = array('<html>', '</html>', '<body>', '</body>');
		$replacement = array('', '', '', '');
		$pattern = '/^<!DOCTYPE.+?>/';
		$html = preg_replace($pattern, '', str_replace( $remove_tags, $replacement, trim(@$dom->saveHTML())));	
		return $html;
	}

	function convertDomElementsToHtml($elements)
	{
		$innerHTML = '';
		if($elements)
		{
			foreach ($elements as $element) 
			{			
				$tmp_dom = new DOMDocument();
				$tmp_dom->appendChild($tmp_dom->importNode($element, true));
				$innerHTML .= modCutterHelper::convertDomToHtml($tmp_dom)."\n";
			} 	
		}	
		return $innerHTML;
	}

	function cleanScriptTags($html)
	{
		//encode html entities within script tags to avoid them being skipped (especially end tags) when converted to DOM
		$pattern = "{<script[^>]*>(.*?)</script>}msi";		
		preg_match_all ( $pattern , $html , $matches );
		if($matches)
		{
			$pattern2 = "{<script[^>]*(\s)src(\s)?=(\s)?[^>]*>}ms";
			foreach($matches[0] as $match)
			{
				preg_match_all ( $pattern2, $match , $matches2 );
				if($matches2[0])
				{
					continue;
				}
				else
				{
					$scripts[] = $match; 
					$replacement = modCutterHelper::getScriptContent($match);
					$html = str_replace($match, $replacement, $html);
					$rep[] = $replacement;
				}
			}
		}	
		return $html;	
	}

	function getScriptContent($html)
	{
		//strip <script> tag
		$pattern = "{<script[^>]*>}msi";
		preg_match_all ( $pattern , $html , $matches );
		if($matches[0])
		{
			$match = $matches[0][0];
			$html = str_replace($match, "", $html);
		}
		
		//strip </script> tag
		//$html = str_replace("</script>", "", $html);
		$html = modCutterHelper::stripScriptEndTag($html);		
		$html = htmlspecialchars($html, ENT_NOQUOTES, "UTF-8");	
		
		//attach script tags
		$html = $match.$html."</script>";
		return $html;
	}

	function appendChildNodes($dom, $elements)
	{
		$innerHTML = '';
		if($elements)
		{
			foreach ($elements as $element) 
			{	
				$dom->appendChild($dom->importNode($element, true)); 				
			} 	
		}	
		return $dom;
	}

	function endsWithString($fullStr, $endStr)
	{
	    if($fullStr  and $endStr)
		{
			$fullStr = trim($fullStr);
			$endStr = trim($endStr);
		    $strLen = strlen($endStr);
		    // Look at the end of FullStr for the substring the size of EndStr
		    $fullStrEnd = substr($fullStr, strlen($fullStr) - $strLen);
			if(strtolower($fullStrEnd) == strtolower($endStr))
				return true;
			else
				return false;
		}
		return false;
	}
	
	function stripLastStrOccurance($fullStr, $subStr)
	{
		if (strpos($fullStr, $subStr)!==false)
		{
			$pos = strripos($fullStr, $subStr);
			if($pos !== false)
			{	
				$fullStr=substr_replace($fullStr,"",$pos,strlen($subStr));		
			}	
		}
		return $fullStr;	
	}

	function stripScriptEndTag($scrtipt)
	{
		if(modCutterHelper::endsWithString($scrtipt, "</script>"))
		{
			$script = modCutterHelper::stripLastStrOccurance($scrtipt, "</script>");
		}
		return $script;
	}
	
	//execute post script processor 
	function postProcessScript($html, $post_script,$script_dir)
	{
		if($html and $post_script and $script_dir)
		{			
			jimport('joomla.filesystem.file');
			if(modCutterHelper::endsWithString($post_script, ".php"))
			{
				$className = modCutterHelper::stripLastStrOccurance($post_script, ".php");
			}
			else
			{
				$className = $post_script;
				$post_script .= ".php";
			}
					
			$script_file = $script_dir.$post_script;
			if(JFile::exists($script_file))
			{
				include_once($script_file);
				$className = "modCutter_".ucfirst($className)."_processor";
				$post_script = new $className;
				$html = $post_script->cutterPostProcessor($html);
			}		
		}
		return $html;
	}
	
	function printResult($html)
	{		
/*	  	
		//Process the prepare content plugins	  		
	  	$article=new stdClass();
	  	$article->text=$html;
	  	$cutter_params=array();
	  	$dispatcher	=& JDispatcher::getInstance();
	  	JPluginHelper::importPlugin('content');
	  	$results = $dispatcher->trigger('onPrepareContent', array ($article, $cutter_params));		
	  	echo $article->text;
*/		
		echo $html;
		return;
	}
	
	function singleAttributeExtendedQuery($tag, $attribute, $value)
	{		
		//$query = "//{$tag}[contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$value}', ' ' )) ]";
		$class_prefix = modCutterHelper::getCutterClassPrefix();
		$query = "//{$tag}[contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$value}', ' ' )) ";
		$query .= " or contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$class_prefix}{$value}', ' ' )) ]";
		return $query;
	}
	
	function doubleAttributeExtendedQuery($tag, $attribute, $value, $attribute2, $value2)
	{	
		//$query = "//{$tag}[contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$value}', ' ' )) or contains(concat( ' ', @{$attribute2}, ' ' ),concat( ' ', '{$value2}', ' ' )) ]";
		$class_prefix = modCutterHelper::getCutterClassPrefix();
		$query = "//{$tag}[contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$value}', ' ' )) or contains(concat( ' ', @{$attribute2}, ' ' ),concat( ' ', '{$value2}', ' ' )) ";
		$query .= " or contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$class_prefix}{$value}', ' ' )) or contains(concat( ' ', @{$attribute2}, ' ' ),concat( ' ', '{$class_prefix}{$value2}', ' ' )) ]";
		return $query;
	}
	
	function tripleAttributeExtendedQuery($tag, $attribute, $value, $attribute2, $value2, $attribute3, $value3)
	{		
		//$query = "//{$tag}[contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$value}', ' ' )) or contains(concat( ' ', @{$attribute2}, ' ' ),concat( ' ', '{$value2}', ' ' )) or contains(concat( ' ', @{$attribute3}, ' ' ),concat( ' ', '{$value3}', ' ' ))]";
		$class_prefix = modCutterHelper::getCutterClassPrefix();
		$query = "//{$tag}[contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$value}', ' ' )) or contains(concat( ' ', @{$attribute2}, ' ' ),concat( ' ', '{$value2}', ' ' )) or contains(concat( ' ', @{$attribute3}, ' ' ),concat( ' ', '{$value3}', ' ' )) ";
		$query .= " or contains(concat( ' ', @{$attribute}, ' ' ),concat( ' ', '{$class_prefix}{$value}', ' ' )) or contains(concat( ' ', @{$attribute2}, ' ' ),concat( ' ', '{$class_prefix}{$value2}', ' ' )) or contains(concat( ' ', @{$attribute3}, ' ' ),concat( ' ', '{$class_prefix}{$value3}', ' ' ))]";		
		return $query;	
	}
	
	function getCutterClassPrefix()
	{
		jimport('joomla.filesystem.file');
		$cssmapper_function_file = JPATH_ADMINISTRATOR.'/components/com_cssmapper/functions/cutter_helper.php';                                                                                                
		if(JFile::exists($cssmapper_function_file))
		{
	      require_once($cssmapper_function_file);   		  
	      $prefix = CssMapperCutterHelper::getCutterClassPrefix();
	      return $prefix;
	    }		
	    return "cutter-";
	}
	
	function getPcoeUrl()
	{		
		$db		=& JFactory::getDBO();
		$query = "SELECT id, params FROM #__modules WHERE module = 'mod_cutter'";		
		$db->setQuery( $query );
		$cutter = $db->loadObject();
		$url = '';
		if($cutter)
		{
			$cutter_params = new JParameter( $cutter->params );
			$url = $cutter_params->get('url');
		}
		return $url;		
	}
	
	function removeNodeElements($query, $dom)
	{
		if($dom != null)	
		{
			//Init the XPath object
			$xpath = new DOMXpath($dom);		
			$results = $xpath->query( $query );
			if($results != null)
			{
				foreach ($results as $element) 
				{				
					$element->parentNode->removeChild($element);				
				}		
			}
		}	
		return $dom;
	}
}	
?>