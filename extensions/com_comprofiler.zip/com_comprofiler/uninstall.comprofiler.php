<?php
/**
* Joomla Community Builder
* @version $Id: uninstall.comprofiler.php 399 2006-09-01 19:48:49Z beat $
* @package Community Builder
* @subpackage uninstall.comprofiler.php
* @author JoomlaJoe and Beat
* @copyright (C) JoomlaJoe and Beat, www.joomlapolis.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

// ensure this file is being included by a parent file
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

function com_uninstall() {
  echo "Component successfully uninstalled.";
}

?>