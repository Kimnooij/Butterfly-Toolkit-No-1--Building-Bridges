<?php
defined('_JEXEC') or die('Restricted access');

//removes the google map leaving the period graph
class modCutter_Cut_media_filter_processor
{
	function cutterPostProcessor($html)
	{
		$html = modCutter_Cut_media_filter_processor::cutMediaFilter($html);
		return $html;	
	}	

	function cutMediaFilter($html)
	{
		if($html)
		{
			//extract script tags
			$script_tags = modCutterHelper::cutAllCssJsTags($html);			
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
				
			//multiple classes query
			$tag = "div";
			$attribute = "class";
			$value = "slider-holder";
			$attribute2 = "id";
			$value2 = "map";
			$attribute3 = "id";
			$value3 = "graph";

			$query = modCutterHelper::tripleAttributeExtendedQuery($tag, $attribute, $value, $attribute2, $value2, $attribute3, $value3);
			$dom = modCutterHelper::removeNodeElements($query, $dom);
			 	
			$innerHTML = modCutterHelper::convertDomToHtml($dom);
			$html = $script_tags.$innerHTML;
		}
		return $html; 	
	}
}	
?>