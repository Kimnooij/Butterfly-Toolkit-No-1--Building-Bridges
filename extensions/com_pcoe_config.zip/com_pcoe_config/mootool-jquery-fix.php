<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );
function mootool_jquery_resolve_conflict($paths)
{
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	jimport('joomla.filesystem.archive');
	jimport('joomla.filesystem.path');
	
	$finds=array();
	$replaces=array();
	$finds[]='$(';
	$finds[]='$.';
	$finds[]='$[';
	$replaces[]='jQuery(';
	$replaces[]='jQuery.';
	$replaces[]='jQuery[';
	
	$status = true;

	if($paths)
	{
		foreach($paths as $path)
		{
			if(JFolder::exists($path))
			{
				$files=JFolder::files($path, '.', true, true);
				
				if($files)
				{
					foreach($files as $file)
					{
						if(JFile::exists($file))
						{	
							//Check src path
							if (is_readable($file)) 
							{
								$content=JFile::read($file);
								foreach($finds as $find)
								{			
									if(strpos($content,$find))
									{				
										$file_path[0] = $file;
										$status = permission_settings::setPermission($file_path,false,false);
										$content=str_replace($finds,$replaces,$content);
										if(!JFile::write($file,$content) and $status)
										{
											$status = false;
										}
										break;
									}
								}
								//echo 'mootool_jquery_resolve_conflict : ' . $file . '<br>';
							}
						}				
					}
				}
			}
		}
	}
	return $status;
}

function apply_mootool_jquery_conflict_fix_to_file($files)
{
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	jimport('joomla.filesystem.archive');
	jimport('joomla.filesystem.path');
	
	$finds=array();
	$replaces=array();
	$finds[]='$(';
	$finds[]='$.';
	$finds[]='$[';
	$replaces[]='jQuery(';
	$replaces[]='jQuery.';
	$replaces[]='jQuery[';
	
	$status = true;

	if($files)
	{
		foreach($files as $file)
		{

			if(JFile::exists($file))
			{	
				//Check src path
				if (is_readable($file)) 
				{
					$content=JFile::read($file);
					foreach($finds as $find)
					{			
						if(strpos($content,$find))
						{				
							$file_path[0] = $file;
							$status = permission_settings::setPermission($file_path,false,false);
							$content=str_replace($finds,$replaces,$content);
							if(!JFile::write($file,$content) and $status)
							{
								$status = false;
							}
							break;
						}
					}
					//echo 'mootool_jquery_resolve_conflict : ' . $file . '<br>';
				}
			}	
		}
		
	}
		
	return $status;
}
?>