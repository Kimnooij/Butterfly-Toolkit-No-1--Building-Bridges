<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

function cb_config()
{
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	require_once('permission_settings.php');
	
	//$ueConfig['reg_first_visit_url']
	$config_path = JPATH_ADMINISTRATOR."/components/com_comprofiler/";
	$tmpl_file = "ue_config.php";
	
	$config_file_path = $config_path.$tmpl_file;
	
	if(JFile::exists($config_file_path))
	{
		$config_file_path_clean = str_replace("\\", "/",$config_file_path);
		$files = array();
		$folders = array();
		$files[] = $config_file_path;
		permission_settings::setPermission($files);
		
		$config_file = JFile::read($config_file_path_clean);
		if($config_file)
		{
			$pattern = "{\\\$ueConfig\['reg_first_visit_url'\].*;}";
			preg_match_all ( $pattern , $config_file , $matches );		
			$matchString = $matches[0];
			
			$login_redirect_url = 'index.php?option=com_pcoe&view=dashboard';
			$configLineReplace = "\$ueConfig['reg_first_visit_url'] = '$login_redirect_url';";
			if($matchString)
			{
				$configLine = $matchString[0];		
				$pos = strpos($matchString[0],"com_pcoe");
				//if default url alrady set to pcoe do nothing
				if($pos !== false) 
				{
					echo "<br />CB configuration updated";
					return true;
				}			
				$config_file = str_replace($configLine, $configLineReplace, $config_file);
				if(write_config_file($config_file, $config_file_path))
				{		
					permission_settings::setPermission($files);
				}			
			}
			
		}
		else
		{
			echo "<strong><br />Failed to update CB config file
					<br />Please ensure first login redirect url is set to 
					index.php?option=com_pcoe&view=dashboard</strong>";
		}
	}
}


function write_config_file($content, $file_path) 
{
	jimport('joomla.filesystem.file');
	
	if(JFile::exists($file_path))
	{
		$failed_to_update_msg= "<strong><br />Failed to update CB config file
							<br />Please set first login redirect url to 
							index.php?option=com_pcoe&view=dashboard</strong>";
		
		$suffix=date('_Y_m_d_H_i_s',mktime());
		$ext='.' . JFile::getExt($file_path);
		$new_ext=$suffix . $ext;
		$rename_to_file=str_replace($ext,$new_ext,$file_path);
		if(JFile::move($file_path,$rename_to_file))
		{			
			if(JFile::write($file_path,$content))
			{				
				echo "<br />CB configuration updated";
				$files[] = $file_path;
				return true;					
			}
			else
			{			
				echo $failed_to_update_msg;
				if(JFile::move($rename_to_file,$file_path))
				{				
					echo "<br />CB backup config file restored";					
					delete_backup_file($rename_to_file);					
					return false;
				}
				else
				{				
					echo "<strong><br />CB backup config file could not be restored<br /> 
					Please restore it manually by renaming <br />
					$rename_to_file to $file_path
					</strong>
						";
					return false;	
				}
			}	
		}
		else
		{	
			echo $failed_to_update_msg;
			return false;
		}
	}
	return false;
}

function delete_backup_file($rename_to_file)
{
	jimport('joomla.filesystem.file');
	if(JFile::delete($rename_to_file))
	{
		echo "<br />CB backup config file deleted";
		return true;
	}
	else
	{
		echo "<br />CB backup config file could not be deleted";
	}
	return false;
}
 
?>