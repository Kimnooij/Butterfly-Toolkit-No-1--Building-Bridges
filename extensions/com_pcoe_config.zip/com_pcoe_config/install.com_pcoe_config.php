<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );
	
function com_pcoe_config_install()
{
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	jimport('joomla.filesystem.archive');
	jimport('joomla.filesystem.path');
	
	//----------- Change Folder Permission ------------------------------
	require_once('permission_settings.php');
	//permission_settings::set_folder_permission();
	$folders = array();
	$folders[] = JPATH_SITE.DS.'templates'.DS.'pcoe'.DS.'params.ini';
	permission_settings::setPermission($folders);
	echo '<br />';
	//----------- Enable PCOE Plugins --------------------------------
	$db=JFactory::getDBO();
	$plugins=array();
	$plugins[]=array('pcoe_sef','pcoe');
	$plugins[]=array('pcoe_search','search');
	$plugins[]=array('cssmapper','content');
	$plugins[]=array('pcoecssloader','system');	
	
	foreach($plugins as $plugin)
	{
		$q="UPDATE `#__plugins` 
			SET `published`=1
			WHERE `element`=".$db->quote($plugin[0])
			. " AND `folder`=".$db->quote($plugin[1]);
		$db->setQuery($q);
		
		if($db->query())
			echo '<br />Enable plugins : ' . $plugin[0] ;
		else
			echo '<br />Unable to enable plugins : ' . $plugin[0];
	}
	//----------- End Enable PCOE Plugins --------------------------------
	//----------- Update Default Template --------------------------------
	$default_template='pcoe';
	$q="UPDATE `#__templates_menu` 
		SET `template`=".$db->quote($default_template) 
		." WHERE menuid=0 AND client_id=0";
	$db->setQuery($q);
	$db->query();
	echo '<br />Set PCOE template as default';
	//----------- End Update Default Template ------------------------------	
	
	$cssmappers=array();
	$cssmappers[]=array('.*', 'content', 'content-pcoe');
	$cssmappers[]=array('.*', 'content-bg', 'content-background');
	$cssmappers[]=array('.*', 'report-btns', 'pcoe-report-btns');
	$cssmappers[]=array('.*', 'swatch', 'pcoe-swatch');
	$cssmappers[]=array('.*', 'grey-box', 'cutter-grey-box pcoe-grey-box');
	$cssmappers[]=array('.*', 'grey-box-bg', 'pcoe-grey-box-bg');
	$cssmappers[]=array('.*', 'filter', 'cutter-filter pcoe-filter');
	$cssmappers[]=array('.*', 'big-map-block', 'cutter-big-map-block pcoe-big-map-block');
	$cssmappers[]=array('.*', 'small-block', 'cutter-small-block pcoe-small-block');
	$cssmappers[]=array('.*', 'report_rowtitle', 'pcoe-report_rowtitle');
	$cssmappers[]=array('.*', 'org_row1', 'pcoe-org_row1');
	$cssmappers[]=array('.*', 'report_row1', 'pcoe-report_row1');
	$cssmappers[]=array('.*', 'report_details', 'pcoe-report_details');
	$cssmappers[]=array('.*', 'report_no', 'pcoe-report_no');
	$cssmappers[]=array('.*', 'report_yes', 'pcoe-report_yes');
	$cssmappers[]=array('.*', 'incident-name', 'pcoe-incident-name');
	$cssmappers[]=array('.*', 'report-description', 'pcoe-report-description');
	$cssmappers[]=array('.*', 'report_rating', 'pcoe-report_rating');
	$cssmappers[]=array('.*', 'report_row', 'pcoe-report_row');
	$cssmappers[]=array('.*', 'blocks-holder', 'pcoe-blocks-holder');
	$cssmappers[]=array('.*', 'report_col1', 'pcoe-report_col1');
	$cssmappers[]=array('.*', 'report_col2', 'pcoe-report_col2');
	$cssmappers[]=array('.*', 'report_col3', 'pcoe-report_col3');
	$cssmappers[]=array('.*', 'report_col4', 'pcoe-report_col4');
	$cssmappers[]=array('.*', 'report_col5', 'pcoe-report_col5');
	$cssmappers[]=array('.*', 'incident-map', 'pcoe-incident-map');
	$cssmappers[]=array('.*', 'step-1', 'pcoe-step-1');
	$cssmappers[]=array('.*', 'step-2', 'pcoe-step-2');
	$cssmappers[]=array('.*', 'step-2-holder', 'pcoe-step-2-holder');
	$cssmappers[]=array('.*', 'report_left', 'pcoe-report_left');
	$cssmappers[]=array('.*', 'report_right', 'pcoe-report_right');
	$cssmappers[]=array('.*', 'time', 'pcoe-time');
	$cssmappers[]=array('.*', 'report_optional', 'pcoe-report_optional');
	$cssmappers[]=array('.*', 'btn_blue', 'pcoe-btn_blue');
	$cssmappers[]=array('.*', 'report_bottom', 'pcoe-report_bottom');
	$cssmappers[]=array('.*', 'report_comment', 'pcoe-report_comment');
	$cssmappers[]=array('.*', 'green-box', 'pcoe-green-box');
	$cssmappers[]=array('.*', 'thanks_msg', 'pcoe-thanks_msg');
	$cssmappers[]=array('.*', 'search_block', 'pcoe-search_block');
	$cssmappers[]=array('.*', 'search_result', 'pcoe-search_result');
	$cssmappers[]=array('.*', 'search_result', 'pcoe-search_result');
	$cssmappers[]=array('.*', 'red-box', 'pcoe-red-box');
	$cssmappers[]=array('.*', 'report_map', 'pcoe-report_map');
	$cssmappers[]=array('.*', 'graph-holder', 'pcoe-graph-holder');
	foreach($cssmappers as $cssmapper)
	{
		$page_reg_exp=$db->Quote($cssmapper[0]);
		$src_css_class=$db->Quote($cssmapper[1]);
		$dest_css_class=$db->Quote($cssmapper[2]);
		$q="SELECT COUNT(*) 
			FROM `#__cssmapper` 
			WHERE `page_reg_exp`= {$page_reg_exp}
				AND `src_css_class`= {$src_css_class}
				AND `dest_css_class`= {dest_css_class}";
		$db->setQuery($q);
		if($db->loadResult()==0)
		{
			$q="INSERT INTO `#__cssmapper` (`page_reg_exp`, `src_css_class`, `dest_css_class`, `remark`) 
				VALUES({$page_reg_exp},{$src_css_class},{$dest_css_class},'')";
			$db->setQuery($q);
			$db->query();
		}
	}
	echo '<br />Add cssmapper data';
	
//==========fix jquery conflict=======
	require_once('mootool-jquery-fix.php');
	echo "<br />";
	$paths = array();
	$paths[]=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'application';
	$paths[]=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'modules'.DS.'joomla';
	
	if(mootool_jquery_resolve_conflict($paths))
	{
		echo '<br />Mootools/jQuery conflict resolved in backend';	
	}
	else
	{
		echo '<br /><strong>There was an error updating all files required to resolve Mootools/jQuery conflict</strong>';
	}
//================end===========

//====fix view links=====
	require_once('url_link_fix.php');
	echo "<br />";
	$paths[]=array();
	$paths[]=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'application'.DS.'views';
	$paths[]=JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe'.DS.'pcoe'.DS.'modules'.DS.'joomla'.DS.'views';
	
	if(fixUrlLinks($paths))
	{
		echo "<br><br> PCoE anchor links updated";
	}
	else
	{
		echo "<br /><br /><strong>There was an error updating PCoE anchor links</strong>";
	}
//==========end=========	
	echo "<br />";
	enable_pcoe_modules();
	fix_pcoe_user_table();
	
	//============building bridges patch=====	
	require_once('bb_patch.php');	
	building_bridges_patch();
	
	//======check/update CB configuration=
	require_once('cb_patch.php');	
	cb_config();
	
	//=========add menu items===	
	require_once('menu_items.php');	
	create_menu_items();
	
	echo "<br /><br />";
	return true;
}
function enable_pcoe_modules()
{
	$modules=array();
	$modules[]=array('mod_pcoe_mediafilter','breadcrumb2');
	$modules[]=array('mod_pcoe_centralmap','content-top-left');
	$modules[]=array('mod_pcoe_periodchart','content-middle-left2');
	$modules[]=array('mod_pcoe_periodfilter','content-middle-left');
	$modules[]=array('mod_pcoe_latestincidents','content-bottom-left');
	$modules[]=array('mod_pcoe_latestnews','content-bottom-left');
	
	$db=JFactory::getDBO();
	$q="SELECT id FROM #__menu WHERE `home`=1";
	$db->setQuery($q);
	$home_menu_id=intval($db->loadResult());
	foreach($modules as $module)
	{	
		$position=$db->Quote($module[1]);
		$mod=$db->Quote($module[0]);
		
		$q="SELECT id FROM #__modules WHERE `module`={$mod}";
		$db->setQuery($q);
		$module_id=intval($db->loadResult());
		
		//-------- Publish module and show in the right position--------------------
		$q="UPDATE #__modules
			SET `position`={$position}, `showtitle`=0
			WHERE `id`={$module_id}";
		$db->setQuery($q);
		$db->query();
		
		//-------- Show module in home page only--------------------
		//$q="INSERT INTO #__modules_menu(moduleid,menuid)
		//	VALUE({$module_id},{$home_menu_id})";	
		
		$q="UPDATE #__modules_menu SET `menuid`={$home_menu_id}
			WHERE `moduleid`={$module_id}";	
		$db->setQuery($q);
		$db->query();
		
		echo "<br />Publish Module {$mod} in {$position}";
	}
	
} 

function fix_pcoe_user_table()	
{
	//clear all password not needed
	$db=JFactory::getDBO();
	
	$q = "UPDATE `#__pcoe_users` SET `password` = ''";	
	$db->setQuery($q);
	$db->query();
}

?>