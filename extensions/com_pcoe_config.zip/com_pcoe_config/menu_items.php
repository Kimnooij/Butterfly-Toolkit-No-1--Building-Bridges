<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


function create_menu_items()
{
	$db=JFactory::getDBO();
	$q = "SELECT `id` FROM #__components WHERE `link`='option=com_pcoe'";
	$db->setQuery($q);
	$pcoe_id = $db->loadResult();
	
	$q = "SELECT `id` FROM #__menu_types WHERE `menutype`='mainmenu'";
	$db->setQuery($q);
	$mainmenu_id = $db->loadResult();
	
	if($db->getErrorMsg())
	{
		echo "<br />".$db->getErrorMsg();
	}
	
	if($pcoe_id and $mainmenu_id)
	{
		$menutype = "mainmenu";
		$sel_1 = "SELECT count(`id`) FROM #__menu WHERE `link` LIKE '%option=com_pcoe%view=reports%'";
		$sel_2 = "SELECT count(`id`) FROM #__menu WHERE `link` LIKE '%option=com_pcoe%view=alerts%'";
		$sel_3 = "SELECT count(`id`) FROM #__menu WHERE `link` LIKE '%option=com_pcoe%view=dashboard%' 
					OR `link` LIKE '%option=com_pcoe%view=profile%'";
		
		$q = "SELECT `ordering` FROM #__menu WHERE `menutype` = '$menutype'
					ORDER BY `ordering` DESC LIMIT 1";
		$db->setQuery($q);
		$last_order = (int)$db->loadResult();
		
		if($db->getErrorMsg())
		{
			echo "<br />".$db->getErrorMsg();
		}
		
		$items = array(
						array(
							'item'=>'report',
							'name'=>'Reports',
							'alias'=>'incident-reports',
							'link'=>'index.php?option=com_pcoe&view=reports',
							'access'=>'0',
							'query'=>$sel_1,			
						),
						array(
								'item'=>'alert',
								'name'=>'Alerts',
								'alias'=>'incident-alerts',
								'link'=>'index.php?option=com_pcoe&view=alerts',
								'access'=>'0',
								'query'=>$sel_2,
							),
						array(
								'item'=>'dashboard',
								'name'=>'My Profile',
								'alias'=>'profile-dashboard',
								'link'=>'index.php?option=com_pcoe&view=dashboard',
								'access'=>'1',
								'query'=>$sel_3,
							),
					)
					;
							
		foreach($items as $item)
		{
			$db->setQuery($item['query']);
			$result = (int) $db->loadResult();
			
			if($db->getErrorMsg())
			{
				echo "<br />".$db->getErrorMsg();
			}
	
			if($result == 0)
			{
				$name = $item['name'];
				$alias = $item['alias'];
				$link = $item['link'];
				$access = $item['access'];
				$last_order++;
				
				$q = "INSERT INTO `#__menu`(
						   `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, 
							`componentid`, `sublevel`, `ordering`, checked_out, checked_out_time, 
							`pollid`, `browserNav`, `access`, `utaccess`
						)
						VALUES(
							'$menutype', '$name', '$alias', '$link', 'component','0','0',
							'$pcoe_id','0','$last_order', 0, '0000-00-00 00:00:00', '0', '0',
							'$access','0'
						)
						";
						
				$db->setQuery($q);
				$db->query();
				if($db->getErrorMsg())
				{
					echo "<br />".$db->getErrorMsg();
				}
				else
				{
					echo "<br /> $name menu item added to main menu";
				}
			}			

		}
	}
	
}

?>