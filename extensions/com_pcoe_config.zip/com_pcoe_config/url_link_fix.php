<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );
function fixUrlLinks($paths)
{
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	
	$status = true;
	if($paths)
	{
		foreach($paths as $path)
		{
			if(JFolder::exists($path))
			{
				$files=JFolder::files($path, '.', true, true);
				if($files)
				{
					$search = 'href="?';
					foreach($files as $file)
					{
						if(JFile::exists($file))
						{	
							//Check src path
							if (is_readable($file)) 
							{
								$content=JFile::read($file);
								if(strpos($content,$search))
								{				
									$kohana_uri = getKohanaPath($file);	
									$replacement = 'href="index.php?option=com_pcoe&kohana_uri='.$kohana_uri.'&';
									$file_path[0] = $file;
									$status = permission_settings::setPermission($file_path,false,false);
									$content=str_replace($search,$replacement,$content);
									if(!JFile::write($file,$content) and $status)
									{
										$status = false;
									}
									else
									{
										echo "<br>$file anchor links updated";
									}
								}					
							}
						}				
					}
				}
			}	
		}
	}
	return $status;
}

function getKohanaPath($file_path)
{
	jimport('joomla.filesystem.file');
	$filename = JFile::getName($file_path);
	$ext = JFile::getExt($filename);	
	$file_path = str_replace('\\','/',$file_path);
	$path = explode('/views/' ,$file_path);
		
	if(sizeOf($path) > 1)
	{
		$kohana_uri = $path[1];
		$root_file = explode('_',$filename);	
		if(sizeOf($root_file) >1)
			$kohana_uri = str_replace($filename, $root_file[0], $kohana_uri);
		else
		{
			$kohana_uri = str_replace(".$ext", $file, $kohana_uri);
		}	
	}
	return $kohana_uri;
}
?>