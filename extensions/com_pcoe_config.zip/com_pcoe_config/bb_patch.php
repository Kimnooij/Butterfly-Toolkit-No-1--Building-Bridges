<?php
/**
 * @version		$Id: install.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla
 * @subpackage	Menus
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


function building_bridges_patch()
{
	$db=JFactory::getDBO();
	$errors = array();
	$q[] = "CREATE TABLE  IF NOT EXISTS `#__pcoe_update` (
			  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			  `incident_id` bigint(20) NOT NULL,
			  `user_id` int(11) DEFAULT '0',
			  `update_title` text,
			  `update_description` text,
			  `update_date` datetime DEFAULT NULL,
			  `update_dateadd` datetime DEFAULT NULL,
			  `update_datemodify` datetime DEFAULT NULL,
			  `update_rating` varchar(15) NOT NULL DEFAULT '0',
			  PRIMARY KEY (`id`)
			)";


	$q[] = "ALTER TABLE `#__pcoe_comment` ADD COLUMN `update_id` 
			BIGINT(20) UNSIGNED NOT NULL DEFAULT 0 AFTER `incident_id`";

	$q[] = "ALTER TABLE `#__pcoe_rating` ADD COLUMN `update_id` 
	BIGINT(20) UNSIGNED NOT NULL DEFAULT 0 AFTER `incident_id`";

	$q[] = "CREATE TABLE  IF NOT EXISTS `#__pcoe_pcoe_id_xref` (
			  `j_id` INTEGER(20) UNSIGNED NOT NULL,
			  `pcoe_id` INTEGER(20) UNSIGNED NOT NULL,
			  PRIMARY KEY (`j_id`)
	)";
	
	foreach($q as $query)
	{
		$db->setQuery($query);
		$db->query();
		$msg = $db->getErrorMsg();
		if($msg)
			$errors[] = $msg;
	}
	
	$query = "SELECT count(id) FROM #__modules WHERE `position` = 'bb_login'";
	$db->setQuery($query);
	$count = $db->loadResult();
	if(!intval($count) and !$db->getErrorMsg())
	{
		$query = "INSERT INTO #__modules(`title`, `position`, `published`, `module`, `params`)
				VALUES ('BB login', 'bb_login', 1, 'mod_bb_cblogin', 
				'profile_view=1 \n login=index.php?option=com_pcoe&view=dashboard')";
	
		$db->setQuery($query);
		$db->query();
		
		$id = $db->insertid ();
		
		if($id)
		{
			$query = "INSERT INTO #__modules_menu VALUES ('$id',0)";
		
			$db->setQuery($query);
			$db->query();
		}
		else
			$errors[] = $db->getErrorMsg();
	}
	elseif($db->getErrorMsg())
	{		
		$errors[] = $db->getErrorMsg();
	}

	$query = "UPDATE #__modules SET `position`='bb_project_msg', `published`='1' 
			WHERE `module` = 'mod_bb_projectmsg'";
	$db->setQuery($query);
	$db->query();
	
	if($db->getErrorMsg())
	{
		$errors[] = $db->getErrorMsg();
	}
	
	$result = "<br /><br />";
	if(sizeOf($errors))
	{
		$result .= implode('<br /><br />',$errors);
	}
	else
	{
		$result .= "Building Bridges patch applied to PCOE tables";
	}
	
	$files[] = JPATH_SITE.'/administrator/components/com_pcoe/pcoe/media/js/photoslider.js';
	
	if(apply_mootool_jquery_conflict_fix_to_file($files))
	{
		$result  .= "<br /><br /> photoslider.js mootool jquery conflict fixed";
		
	}
	else
		$result .= "<br /><br /> Error resolving photoslider.js mootool jquery conflict ";	
	
	echo $result;
}

?>