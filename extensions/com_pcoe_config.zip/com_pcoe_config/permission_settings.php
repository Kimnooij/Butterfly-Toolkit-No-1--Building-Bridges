<?php
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.archive');
jimport('joomla.filesystem.path');
jimport('joomla.client.helper');
jimport('joomla.client.ftp');
if(class_exists('permission_settings')==false)
{
	class permission_settings
	{		
		function set_folder_permission()
		{	
			$folders=array();
			$extractdir= JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe';
			$folders[]=$extractdir .DS.'pcoe';
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'cache';
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'controllers';
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'views';
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'logs';
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'config';	
			$folders[]=$extractdir .DS.'pcoe'.DS.'media'.DS.'uploads';
			
			permission_settings::setPermission($folders, true);			
		}
		
		function set_config_files_permission()
		{
			$folders=array();
			$extractdir= JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_pcoe';
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'config'.DS.'config.php';
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'config'.DS.'alerts.php';			
			$folders[]=$extractdir .DS.'pcoe'.DS.'application'.DS.'config'.DS.'settings.php';
						
			permission_settings::setPermission($folders);
		}
						
		function setPermission($folders, $createDir=false, $show_result=true)
		{
			$status = true;
			$FTPOptions = JClientHelper::getCredentials('ftp');
			if($folders)
			{
				$ftp = & JFTP::getInstance($FTPOptions['host'], $FTPOptions['port'], null, $FTPOptions['user'], $FTPOptions['pass']);				
				foreach($folders as $folder)
				{
					if($createDir)
					{
						JFolder::create($folder,0777);
					}
					
					if ($FTPOptions['enabled'] == 1) 
					{
						$ftp_path = permission_settings::get_ftp_path($folder);
						if($ftp->chmod($ftp_path, 0777))
						{							
							$msg = '<br>' . $folder .' set permission to 777 success using ftp account' ;
						}
						elseif($ftp->_OS != 'WIN')
						{
							$msg = '<br>' . $folder .' unable to set permission to 777 using ftp account<br>' ;
							$status = false;
						}	
					}
					else
					{		
						if(JPath::canChmod($folder)==true)
						{
							if(JPath::setPermissions($folder,'0777','0777'))
							{
								$msg = '<br>' . $folder .' set permission to 777 success' ;
							}
							else
							{
								$msg = '<br>' . $folder .' unable to set permission to 777' ;
								$status = false;
							}
						}
						else
						{
							$msg = '<br>' . $folder .' unable to set permission to 777.' ;
							$status = false;
						}
					}
					
					if($show_result)
					{
						echo $msg;
					}
				}
			}
			return $status;			
		}
		
		function get_ftp_path($path)
		{
			$ftp_root = permission_settings::detect_ftp_root();
			
			$ftp_root = str_replace('\\','/',$ftp_root);
			$site_root = str_replace('\\','/',JPATH_SITE);
			$path = str_replace('\\','/',$path);
			
			if($ftp_root != $site_root)
			{
				$ftp_path = str_replace($site_root, $ftp_root, $path);
				return $ftp_path;
			}
			return $path;
		}
		
		function detect_ftp_root()
		{
			$FTPOptions = JClientHelper::getCredentials('ftp');	
			if ($FTPOptions['enabled'] == 1) 
			{
				$ftp = & JFTP::getInstance($FTPOptions['host'], $FTPOptions['port'], null, $FTPOptions['user'], $FTPOptions['pass']);	
				if($ftp->_OS != 'WIN' and $FTPOptions['root'])
				{
					return $FTPOptions['root'];
				}
			}
			return JPATH_SITE;
		}
	}
}
?>