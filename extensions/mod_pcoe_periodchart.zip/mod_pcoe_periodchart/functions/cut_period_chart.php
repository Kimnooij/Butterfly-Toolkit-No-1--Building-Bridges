<?php
defined('_JEXEC') or die('Restricted access');

//removes the google map leaving the period graph
class modCutter_Cut_period_chart_processor
{
	function cutterPostProcessor($html)
	{
		$html = modCutter_Cut_period_chart_processor::cutPeriodGraph($html);
		return $html;	
	}	

	function cutPeriodGraph($html)
	{
		if($html)
		{
			$script_tags = modCutterHelper::cutAllCssJsTags($html);			
			$dom = modCutterHelper::convertHtmlToDomDoc($html);
			
			//multiple classes query
			$tag = "div";
			$attribute = "class";
			$value = "slider-holder";
			$attribute2 = "class";
			$value2 = "filter";
			$attribute3 = "id";
			$value3 = "map";

			$query = modCutterHelper::tripleAttributeExtendedQuery($tag, $attribute, $value, $attribute2, $value2, $attribute3, $value3);
			$dom = modCutterHelper::removeNodeElements($query, $dom);
				
			$innerHTML = modCutterHelper::convertDomToHtml($dom);
			$html = $script_tags.$innerHTML;
		}
		return $html; 	
	}
}	
?>