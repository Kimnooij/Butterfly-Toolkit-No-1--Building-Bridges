sfHover = function()

{

 var sfEls = document.menusan.getElementsByTagName("LI");

 

 for (var j=0; j<sfEls.length; j++)

 {

  sfEls[j].onmouseover=function()

  {

   this.className+=" sfhover";

  }

  sfEls[j].onmouseout=function()

  {

   this.className=this.className.replace(new RegExp(" sfhover\\b"), "");

  }

 } 

}

if (window.attachEvent) window.attachEvent("onload", sfHover);

