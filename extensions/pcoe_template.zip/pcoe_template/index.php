<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $mainframe->getTemplate(); ?>/css/template.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $mainframe->getTemplate(); ?>/css/menu.css" type="text/css" />
<link rel="stylesheet" href="css/template.css" type="text/css" /> 
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $mainframe->getTemplate(); ?>/css/pcoe.css" type="text/css" />
<!--[if IE]>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $mainframe->getTemplate(); ?>/css/ie.css" type="text/css" />
<![endif]-->


<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $mainframe->getTemplate(); ?>/scripts/menu.js"></script>
</head>
<body>
	<div id="container"> 
    	<div id="header"> 
        	 <div id="logo" class="floatleft">   
				<jdoc:include type="modules" name="logo" style="none"/>
                <a href="<?php echo $this->baseurl ?>">
                    <?php	echo $mainframe->getCfg('sitename');	?>
                </a>
                <span class="slogan">a positive chain of events</span>
            </div>
        </div>
	<div id="menu1" class="floatright">
		<jdoc:include type="modules" name="top-menu" style="none"/>          
	</div>
	<div id="submenu">
		<div class="submenu-content">
			<div style="float:left">
				<jdoc:include type="modules" name="menu2" style="none"/>  
				<jdoc:include type="modules" name="breadcrumb" style="none"/>  
			</div>
			<div style="float:left">
				<jdoc:include type="modules" name="breadcrumb2" style="none"/>  
			</div>
			<div style="float:right">
				<jdoc:include type="modules" name="search" style="none"/>  
			</div>					
        		</div>
	</div>
	
	<br  style="clear:both" />
	
	<?php 
		if($this->countModules('bottom-left') OR $this->countModules('bottom-right'))
		{
	?>
         <div id="top-middle">
	<?php 
		if($this->countModules('bottom-left') AND $this->countModules('bottom-right'))
		{
	?>
			<div class="top-left" style="width:50%;float:left">
				<jdoc:include type="modules" name="top-left" style="xhtml"/>			
			</div>
			<div class="top-right" style="width:50%;float:right">
				<jdoc:include type="modules" name="top-right" style="xhtml"/>
			</div>
			 <br  style="clear:both" />	
                <?php 
		}
		else
		{
	 ?>
		<div class="top" style="width:100%">
			<jdoc:include type="modules" name="top-left" style="xhtml"/>
			<jdoc:include type="modules" name="top-right" style="xhtml"/>
		</div>  
		 <br  style="clear:both" />	
                 <?php
		}
	?>                                           
        </div>	 
	<?php
	}
	?>    
       
	<div id="site-content">        	
		<?php 
		if($this->countModules('top')):?>
		<div id="top"><jdoc:include type="modules" name="top" style="xhtml"/></div>
		<?php endif;?>
		<table id="nopad" cellspacing="0" cellpadding="1" border="0">
			<tr valign="top">
				<?php if($this->countModules('left') and JRequest::getCmd('layout') != 'form') : ?>
				<td valign="top">
					<div id="left"><jdoc:include type="modules" name="left" style="xhtml"/></div>
				</td>
			    <?php endif; ?>                    
				<td valign="top">
					<div id="component">
						<?php
						if($this->countModules('content-top-left') AND $this->countModules('content-top-right'))
						{?>
							<div style="width:49%;float:left">
								<jdoc:include type="modules" name="content-top-left" style="xhtml"/>
							</div>
							<div style="width:49%;float:right">
								<jdoc:include type="modules" name="content-top-right" style="xhtml"/>
							</div>
							<br  style="clear:both" />
						<?php
						}
						else
						{?>
							<?php if($this->countModules('content-top-left')) :?>
							<div style="width:100%">
								<jdoc:include type="modules" name="content-top-left" style="xhtml"/>
							</div>
							<br  style="clear:both" />
							<?php endif;?>
							<?php if($this->countModules('content-top-right')) :?>
							<div style="width:100%">
								<jdoc:include type="modules" name="content-top-right" style="xhtml"/>
							</div>
							<br  style="clear:both" />
							<?php endif;?>
						<?php }?>		
						
						<?php
						if($this->countModules('content-middle-left or content-middle-left2') 
						AND $this->countModules('content-middle-right or content-middle-right2') )
						{?>
							<div style="width:49%;float:left">
							<?php 
								if($this->countModules('content-middle-left'))
								{ 
							?>
								<div style="width:100%;">
									<jdoc:include type="modules" name="content-middle-left" style="xhtml"/>
								 </div>
							<?php 
								}
								if($this->countModules('content-middle-left2'))
								{ ?>	
								<div style="width:100%;">
									<jdoc:include type="modules" name="content-middle-left2" style="xhtml"/>
								 </div>
							<?php 
								}
							?>
							</div>

							<div style="width:49%;float:right">
							<?php 
								if($this->countModules('content-middle-right'))
								{ ?>
								<div style="width:100%;">
									<jdoc:include type="modules" name="content-middle-right" style="xhtml"/>
								 </div>
							<?php 
								}
								if($this->countModules('content-middle-right2'))
								{ ?>	
								<div style="width:100%;">
									<jdoc:include type="modules" name="content-middle-right2" style="xhtml"/>
								 </div>
							<?php } ?>
							</div>
							<br  style="clear:both" />
						<?php
						}
						else
						{?>
							<?php if($this->countModules('content-middle-left')) :?>							
							<div style="width:100%;float:left">
								<jdoc:include type="modules" name="content-middle-left" style="xhtml"/>
							</div>
							<br  style="clear:both" />
							<?php endif;?>
							<?php if($this->countModules('content-middle-left2')) :?>
							<div style="width:100%">
								<jdoc:include type="modules" name="content-middle-left2" style="xhtml"/>
							</div>
							<br  style="clear:both" />
							<?php endif;?>
							<?php if($this->countModules('content-middle-right')) :?>
							<div style="width:100%">
								<jdoc:include type="modules" name="content-middle-right" style="xhtml"/>
							</div>
							<br  style="clear:both" />
							<?php endif;?>
							<?php if($this->countModules('content-middle-right2')) :?>
							<div style="width:100%">
								<jdoc:include type="modules" name="content-middle-right2" style="xhtml"/>
							</div>
							<br  style="clear:both" />
							<?php endif;?>
						<?php }?>	
						
						<jdoc:include type="component" />
						<br  style="clear:both" />
						
						<?php
						if($this->countModules('content-bottom-left') AND $this->countModules('content-bottom-right'))
						{?>
							<div style="width:49%;float:left">
								<jdoc:include type="modules" name="content-bottom-left" style="xhtml"/>
							</div>
							<div style="width:49%;float:right">
								<jdoc:include type="modules" name="content-bottom-right" style="xhtml"/>
							</div>
						<?php
						}
						else
						{?>
							<?php if($this->countModules('content-bottom-left')) :?>
							<div style="width:100%">
								<jdoc:include type="modules" name="content-bottom-left" style="xhtml"/>
							</div>
							<?php endif;?>
							<?php if($this->countModules('content-bottom-right')) :?>
							<div style="width:100%">
								<jdoc:include type="modules" name="content-bottom-right" style="xhtml"/>
							</div>
							<?php endif;?>
						<?php }?>
						<br  style="clear:both" />			
					</div>
				</td>				    
				<?php if($this->countModules('right') and JRequest::getCmd('layout') != 'form') : ?>
				<td valign="top" style="width:200px;">
					<div id="right" style="float:right"><jdoc:include type="modules" name="right" style="xhtml"/></div>
				</td>
				<?php endif; ?>
			</tr>
		</table>
	</div>
	<div id="footer">
		<?php 
		if($this->countModules('bottom-left') AND $this->countModules('bottom-right'))
		{
	?>
	    <div class="bottom-left" style="width:50%;float:left;">
		 <jdoc:include type="modules" name="bottom-left" style="xhtml"/>
	    </div>
	    <div class="bottom-right" style="width:50%;float:right">
		 <jdoc:include type="modules" name="bottom-right" style="xhtml"/>
	    </div>
	<?php 
		}
		else
		{
	?>			
			<div class="bottom" style="width:100%">
		<jdoc:include type="modules" name="bottom-left" style="xhtml"/>
		<jdoc:include type="modules" name="bottom-right" style="xhtml"/>
			</div>                 
	<?php
		}
	?>                           
	<?php if($this->countModules('bottom')):	?>
	<br class="clear" />
	    <div class="bottom" style="width:100%">
		 <jdoc:include type="modules" name="bottom" style="xhtml"/>
	    </div>
	<?php endif; ?>
	<br class="clear" />
	<div class="footer" style="width:100%">
		<jdoc:include type="modules" name="footer" style="xhtml"/>
	</div>
</div>	 
        	 
<!--      
Top #ffffff
Top 1 #756767
Top 2 #C1B9B6
Red button #EE3A43
Dark button #756767
Header Color : #C1B9B6
Content color : #E1DDDA
-->

</div>
</body>
</html>
