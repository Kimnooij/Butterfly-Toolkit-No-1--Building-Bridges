<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
$mainframe->registerEvent( 'onSearch', 'botSearchPcoeIncident' );
$mainframe->registerEvent( 'onSearchAreas', 'botSearchPcoeIncidentAreas' );

//load language file
JPlugin::loadLanguage( 'plg_search_pcoe_search' );
  
  function &botSearchPcoeIncidentAreas() 
  {
    static $areas = array('pcoe_search' => 'Incident');
    return $areas;
  }
  
  function botSearchPcoeIncident ( $text, $phrase='', $ordering='', $areas=null )
  {
    if (!$text) 
    {
      return array();
    }
    if (is_array( $areas )) 
    {
      if (!array_intersect( $areas, array_keys( botSearchPcoeIncidentAreas() ) )) 
      {
        return array();
      }
    }
  
    $db =& JFactory::getDBO();
    if ($phrase == 'exact')
    {
      $where = " incident_title LIKE '%$text%'
                 OR incident_description LIKE '%$text%' ";
    }
    else
    {
      $words = explode( ' ', $text );
      $wheres = array();
      foreach ($words as $word) 
      {
        $wheres[] = " incident_title LIKE '%$text%'
                     OR incident_description LIKE '%$text%' ";
      }
      if($phrase == 'all')
      {
        $separator = "AND";
      }
      else
      {
        $separator = "OR";
      }
      $where = '(' . implode( ") $separator (" , $wheres ) . ')';
    }
    //$where .= ' AND incident_verified = 1';
    
    switch ($ordering) 
    {
      case 'oldest':
        $order = 'incident_dateadd ASC';
        break;
      case 'alpha':
        $order = 'incident_title ASC';
        break;
      case 'newest':
        default:
        $order = 'incident_dateadd DESC';
      break;
    }
    
    //load pcoe config file
    if(!defined('SYSPATH'))define('SYSPATH',1);
    require_once(JPATH_ADMINISTRATOR."/components/com_pcoe/pcoe/application/config/database.php");
    
    $table_prefix = $config['default']['table_prefix'];
    $link = 'index.php?option=com_pcoe&kohana_uri=reports/view/';
    $query = "SELECT incident_title AS title, incident_description AS text,
    incident_dateadd AS created, " .
    "\n CONCAT('$link', id) AS href," .
    "\n '2' AS browsernav" .
    "\n FROM ".$table_prefix."incident" .
    "\n WHERE $where" .
    "\n ORDER BY $order";
    $db->setQuery( $query );
    $rows = $db->loadObjectList();
    return $rows;
  }

?>

