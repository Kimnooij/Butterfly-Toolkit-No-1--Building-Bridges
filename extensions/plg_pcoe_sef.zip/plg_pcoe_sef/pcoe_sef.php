<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
// Import library dependencies
jimport('joomla.event.plugin');

class plgPcoePCOE_Sef extends JPlugin {

	
	function plgPcoePCOE_Sef(&$subject, $config = array())
	{
		parent::__construct($subject, $config);
	}
	
	function onSefURL(&$article)
	{
		$content=$article->text;
		$finds=array();
		$replaces=array();
		
		$path= dirname($_SERVER['PHP_SELF']);
		$finds[]='index.php?option=com_pcoe&kohana_uri=media/';
		$finds[]='href="feeds"';
		
		
		$replaces[]='administrator/components/com_pcoe/pcoe/media/';
		$replaces[]='href="http://' .$_SERVER['HTTP_HOST'].'/'. JRoute::_('index.php?option=com_pcoe&kohana_uri=feeds').'"';
				
		
		$tags=null;
		$patterns=array();
		
		$patterns[]= array('href',"'href\s*=\s*([\"\'])([^\"\']+)([\"\'])'i");
		$patterns[]= array('action',"'action\s*=\s*([\"\'])([^\"\']+)([\"\'])'i");
		
		foreach($patterns as $pattern_item)
		{
			$pattern_text=$pattern_item[0];
			$pattern=$pattern_item[1];			
			$tags=array();
			preg_match_all ( $pattern , $content, $tags );
			$links=$tags[2];

			foreach($links as $link)
			{
				$finds[]=$link;
				$url_to_sef=str_replace(JURI::base(),'',$link);				
				$url_to_sef=JRoute::_($url_to_sef);
				$replaces[]=$url_to_sef;				
			}
		}
		$finds[]= JRoute::_('index.php?option=com_pcoe&kohana_uri=feed');
		$replaces[]='http://' .$_SERVER['HTTP_HOST']. JRoute::_('index.php?option=com_pcoe&kohana_uri=feed');
		$content=str_ireplace($finds,$replaces,$content);
		$article->text=$content;				
		return true;
	}
}
?>