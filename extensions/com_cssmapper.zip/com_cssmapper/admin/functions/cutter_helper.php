<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

class CssMapperCutterHelper
{
  function getCutterClassPrefix()
  {
     return 'cutter-';
  }

}