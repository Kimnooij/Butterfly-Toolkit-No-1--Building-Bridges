<?php

// no direct access

defined('_JEXEC') or die('Restricted access');



function css_map($html, $old, $new)

{

	$html = htmlspecialchars_decode($html, ENT_QUOTES);

	$html = replaceClass($html, $old, $new);

    $html = replaceClassSp($html, $old, $new);

    $html = replaceSpClass($html, $old, $new);

    $html = replaceSpClassSp($html, $old, $new);



   return $html;

}



function replaceClass($html, $old, $new)

{

	$pattern = '/<(\w+)[^>]*\sclass\s?=\s?([\'\"])'.$old.'[\'\"][^>]*>(.*?)/i';

	preg_match_all ( $pattern , $html , $tags );

	$matches = $tags[0];

//print_r($matches);	

	if($matches)

	{

		$matches = array_filter($matches);

        $matches = array_unique($matches);

		

		foreach($matches as $match)

		{

			$pattern2 = "/[\s]class(\s?)=(\s?)('|\")$old('|\")/i";

            $replace = " class=\"$new\"";

						

			$replacement[] = preg_replace($pattern2, $replace, $match);

			$match_pattern[] = '{'.$match.'}';

		}	

		$html = preg_replace($match_pattern, $replacement, $html);

	}	

   

    return $html; 

}



function replaceClassSp($html, $old, $new)

{

    $pattern = '/<(\w+)[^>]*\sclass\s?=\s?([\'\"])'.$old.'[\s][^>]*>(.*?)/i';

	

	preg_match_all ( $pattern , $html , $tags );

	$matches = $tags[0];

//print_r($matches);	

	if($matches)

	{

		$matches = array_filter($matches);

        $matches = array_unique($matches);

		

		$pattern1 = "<[.*\s]class(\s?)=(\s?)('|\")$old(\s)(.*)('|\").*?>i";

		$pattern2 = array("/class(\s?)=(\s?)\"$old(\s)/i",

						  "/class(\s?)=(\s?)'$old(\s)/i"

					);

		$replace = array("class=\"$new ",

						  "class='$new "

					);

		foreach($matches as $match)

		{						

			preg_match_all ( $pattern1 , $match , $match2 );

			$attribute = $match2[0][0];

			

			if($attribute)

			{

				$replace1 = preg_replace($pattern2, $replace, $attribute);

				$replacement[] = preg_replace($pattern1, $replace1, $match);

			}

			else

				$replacement[] = preg_replace($pattern2, $replace, $match);

			$match_pattern[] = '{'.$match.'}';

			

//print_r($replacement);print_r($match_pattern);	die();	

			

		}	

		$html = preg_replace($match_pattern, $replacement, $html);

	}	

   

   return $html; 

}

function replaceSpClass($html, $old, $new)

{

    $pattern = '/<(\w+)[^>]*\sclass\s?=\s?([\'\"])[^>]*(\s)'.$old.'[\'\"][^>]*>(.*?)/i';

    preg_match_all ( $pattern , $html , $tags );

	$matches = $tags[0];

//print_r($matches);	

	if($matches)

	{

		$matches = array_filter($matches);

        $matches = array_unique($matches);

		

		$pattern1 = "<[.*\s]class(\s?)=(\s?)('|\")(.*\s)$old('|\").*?>i";

		$pattern2 = array("/(\s)$old(\")/i",

						  "/(\s)$old(')/i"

					);

		$replace = array(" $new\"",

						  " $new'"

					);

		

		foreach($matches as $match)

		{

			

			preg_match_all ( $pattern1 , $match , $match2 );

			$attribute = $match2[0][0];

			

			if($attribute)

			{

				$replace1 = preg_replace($pattern2, $replace, $attribute);

				$replacement[] = preg_replace($pattern1, $replace1, $match);

			}

			else

				$replacement[] = preg_replace($pattern2, $replace, $match);

			$match_pattern[] = '{'.$match.'}';

			

//print_r($replacement);print_r($match_pattern);	die();		

	

		}	

		$html = preg_replace($match_pattern, $replacement, $html);

	}	

   

   return $html; 

}

function replaceSpClassSp($html, $old, $new)

{

    $pattern = '/<(\w+)[^>]*\sclass\s?=\s?([\'\"])[^>]*(\s)'.$old.'(\s)[^>]*>(.*?)/i';

    preg_match_all ( $pattern , $html , $tags );

	$matches = $tags[0];

//print_r($matches);	

	if($matches)

	{

		$matches = array_filter($matches);

        $matches = array_unique($matches);

	

		$pattern1 = "/[.*\s]class(\s?)=(\s?)('|\")(.*\s)$old(\s)(.*)?('|\").*?/i";

		$pattern2 ="/(\s)$old(\s)/i";

		$replace = " $new ";

					

		foreach($matches as $match)

		{

			preg_match_all ( $pattern1 , $match , $match2 );

			$attribute = $match2[0][0];



			if($attribute)

			{						

				$replace1 = preg_replace($pattern2, $replace, $attribute);

				$replacement[] = preg_replace($pattern1, $replace1, $match);

			}

			

			else

				$replacement[] = preg_replace($pattern2, $replace, $match);

			$match_pattern[] = '{'.$match.'}';



//print_r($replacement);print_r($match_pattern);	die();	

			

		}	

		$html = preg_replace($match_pattern, $replacement, $html);

	}   

   return $html; 

}



function match_pattern($pattern, $html)

{

	$html = clean_html($html);

	preg_match_all ( $pattern , $html , $matches );

    return $matches[0];

}



function clean_pattern_string($html, $pattern)

{

	$new = str_replace("$pattern", "\\".$pattern, $htm);

	return $new;

}



function clean_html($html)

{

	

	$html = str_replace("<br>", "\n", $html);

	$html = str_replace("<br />", "\n", $html);

	$html = str_replace("<p>", "\n", $html);

	$html = str_replace("</p>", "", $html);

	$html = str_replace("</ p>", "", $html);

	

	return $html;

}





function getSampleData()

{

$html = 

'

test article

column_1

column_2

column_3





        <div class="column_1">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

       

        <div class="column_1pre column_1">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

        

        <div class="column_1 column_1post">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

        

        <div class="column_1pre column_1 column_1post">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>





        <div class="column_2">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

       

        <div class="column_2pre column_2">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

        

        <div class="column_2 column_2post">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

        

        <div class="column_2pre column_2 column_2post">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>





        <div class="column_3">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

       

        <div class="column_3pre column_3">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

        

        <div class="column_3 column_3post">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>

        

        <div class="column_3pre column_3 column_3post">

            <div class="indent">

                <jdoc:include type="modules" name="box3" style="custom" />

            </div>

        </div>        

        <div class="column_1 column_2 column_3"/>

		<span class="column_1 column_2 column_3"/>

    </div>

</div>

';



return $html;

}

