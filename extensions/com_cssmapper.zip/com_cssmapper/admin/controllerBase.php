<?php
 
// no direct access
defined('_JEXEC') or die('Restricted access');
 
jimport( 'joomla.application.component.controller' );
 
class JControllerBase extends JController
{
    function getViewName() { JError::raiseError(500,"getViewName() not implemented"); } /* abstract */

    function getModelName() { JError::raiseError(500,"getModelName() not implemented"); } /* abstract */

    function getLayoutName() { return 'default'; }
    
  	function getParentView() { JError::raiseError(500,"function not implemented");  } /* abstract */
  	
  	function getChildView() { JError::raiseError(500,"function not implemented");  } /* abstract */
   
  	function doSave() { JError::raiseError(500,"function not implemented");  } /* abstract */
  	
    function display()
    {      
        $doc = &JFactory::getDocument();
		    $viewType = $doc->getType();
        $view = &$this->getView( ucfirst($this->getViewName()), $viewType);
 
        if ($model = &$this->getModel($this->getModelName()))
        {
            $view->setModel($model, true);
        } 
        $view->setLayout($this->getLayoutName());
        $view->display();
    }	
    function add()
  	{
  		$childView = $this->getChildView();
  		$this->redirectToChild();
  	}	
    function save()
  	{	
  		$status = $this->doSave();
  		if($status['success'] )
  			$this->redirectToParent($status['message']);
  		else
  			$this->redirectToSelf($status['message']);
  	}
  	function apply()
  	{
  		$status = $this->doSave();
  		$this->redirectToSelf($status['message']);
  	}
  	function cancel()
  	{
  			$this->redirectToParent();
  	}	
  	
  	function back()
  	{
  		$parentView = $this->getParentView();
  		$this->setRedirect("index.php?option=com_cssmapper&view=$parentView");
  	}
  	function redirectToParent($msg=null)
  	{
  		$parentView = $this->getParentView();
  		$this->setRedirect("index.php?option=com_cssmapper&view=$parentView", $msg);
  	}
  	function redirectToChild($msg=null)
  	{
  		$childView = $this->getChildView();
  		$id = JRequest::getVar('id');
  		$this->setRedirect("index.php?option=com_cssmapper&view=$childView&id=$id", $msg);
  	}	
  	function redirectToSelf($msg=null)
  	{
  		$view = JRequest::getVar('view');
  		$id = JRequest::getVar('id');
  		$this->setRedirect("index.php?option=com_cssmapper&view=$view&id=$id", $msg);  		
  	}
  	
  	function successStatus($msg=null)
  	{
      	$status['success'] = true;
  			$status['message'] = $msg;
  			return $status;
    }
	   
	   function failureStatus($msg=null)
  	{
      	$status['success'] = false;
  			$status['message'] = $msg;
  			return $status;
    }
} 
?> 