<?php
	defined('_JEXEC') or die('Restricted access');
	class JTableCssmapper extends JTable
	{
		var $id = null;
		var $page_reg_exp = null;
		var $src_css_class = null;
		var $dest_css_class = null;
		var $remark = null;
			
		function __construct(&$db)
		{
			parent::__construct( '#__cssmapper', 'id', $db );
		}
	}
?>