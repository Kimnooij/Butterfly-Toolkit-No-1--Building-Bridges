<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

class JControllerDetail extends JControllerBase
{
	function getViewName() { return 'detail';	} 
	function getModelName(){ return 'detail'; }	
	function getParentView(){return 'list';}  
	function getChildView() { return 'detail';} 
 
	function doSave()
	{			
    $row =& JTable::getInstance('cssmapper', 'JTable');
		if (!$row->bind(JRequest::get('post')))
		{
  		  return $this->failureStatus(CSSMAPPER_CNTRL_BIND_FAILURE_LBL);
		}
		$text = JRequest::getVar( 'remark', '', 'post', 'string', JREQUEST_ALLOWRAW );
		//$row->remark = addslashes($row->remark);
		$row->remark = $text;
		if($row->page_reg_exp and $row->src_css_class and $row->dest_css_class )
		{                                                                                 
		  //add cutter class (used by mod_cutter to identify class after cssmapper plugin changes class name) 
		  $prefix = CssMapperCutterHelper::getCutterClassPrefix();
      $row->dest_css_class =  "{$prefix}{$row->src_css_class} {$row->dest_css_class}";
		  
			if (!$row->store())
			{
				return $this->failureStatus(CSSMAPPER_CNTRL_SAVE_FAILURE_LBL);
			}
			else
			{
				if(!JRequest::getVar( 'id', ''))
				{
					JRequest::setVar( 'id', $row->id);
				}
		      return $this->successStatus(CSSMAPPER_CNTRL_SAVE_SUCCESS_LBL);
		    }
		}
		else
		{
			return $this->failureStatus(CSSMAPPER_CNTRL_MISSING_PARAMS_LBL);
		}
	}
}
