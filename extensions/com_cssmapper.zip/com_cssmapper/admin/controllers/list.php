<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

class JControllerList extends JControllerBase
{	
	function getViewName(){ return 'list'; }
	function getModelName(){ return 'list'; }
	function getParentView(){return 'list';}   
	function getChildView() { return 'detail';} 
	function doSave() {  } 
		
	function delete()
	{
		$id = JRequest::getVar('id');
		$db=JFactory::getDBO();
		$q = "DELETE FROM #__cssmapper where id = '$id'";
		$db->setQuery($q);
		if($db->query())
		{
			$msg = CSSMAPPER_CNTRL_DELETE_SUCCESS;
		}
		else
		{
			$msg = $db->getErrorMsg();
		}
		
		$this->redirectToSelf($msg);
	}
	
	function test_cssmapper()
	{
      require_once(JPATH_COMPONENT."/functions/helper.php");
      $html = getSampleData();
      $new = css_map($html, "column_2", "xxxcolumn_2xxx");
      echo "$new";
      die("end");
  }
}

?>