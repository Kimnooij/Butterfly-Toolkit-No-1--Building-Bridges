<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
	
	
	JToolBarHelper::Title(CSSMAPPER_LIST_VIEW , 'generic');
	JToolBarHelper::addNew();
		
	//set links
	$detail_link = "index.php?option=com_cssmapper&amp;view=detail&amp;id=";
	$delete_link = "index.php?option=com_cssmapper&amp;view=list&amp;task=delete&amp;id=";	
	
?>	
	<form action="index.php" method="post" name="adminForm" id="adminForm">
			<table class="adminlist">           
				<tr>
					<th>#</th>
					<th><?php echo CSSMAPPER_LIST_ID_COLUMN ?></th>
					<th><?php echo CSSMAPPER_LIST_REG_EXPRESSION_COLUMN ?></th>
					<th><?php echo CSSMAPPER_LIST_SRC_CSS_COLUMN ?></th>
					<th><?php echo CSSMAPPER_LIST_DEST_CSS_COLUMN ?></th>
					<th><?php echo CSSMAPPER_LIST_REMARK_COLUMN ?></th>
					<th><?php echo CSSMAPPER_LIST_EDIT_COLUMN ?></th>	
          <th><?php echo CSSMAPPER_LIST_DELETE_COLUMN ?></th>						
				</tr>                     
	<?php
				$row_size = count($this->rows);
				$k = 0;
				$i = 0;
				//if($row_size > 0)
				if($this->rows)
				{
					foreach($this->rows as $row)
          {	
              $remark = strip_tags($row->remark);
              $remark = (strlen($remark) > 45) ? substr($remark, 0, 45)."....."  :  $remark;
              //remove cutter class
              $dest_css = str_replace("{$this->prefix}{$row->src_css_class} ", "", $row->dest_css_class);										
	?>	        
					<tr class="<?php echo "row$k"; ?>">
						<td><?php echo $i + 1;?></td>
						<td><?php echo $row->id?></td>
						<td><?php echo $row->page_reg_exp?></td>
						<td><?php echo $row->src_css_class?></td>
						<td><?php echo $dest_css?></td>
					  <!--td><?php //echo $row->dest_css_class?></td-->
						<td><?php echo $remark?></td>
						<td><a href="<?php echo $detail_link.$row->id?>"><?php echo CSSMAPPER_LIST_EDIT_LBL; ?></a></td>
						<td><a href="<?php echo $delete_link.$row->id?>"><?php echo CSSMAPPER_LIST_DELETE_LBL; ?></a></td>
					</tr>
	<?php
					$row_count++;
					$k = 1 - $k; $i++;
					}
				}
	?>				
				
					<tfoot>				
						<td colspan="8"><?php echo $this->pageNav->getListFooter(); ?></td>
					</tfoot>
				
			</table>
		<input type="hidden" name="option" value="com_cssmapper" />
		<input type="hidden" name="view" value="list" />
		<input type="hidden" name="task" value="" />
		
	</form>	
