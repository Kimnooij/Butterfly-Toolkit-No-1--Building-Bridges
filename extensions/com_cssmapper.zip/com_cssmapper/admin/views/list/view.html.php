<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
	jimport('joomla.application.component.view');
	class JViewList extends JView
	{
		function display($tpl = null)
		{	
			global $option, $mainframe;
			
			$limit = JRequest::getVar('limit', $mainframe->getCfg('list_limit'));
			$limitstart = JRequest::getVar('limitstart', 0);
					
			$model = &$this->getModel();
			
			$rows = $model->getAll($limitstart, $limit);
				
			$total = $model->countRows($where_clause);
			
			jimport('joomla.html.pagination');
			$pageNav = new JPagination($total, $limitstart, $limit);
			
      //get cutter prefix
      $prefix = CssMapperCutterHelper::getCutterClassPrefix();
      			
			$this->assignRef('rows', $rows);
			$this->assignRef('pageNav', $pageNav);
			$this->assignRef('prefix', $prefix);
									
			parent::display($tpl); 
		}
	}
?>