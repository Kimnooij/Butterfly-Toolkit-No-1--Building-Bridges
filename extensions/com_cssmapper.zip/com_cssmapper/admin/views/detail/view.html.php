<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
	jimport('joomla.application.component.view');
	class JViewDetail extends JView
	{
		
		function display($tpl = null)
		{			
			$limit = JRequest::getVar('limit');
			$limitstart = JRequest::getVar('limitstart');
				
			$id = JRequest::getVar('id');
			$model = &$this->getModel();
			if($id)
			{
				$row = $model->findById($id);     
			  
        //get cutter prefix
        $prefix = CssMapperCutterHelper::getCutterClassPrefix();
        //remove cutter class
        $row->dest_css_class = str_replace("{$prefix}{$row->src_css_class} ", "", $row->dest_css_class);	 
				
			}
			$editor =& JFactory::getEditor();
			
      
			$this->assignRef('row', $row);
			$this->assignRef('id', $id);
			$this->assignRef('editor', $editor);
			
			parent::display($tpl); 
		}
		
	}
?>