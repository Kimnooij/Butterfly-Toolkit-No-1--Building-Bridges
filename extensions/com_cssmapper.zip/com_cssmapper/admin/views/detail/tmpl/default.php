<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
	
	if($this->id)
  { 
    JToolBarHelper::Title(CSSMAPPER_UPDATE_DETAIL_VIEW , 'generic');         
  }
	else
  { 
    JToolBarHelper::Title(CSSMAPPER_NEW_DETAIL_VIEW , 'generic');
  }
  
  JToolBarHelper::save();
  JToolBarHelper::apply();
  JToolBarHelper::cancel();
	
?>
	<form action="index.php" method="post" name="adminForm" id="adminForm">
			                  
	   <fieldset class="adminform">
				<legend><?php echo CSSMAPPER_DETAIL_LEGEND_LBL ?></legend>
				<table class="admintable">		
					<tr>
						<td width="20" align="right" class="key"><?php echo CSSMAPPER_DETAIL_REG_EXPRESSION_LBL?></td>						
						<td>
		            <input style="width:150px" type="text" name="page_reg_exp" value="<?php echo $this->row->page_reg_exp ?>" />
						</td>
					</tr>
					
					<tr>
						<td width="20" align="right" class="key"><?php echo CSSMAPPER_DETAIL_SRC_CLASS_LBL?></td>						
						<td>
		            <input style="width:150px" type="text" name="src_css_class" value="<?php echo $this->row->src_css_class ?>" />
						</td>
					</tr>
					
					<tr>
						<td width="20" align="right" class="key"><?php echo CSSMAPPER_DETAIL_DEST_CLASS_LBL?></td>						
						<td>
		            <input style="width:150px" type="text" name="dest_css_class" value="<?php echo $this->row->dest_css_class ?>" />
						</td>
					</tr>
					
					<tr>
						<td width="20" align="right" class="key"><?php echo CSSMAPPER_DETAIL_REMARK_LBL?></td>
						
						<td>
		<?php
						echo $this->editor->display( 'remark', $this->row->remark ,'100%', '150', '40', '10' ) ;
		?>
					   
          	</td>
					</tr>
				
				</table>
			</fieldset>
			<input type="hidden" name="option" value="com_cssmapper" />
			<input type="hidden" name="view" value="detail" />
			<input type="hidden" name="id" value="<?php echo $this->row->id ?>" />
		  <input type="hidden" name="task" value="" />
	</form>	

	<?php

?>