<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
	jimport( 'joomla.application.component.model' );
	
	class JModelList extends JModel
	{	
		function __construct()
		{
			parent::__construct();
		
		}
		function getAll($limitstart, $limit)
		{
			$db=JFactory::getDBO();
			$q = "SELECT  * FROM #__cssmapper ORDER BY id ASC " ;
			$db->setQuery($q, $limitstart, $limit);
			return $db->loadObjectList();
		}	
		
		function countRows()
		{
			$db=JFactory::getDBO();
			$q = "SELECT count(*) FROM #__cssmapper " ;
		
			$db->setQuery($q);
			return $db->loadResult();
		}	
				
	}
	
?>