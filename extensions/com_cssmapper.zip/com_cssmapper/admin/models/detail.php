<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
	jimport( 'joomla.application.component.model' );
	
	class JModelDetail extends JModel
	{
	
		function __construct()
		{
			parent::__construct();
		
		}
		function findById($id)
		{
			$db=JFactory::getDBO();
			$q = "SELECT  * FROM #__cssmapper WHERE id = $id" ;
			$db->setQuery($q);
			return $db->loadObject();
		}			
	}
	
?>