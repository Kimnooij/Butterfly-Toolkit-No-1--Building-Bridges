<?php
	
	define('CSSMAPPER_LIST_VIEW','List');
	define('CSSMAPPER_UPDATE_DETAIL_VIEW','Edit');
	define('CSSMAPPER_NEW_DETAIL_VIEW','New');
	
	define('CSSMAPPER_DETAIL_LEGEND_LBL','');
	define('CSSMAPPER_DETAIL_REG_EXPRESSION_LBL','Page URL Reg Expression');
	define('CSSMAPPER_DETAIL_SRC_CLASS_LBL','Source CSS Class');
	define('CSSMAPPER_DETAIL_DEST_CLASS_LBL','Destination CSS Class');
	define('CSSMAPPER_DETAIL_REMARK_LBL','Remark');
	
	define('CSSMAPPER_LIST_ID_COLUMN','ID');
	define('CSSMAPPER_LIST_REG_EXPRESSION_COLUMN','Page URL Reg Expression');
	define('CSSMAPPER_LIST_SRC_CSS_COLUMN','Source CSS Class');
	define('CSSMAPPER_LIST_DEST_CSS_COLUMN','Destination CSS Class');
	define('CSSMAPPER_LIST_REMARK_COLUMN','Remark');
	define('CSSMAPPER_LIST_EDIT_COLUMN','Edit');
	define('CSSMAPPER_LIST_DELETE_COLUMN','Delete');
	
	define('CSSMAPPER_LIST_EDIT_LBL','Edit');
	define('CSSMAPPER_LIST_DELETE_LBL','Delete');
	
	define('CSSMAPPER_CNTRL_BIND_FAILURE_LBL','Bind failure');
	define('CSSMAPPER_CNTRL_SAVE_FAILURE_LBL','Save failure');
	define('CSSMAPPER_CNTRL_SAVE_SUCCESS_LBL','Save success');
	define('CSSMAPPER_CNTRL_DELETE_SUCCESS','Item deleted');
	define('CSSMAPPER_CNTRL_MISSING_PARAMS_LBL','Please enter values for Page URL Regexp, source and destinaion css class');
	
?>

     