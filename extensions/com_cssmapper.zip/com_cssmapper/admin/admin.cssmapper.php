<?php

// no direct access
defined('_JEXEC') or die('Restricted access');
 
// Set the path definitions 
JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

//get active language
$lang =& JFactory::getLanguage();
$active_lang = trim($lang->get('backwardlang'));

//get  language file
if( file_exists(dirname(__FILE__).DS.'languages'.DS.$active_lang.'.php')) {
	require_once(dirname(__FILE__).DS.'languages'.DS.$active_lang.'.php');
} 
else {
	require(dirname(__FILE__).DS.'languages'.DS.'english.php');
}

//get base controller
require_once (JPATH_COMPONENT.DS.'controllerBase.php');

//load cutter helper
require_once (JPATH_COMPONENT.DS.'functions'.DS.'cutter_helper.php');     		 

//get query variables
 
$cmd = JRequest::getCmd('task', 'display');
$controller=JRequest::getcmd('view', 'list');

$controllerPath    = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
 
if (file_exists($controllerPath)) {
        require_once($controllerPath);
} else {
        JError::raiseError(500, 'Invalid Controller');
}
 
$controllerClass = 'JController'.ucfirst($controller);
if (class_exists($controllerClass)) {
    $controller = new $controllerClass();
} else {
    JError::raiseError(500, 'Invalid Controller Class');
}
 
$controller->execute($task);

if($task != 'display')
{
	$controller->redirect();
}

?>

